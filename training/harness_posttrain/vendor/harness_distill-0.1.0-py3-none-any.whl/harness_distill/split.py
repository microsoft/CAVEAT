"""Leakage-resistant family inventories for procedural training tasks.

Exact domain, layout-style, and instruction-template family names are disjoint
across train, validation, and test.  Layouts still share four broad interaction
archetypes so held-out evaluation measures style generalization rather than an
entirely unseen navigation primitive.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from hashlib import sha256

SPLIT_ORDER = ("train", "validation", "test")

# The benchmark's Amazon categories remain sealed from procedural training.
FORBIDDEN_BENCHMARK_DOMAINS = frozenset({"laptop", "office_chair", "mattress", "backpack", "tent"})

DOMAIN_FAMILIES: Mapping[str, tuple[str, ...]] = {
    "train": (
        "espresso_machine",
        "air_purifier",
        "robot_vacuum",
        "portable_projector",
        "power_station",
        "dehumidifier",
        "induction_cooktop",
        "document_scanner",
        "dash_camera",
        "digital_piano",
        "thermal_camera",
        "bread_maker",
        "retreat_venue",
        "rehearsal_room",
        "workshop_space",
        "translation_service",
        "data_labeling_service",
        "equipment_repair",
        "packaging_vendor",
        "component_supplier",
        "catering_bid",
        "cloud_backup_plan",
        "fleet_tracking_plan",
        "support_subscription",
    ),
    "validation": (
        "photo_printer",
        "cordless_drill",
        "studio_rental",
        "transcription_service",
        "courier_vendor",
        "mobile_data_plan",
    ),
    "test": (
        "sous_vide_cooker",
        "water_flosser",
        "meeting_room",
        "print_service",
        "laboratory_supplier",
        "renewable_energy_plan",
    ),
}

_LAYOUT_ARCHETYPES = (
    "grid_visible_total",
    "list_numbered_pager",
    "table_visible_total",
    "cards_numbered_pager",
)
LAYOUT_FAMILIES: Mapping[str, tuple[str, ...]] = {
    split: tuple(f"{split}_{archetype}" for archetype in _LAYOUT_ARCHETYPES)
    for split in SPLIT_ORDER
}

_TEMPLATE_STYLES = ("direct", "narrative", "procurement", "concise")
TEMPLATE_FAMILIES: Mapping[str, tuple[str, ...]] = {
    split: tuple(f"{split}_{style}" for style in _TEMPLATE_STYLES) for split in SPLIT_ORDER
}


@dataclass(frozen=True)
class SplitInventory:
    split: str
    domain_families: tuple[str, ...]
    layout_families: tuple[str, ...]
    template_families: tuple[str, ...]


def inventory(split: str) -> SplitInventory:
    if split not in SPLIT_ORDER:
        raise ValueError(f"unknown split {split!r}")
    return SplitInventory(
        split=split,
        domain_families=DOMAIN_FAMILIES[split],
        layout_families=LAYOUT_FAMILIES[split],
        template_families=TEMPLATE_FAMILIES[split],
    )


def layout_archetype(layout_family: str) -> str:
    for split in SPLIT_ORDER:
        prefix = f"{split}_"
        if layout_family.startswith(prefix):
            archetype = layout_family[len(prefix) :]
            if archetype in _LAYOUT_ARCHETYPES:
                return archetype
    raise ValueError(f"unknown layout family {layout_family!r}")


def template_style(template_family: str) -> str:
    for split in SPLIT_ORDER:
        prefix = f"{split}_"
        if template_family.startswith(prefix):
            style = template_family[len(prefix) :]
            if style in _TEMPLATE_STYLES:
                return style
    raise ValueError(f"unknown template family {template_family!r}")


def family_split(family: str) -> str:
    matches = [
        split
        for split in SPLIT_ORDER
        if family in DOMAIN_FAMILIES[split]
        or family in LAYOUT_FAMILIES[split]
        or family in TEMPLATE_FAMILIES[split]
    ]
    if len(matches) != 1:
        raise ValueError(f"family {family!r} has {len(matches)} split assignments")
    return matches[0]


def validate_assignment(
    split: str,
    domain_family: str,
    layout_family: str,
    template_family: str,
) -> None:
    selected = inventory(split)
    if domain_family not in selected.domain_families:
        raise ValueError(f"domain {domain_family!r} does not belong to {split!r}")
    if layout_family not in selected.layout_families:
        raise ValueError(f"layout {layout_family!r} does not belong to {split!r}")
    if template_family not in selected.template_families:
        raise ValueError(f"template {template_family!r} does not belong to {split!r}")


def assert_split_disjoint() -> None:
    for inventory_map, label in (
        (DOMAIN_FAMILIES, "domain"),
        (LAYOUT_FAMILIES, "layout"),
        (TEMPLATE_FAMILIES, "template"),
    ):
        seen: set[str] = set()
        for split in SPLIT_ORDER:
            values = inventory_map[split]
            if len(set(values)) != len(values):
                raise ValueError(f"duplicate {label} within {split}")
            overlap = seen.intersection(values)
            if overlap:
                raise ValueError(f"{label} leakage across splits: {sorted(overlap)}")
            seen.update(values)

    domain_names = set().union(*(set(DOMAIN_FAMILIES[split]) for split in SPLIT_ORDER))
    leaked = domain_names.intersection(FORBIDDEN_BENCHMARK_DOMAINS)
    if leaked:
        raise ValueError(
            f"sealed benchmark domains leaked into procedural inventory: {sorted(leaked)}"
        )
    if tuple(len(DOMAIN_FAMILIES[split]) for split in SPLIT_ORDER) != (24, 6, 6):
        raise ValueError("domain split must remain 24/6/6")


def split_fingerprint() -> str:
    payload = {
        "domains": {split: DOMAIN_FAMILIES[split] for split in SPLIT_ORDER},
        "layouts": {split: LAYOUT_FAMILIES[split] for split in SPLIT_ORDER},
        "templates": {split: TEMPLATE_FAMILIES[split] for split in SPLIT_ORDER},
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256(encoded).hexdigest()


assert_split_disjoint()
