"""Build assistant-only SFT rows from successful policy traces and corrections."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping, Sequence
from copy import deepcopy
from pathlib import Path
from typing import Any

from .materialize import (
    PROXY_TRACE_SCHEMA,
    MaterializationError,
    canonical_json,
    infer_turn_index,
    read_jsonl,
    replay_request,
    sha256_json,
    write_jsonl,
)

SUCCESS_SFT_SCHEMA = "harness-distill.success-sft.v1"
SFT_MANIFEST_SCHEMA = "harness-distill.sft-dataset-manifest.v1"


class SftDataError(ValueError):
    pass


def _completion(record: Mapping[str, Any]) -> dict[str, Any]:
    response = record.get("response")
    choices = response.get("choices") if isinstance(response, Mapping) else None
    if not isinstance(choices, list) or len(choices) != 1:
        raise SftDataError("successful proxy turn must have exactly one response choice")
    choice = choices[0]
    if not isinstance(choice, Mapping) or not isinstance(choice.get("message"), Mapping):
        raise SftDataError("successful proxy turn has no assistant message")
    finish = choice.get("finish_reason")
    if finish not in {None, "stop", "tool_calls"}:
        raise SftDataError(f"successful proxy completion was truncated: {finish!r}")
    message = deepcopy(dict(choice["message"]))
    message.setdefault("role", "assistant")
    try:
        if infer_turn_index([message]) != 1:
            raise SftDataError("proxy completion is not one assistant turn")
    except (MaterializationError, TypeError, ValueError) as exc:
        raise SftDataError(f"proxy completion is not replayable: {exc}") from exc
    if (
        message.get("content") in {None, ""}
        and message.get("reasoning_content") in {None, ""}
        and not message.get("tool_calls")
    ):
        raise SftDataError("proxy completion is empty")
    return message


def successful_trace_rows(
    proxy_records: Iterable[Mapping[str, Any]],
    *,
    session_id: str,
    split: str = "train",
) -> list[dict[str, Any]]:
    """Convert every causal decision in one evaluator-selected success trace.

    Selection by episode outcome happens outside this function.  Neither the
    outcome nor any evaluator field is copied into a training row.
    """

    rows: list[dict[str, Any]] = []
    last_sequence = -1
    for record_index, record in enumerate(proxy_records):
        if record.get("schema") != PROXY_TRACE_SCHEMA:
            raise SftDataError(f"proxy row {record_index} has an unsupported schema")
        if record.get("role", "student") != "student":
            continue
        status = record.get("status_code")
        if type(status) is not int or not 200 <= status < 300:
            raise SftDataError(f"proxy row {record_index} was not a successful model call")
        sequence = record.get("sequence")
        if type(sequence) is not int or sequence <= last_sequence:
            raise SftDataError("proxy sequence must be strictly increasing")
        last_sequence = sequence
        original = record.get("request")
        effective = record.get("effective_request")
        if not isinstance(original, Mapping) or not isinstance(effective, Mapping):
            raise SftDataError("successful proxy turn requires original and effective requests")
        original_hash = sha256_json(original)
        effective_hash = sha256_json(effective)
        if record.get("request_sha256") != original_hash:
            raise SftDataError("successful proxy turn original request hash mismatch")
        if record.get("effective_request_sha256") != effective_hash:
            raise SftDataError("successful proxy turn effective request hash mismatch")
        try:
            original_request = replay_request(original)
            request = replay_request(effective)
        except MaterializationError as exc:
            raise SftDataError(f"successful proxy request is not replayable: {exc}") from exc
        if infer_turn_index(original_request["messages"]) != infer_turn_index(request["messages"]):
            raise SftDataError("effective request changes the causal assistant-turn index")
        completion = _completion(record)
        messages = [*deepcopy(request["messages"]), completion]
        tools = deepcopy(request.get("tools", []))
        row_id = hashlib.sha256(
            f"{session_id}:{sequence}:{sha256_json(messages)}".encode()
        ).hexdigest()
        row = {
            "schema": SUCCESS_SFT_SCHEMA,
            "label_id": row_id,
            "split": split,
            "session_sha256": session_id,
            "source_sequence": sequence,
            "source_turn_index": infer_turn_index(request["messages"]),
            "original_request_sha256": original_hash,
            "effective_request_sha256": effective_hash,
            "messages": messages,
            "tools": tools,
            "tool_choice": deepcopy(request.get("tool_choice")),
            "parallel_tool_calls": deepcopy(request.get("parallel_tool_calls")),
            "response_format": deepcopy(request.get("response_format")),
            "prompt_message_count": len(request["messages"]),
            "student_prompt_sha256": sha256_json({"messages": request["messages"], "tools": tools}),
            "completion_sha256": sha256_json(completion),
        }
        serialized_student = canonical_json(
            {"messages": row["messages"][:-1], "tools": row["tools"]}
        ).casefold()
        if any(
            forbidden in serialized_student
            for forbidden in ("privileged_context", "<public-derived-phase-state>")
        ):
            raise SftDataError("teacher-only state entered a successful SFT prompt")
        rows.append(row)
    if not rows:
        raise SftDataError("successful trajectory contains no trainable model decisions")
    return rows


def _successful_summary(path: Path) -> bool:
    value = json.loads(path.read_text(encoding="utf-8"))
    return value.get("success") is True and value.get("outcome") in {
        "optimal",
        "accepted",
        "abstained",
    }


def rows_from_successful_runs(
    run_roots: Iterable[str | Path],
    *,
    split: str = "train",
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    episodes: list[dict[str, Any]] = []
    seen_labels: set[str] = set()
    for raw_root in run_roots:
        root = Path(raw_root)
        run_dirs = [root] if (root / "summary.json").is_file() else sorted(root.glob("*"))
        for run_dir in run_dirs:
            summary = run_dir / "summary.json"
            trace = run_dir / "model_requests.jsonl"
            if not summary.is_file() or not trace.is_file() or not _successful_summary(summary):
                continue
            session = hashlib.sha256(run_dir.name.encode("utf-8")).hexdigest()
            episode_rows = successful_trace_rows(read_jsonl(trace), session_id=session, split=split)
            for row in episode_rows:
                if row["label_id"] in seen_labels:
                    raise SftDataError(f"duplicate successful SFT label: {row['label_id']}")
                seen_labels.add(row["label_id"])
            rows.extend(episode_rows)
            episodes.append(
                {
                    "run": run_dir.name,
                    "session_sha256": session,
                    "decision_count": len(episode_rows),
                    "trace_sha256": hashlib.sha256(trace.read_bytes()).hexdigest(),
                }
            )
    return rows, episodes


def build_sft_jsonl(
    successful_run_roots: Iterable[str | Path],
    corrective_rows: Sequence[Mapping[str, Any]],
    output_dir: str | Path,
    *,
    split: str = "train",
) -> dict[str, Any]:
    """Write a generic HF JSON split plus an audit manifest.

    PRIME consumes only ``messages`` and ``tools``.  Provenance columns remain
    non-model metadata and are retained for post-hoc auditing.
    """

    successful, episodes = rows_from_successful_runs(successful_run_roots, split=split)
    corrections = [deepcopy(dict(row)) for row in corrective_rows if row.get("split") == split]
    label_ids: set[str] = set()
    combined: list[dict[str, Any]] = []
    for row in [*successful, *corrections]:
        if not isinstance(row.get("messages"), list) or not row["messages"]:
            raise SftDataError("SFT row has no messages")
        if row["messages"][-1].get("role") != "assistant":
            raise SftDataError("SFT row does not end in an assistant completion")
        if "privileged_context" in canonical_json(
            {"messages": row["messages"], "tools": row.get("tools", [])}
        ):
            raise SftDataError("privileged context entered model-visible SFT columns")
        label = row.get("label_id")
        if not isinstance(label, str) or not label or label in label_ids:
            raise SftDataError("SFT label IDs must be unique non-empty strings")
        label_ids.add(label)
        combined.append(row)
    if not combined:
        raise SftDataError("SFT dataset would be empty")

    destination = Path(output_dir).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    data_path = destination / f"{split}.jsonl"
    write_jsonl(data_path, combined)
    data_hash = hashlib.sha256(data_path.read_bytes()).hexdigest()
    manifest = {
        "schema": SFT_MANIFEST_SCHEMA,
        "split": split,
        "path": str(data_path),
        "sha256": data_hash,
        "row_count": len(combined),
        "successful_episode_count": len(episodes),
        "successful_decision_count": len(successful),
        "corrective_decision_count": len(corrections),
        "assistant_tokens_only": True,
        "privileged_context_in_model_columns": False,
        "episodes": episodes,
    }
    (destination / f"{split}.manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return manifest
