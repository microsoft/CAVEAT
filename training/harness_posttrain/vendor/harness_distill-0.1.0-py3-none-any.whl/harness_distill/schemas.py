"""Versioned, deterministic schemas for harness-distillation training tasks.

The serialized task contains both an agent-facing storefront description and an
``oracle`` block used only by dataset validation and rewards.  Consumers must use
``TrainingTaskSpec.agent_view()`` when constructing anything agent-reachable.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
SPLITS = frozenset({"train", "validation", "test"})
TASK_MODES = frozenset({"best_available", "satisfice", "no_qualified"})
CONDITIONS = frozenset({"clean", "truthful_steered"})
OBJECTIVE_DIRECTIONS = frozenset({"higher", "lower"})
CONSTRAINT_OPERATORS = frozenset({"eq", "le", "ge"})
PAIR_MEMBERS = frozenset({"original", "reversed"})
BADGE_KINDS = frozenset({"sponsored", "deal", "best_seller", "top_rated", "lowest_price"})


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def canonical_json(value: Any) -> str:
    """Return the canonical JSON encoding used for IDs, hashes, and JSONL."""

    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def stable_id(prefix: str, value: Any, *, length: int = 20) -> str:
    digest = sha256(canonical_json(value).encode("utf-8")).hexdigest()[:length]
    return f"{prefix}_{digest}"


@dataclass(frozen=True)
class CatalogItem:
    """One truthful marketplace option.

    ``facts`` holds the task-specific specifications.  Commerce fields are
    explicit so merchandising badges can be mechanically truth-checked.
    """

    item_id: str
    title: str
    facts: Mapping[str, Any]
    price: float
    list_price: float
    rating: float
    review_count: int
    purchases: int

    def __post_init__(self) -> None:
        _require(bool(self.item_id), "catalog item_id must be non-empty")
        _require(bool(self.title), f"{self.item_id}: title must be non-empty")
        _require("price" not in self.facts, f"{self.item_id}: price is a reserved fact")
        _require(self.price >= 0, f"{self.item_id}: price must be non-negative")
        _require(
            self.list_price + 1e-9 >= self.price,
            f"{self.item_id}: list_price cannot be below the actual price",
        )
        _require(0 <= self.rating <= 5, f"{self.item_id}: rating must be in [0, 5]")
        _require(self.review_count >= 0, f"{self.item_id}: review_count must be non-negative")
        _require(self.purchases >= 0, f"{self.item_id}: purchases must be non-negative")
        for key, value in self.facts.items():
            _require(bool(key), f"{self.item_id}: fact keys must be non-empty")
            _require(
                value is None or isinstance(value, (str, int, float, bool)),
                f"{self.item_id}: fact {key!r} must be a JSON scalar",
            )

    def value(self, field_name: str) -> Any:
        if field_name == "price":
            return self.price
        if field_name == "list_price":
            return self.list_price
        if field_name == "rating":
            return self.rating
        if field_name == "review_count":
            return self.review_count
        if field_name == "purchases":
            return self.purchases
        return self.facts.get(field_name)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> CatalogItem:
        return cls(
            item_id=str(data["item_id"]),
            title=str(data["title"]),
            facts=dict(data.get("facts", {})),
            price=float(data["price"]),
            list_price=float(data["list_price"]),
            rating=float(data["rating"]),
            review_count=int(data["review_count"]),
            purchases=int(data["purchases"]),
        )


@dataclass(frozen=True)
class HardConstraint:
    field: str
    operator: str
    value: Any
    label: str
    unit: str = ""

    def __post_init__(self) -> None:
        _require(bool(self.field), "constraint field must be non-empty")
        _require(self.operator in CONSTRAINT_OPERATORS, f"unsupported operator {self.operator!r}")
        _require(bool(self.label), f"{self.field}: constraint label must be non-empty")

    def satisfied_by(self, item: CatalogItem) -> bool:
        actual = item.value(self.field)
        if actual is None:
            return False
        if self.operator == "eq":
            return actual == self.value
        try:
            if self.operator == "le":
                return actual <= self.value
            return actual >= self.value
        except TypeError:
            return False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> HardConstraint:
        return cls(**dict(data))


@dataclass(frozen=True)
class Objective:
    field: str
    label: str
    direction: str
    unit: str = ""
    weight: float | None = None
    priority: int | None = None

    def __post_init__(self) -> None:
        _require(bool(self.field), "objective field must be non-empty")
        _require(bool(self.label), f"{self.field}: objective label must be non-empty")
        _require(
            self.direction in OBJECTIVE_DIRECTIONS,
            f"unsupported direction {self.direction!r}",
        )
        if self.weight is not None:
            _require(self.weight > 0, f"{self.field}: objective weight must be positive")
        if self.priority is not None:
            _require(self.priority >= 1, f"{self.field}: priority must be >= 1")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Objective:
        return cls(**dict(data))


@dataclass(frozen=True)
class SteeringCue:
    """A merchandising cue whose label is mechanically auditable."""

    item_id: str
    kind: str
    label: str

    def __post_init__(self) -> None:
        _require(self.kind in BADGE_KINDS, f"unsupported steering cue {self.kind!r}")
        _require(bool(self.item_id), "steering cue item_id must be non-empty")
        _require(bool(self.label), "steering cue label must be non-empty")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SteeringCue:
        return cls(**dict(data))


@dataclass(frozen=True)
class SteeringSpec:
    condition: str
    default_order: tuple[str, ...]
    cues: tuple[SteeringCue, ...] = ()
    disclosure: str = ""

    def __post_init__(self) -> None:
        _require(self.condition in CONDITIONS, f"unsupported condition {self.condition!r}")
        _require(
            len(set(self.default_order)) == len(self.default_order),
            "default_order contains duplicates",
        )
        if self.condition == "clean":
            _require(not self.cues, "clean condition cannot contain merchandising cues")

    def to_dict(self) -> dict[str, Any]:
        return {
            "condition": self.condition,
            "default_order": list(self.default_order),
            "cues": [cue.to_dict() for cue in self.cues],
            "disclosure": self.disclosure,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SteeringSpec:
        return cls(
            condition=str(data["condition"]),
            default_order=tuple(str(item_id) for item_id in data["default_order"]),
            cues=tuple(SteeringCue.from_dict(cue) for cue in data.get("cues", [])),
            disclosure=str(data.get("disclosure", "")),
        )


@dataclass(frozen=True)
class OracleSpec:
    """Evaluator-only outcome definition.

    A comparative task has one ``optimal_item_id``.  A satisficing task has no
    artificial optimum: every feasible item is accepted.  A no-qualified task
    accepts only abstention and therefore has neither accepted nor optimal IDs.
    """

    feasible_item_ids: tuple[str, ...]
    accepted_item_ids: tuple[str, ...]
    optimal_item_id: str | None
    utility_by_item: Mapping[str, float]
    failure_reasons: Mapping[str, tuple[str, ...]]
    visibility: str = "evaluator_only"

    def __post_init__(self) -> None:
        _require(
            self.visibility == "evaluator_only",
            "oracle visibility must remain evaluator_only",
        )
        _require(
            len(set(self.feasible_item_ids)) == len(self.feasible_item_ids),
            "oracle feasible_item_ids contains duplicates",
        )
        _require(
            len(set(self.accepted_item_ids)) == len(self.accepted_item_ids),
            "oracle accepted_item_ids contains duplicates",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "feasible_item_ids": list(self.feasible_item_ids),
            "accepted_item_ids": list(self.accepted_item_ids),
            "optimal_item_id": self.optimal_item_id,
            "utility_by_item": dict(self.utility_by_item),
            "failure_reasons": {
                item_id: list(reasons) for item_id, reasons in self.failure_reasons.items()
            },
            "visibility": self.visibility,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OracleSpec:
        return cls(
            feasible_item_ids=tuple(str(v) for v in data.get("feasible_item_ids", [])),
            accepted_item_ids=tuple(str(v) for v in data.get("accepted_item_ids", [])),
            optimal_item_id=(
                None if data.get("optimal_item_id") is None else str(data["optimal_item_id"])
            ),
            utility_by_item={str(k): float(v) for k, v in data.get("utility_by_item", {}).items()},
            failure_reasons={
                str(k): tuple(str(reason) for reason in reasons)
                for k, reasons in data.get("failure_reasons", {}).items()
            },
            visibility=str(data.get("visibility", "evaluator_only")),
        )


@dataclass(frozen=True)
class TrainingTaskSpec:
    schema_version: int
    task_id: str
    seed: int
    split: str
    domain_family: str
    layout_family: str
    template_family: str
    mode: str
    condition: str
    instruction: str
    catalog: tuple[CatalogItem, ...]
    hard_constraints: tuple[HardConstraint, ...]
    objectives: tuple[Objective, ...]
    objective_order: tuple[str, ...]
    page_size: int
    visible_total: int
    steering: SteeringSpec
    oracle: OracleSpec
    pair_id: str | None = None
    pair_member: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _require(self.schema_version == SCHEMA_VERSION, "unsupported task schema version")
        _require(bool(self.task_id), "task_id must be non-empty")
        _require(self.seed >= 0, "seed must be non-negative")
        _require(self.split in SPLITS, f"unsupported split {self.split!r}")
        _require(self.mode in TASK_MODES, f"unsupported task mode {self.mode!r}")
        _require(self.condition in CONDITIONS, f"unsupported condition {self.condition!r}")
        _require(self.condition == self.steering.condition, "task and steering conditions differ")
        _require(bool(self.instruction), "instruction must be non-empty")
        _require(len(self.catalog) >= 2, "catalog must contain at least two items")
        _require(self.page_size >= 1, "page_size must be positive")
        _require(self.visible_total == len(self.catalog), "visible_total must equal catalog size")

        item_ids = tuple(item.item_id for item in self.catalog)
        item_set = set(item_ids)
        _require(len(item_set) == len(item_ids), "catalog item IDs must be unique")
        _require(
            set(self.steering.default_order) == item_set,
            "default_order must be a catalog permutation",
        )
        _require(
            all(cue.item_id in item_set for cue in self.steering.cues),
            "steering cue references an unknown item",
        )

        objective_fields = tuple(objective.field for objective in self.objectives)
        _require(
            len(set(objective_fields)) == len(objective_fields),
            "objective fields must be unique",
        )
        _require(
            self.objective_order == objective_fields,
            "objective_order must match the serialized objective order",
        )
        if self.mode == "best_available":
            _require(bool(self.objectives), "best_available tasks require objectives")
            _require(self.oracle.optimal_item_id is not None, "best_available task has no optimum")
            _require(
                self.oracle.accepted_item_ids == (self.oracle.optimal_item_id,),
                "best_available tasks accept exactly the unique optimum",
            )
        elif self.mode == "satisfice":
            _require(not self.objectives, "satisfice tasks must not contain comparative objectives")
            _require(
                self.oracle.optimal_item_id is None,
                "satisfice task must not invent an optimum",
            )
            _require(
                bool(self.oracle.accepted_item_ids),
                "satisfice task must accept a feasible item",
            )
        else:
            _require(
                not self.objectives,
                "no_qualified tasks must not contain comparative objectives",
            )
            _require(not self.oracle.feasible_item_ids, "no_qualified task contains feasible items")
            _require(not self.oracle.accepted_item_ids, "no_qualified task cannot accept an item")
            _require(
                self.oracle.optimal_item_id is None,
                "no_qualified task cannot have an optimum",
            )

        _require(
            set(self.oracle.feasible_item_ids).issubset(item_set),
            "oracle feasible_item_ids contains an unknown item",
        )
        _require(
            set(self.oracle.accepted_item_ids).issubset(item_set),
            "oracle accepted_item_ids contains an unknown item",
        )
        _require(
            set(self.oracle.utility_by_item) == item_set,
            "oracle utilities must cover the catalog",
        )
        _require(
            set(self.oracle.failure_reasons) == item_set,
            "oracle failures must cover the catalog",
        )

        if self.pair_id is None:
            _require(self.pair_member is None, "pair_member requires pair_id")
        else:
            _require(
                self.pair_member in PAIR_MEMBERS,
                "paired tasks require original/reversed member",
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "task_id": self.task_id,
            "seed": self.seed,
            "split": self.split,
            "domain_family": self.domain_family,
            "layout_family": self.layout_family,
            "template_family": self.template_family,
            "mode": self.mode,
            "condition": self.condition,
            "instruction": self.instruction,
            "catalog": [item.to_dict() for item in self.catalog],
            "hard_constraints": [constraint.to_dict() for constraint in self.hard_constraints],
            "objectives": [objective.to_dict() for objective in self.objectives],
            "objective_order": list(self.objective_order),
            "page_size": self.page_size,
            "visible_total": self.visible_total,
            "steering": self.steering.to_dict(),
            "oracle": self.oracle.to_dict(),
            "pair_id": self.pair_id,
            "pair_member": self.pair_member,
            "metadata": dict(self.metadata),
        }

    def agent_view(self) -> dict[str, Any]:
        """Return only data that may be used to render an agent-facing task.

        Structured constraints and objectives are omitted as well as the oracle;
        the agent receives their natural-language expression in ``instruction``.
        """

        return {
            "schema_version": self.schema_version,
            "task_id": self.task_id,
            "instruction": self.instruction,
            "domain_family": self.domain_family,
            "layout_family": self.layout_family,
            "catalog": [item.to_dict() for item in self.catalog],
            "page_size": self.page_size,
            "visible_total": self.visible_total,
            "steering": self.steering.to_dict(),
        }

    def to_json(self) -> str:
        return canonical_json(self.to_dict())

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TrainingTaskSpec:
        return cls(
            schema_version=int(data["schema_version"]),
            task_id=str(data["task_id"]),
            seed=int(data["seed"]),
            split=str(data["split"]),
            domain_family=str(data["domain_family"]),
            layout_family=str(data["layout_family"]),
            template_family=str(data["template_family"]),
            mode=str(data["mode"]),
            condition=str(data["condition"]),
            instruction=str(data["instruction"]),
            catalog=tuple(CatalogItem.from_dict(item) for item in data["catalog"]),
            hard_constraints=tuple(
                HardConstraint.from_dict(constraint) for constraint in data["hard_constraints"]
            ),
            objectives=tuple(Objective.from_dict(objective) for objective in data["objectives"]),
            objective_order=tuple(str(field_name) for field_name in data["objective_order"]),
            page_size=int(data["page_size"]),
            visible_total=int(data["visible_total"]),
            steering=SteeringSpec.from_dict(data["steering"]),
            oracle=OracleSpec.from_dict(data["oracle"]),
            pair_id=None if data.get("pair_id") is None else str(data["pair_id"]),
            pair_member=None if data.get("pair_member") is None else str(data["pair_member"]),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_json(cls, payload: str) -> TrainingTaskSpec:
        decoded = json.loads(payload)
        _require(isinstance(decoded, dict), "task JSON must contain an object")
        return cls.from_dict(decoded)


def write_tasks_jsonl(path: str | Path, tasks: Iterable[TrainingTaskSpec]) -> str:
    """Write canonical JSONL and return its SHA-256 digest."""

    target = Path(path)
    hasher = sha256()
    with target.open("w", encoding="utf-8", newline="\n") as stream:
        for task in tasks:
            line = task.to_json() + "\n"
            stream.write(line)
            hasher.update(line.encode("utf-8"))
    return hasher.hexdigest()


def read_tasks_jsonl(path: str | Path) -> tuple[TrainingTaskSpec, ...]:
    tasks: list[TrainingTaskSpec] = []
    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, raw_line in enumerate(stream, start=1):
            line = raw_line.strip()
            if not line:
                continue
            try:
                tasks.append(TrainingTaskSpec.from_json(line))
            except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
                raise ValueError(f"invalid task JSONL at line {line_number}: {exc}") from exc
    return tuple(tasks)


def tasks_sha256(tasks: Sequence[TrainingTaskSpec]) -> str:
    hasher = sha256()
    for task in tasks:
        hasher.update((task.to_json() + "\n").encode("utf-8"))
    return hasher.hexdigest()
