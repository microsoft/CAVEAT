"""Merge and numerically verify a Qwen PEFT/PRIME checkpoint.

The verifier refuses a merely well-formed checkpoint: a successful result must
change deterministic logits relative to the exact base revision, reproduce the
adapter's logits within tolerance, reload as a complete Hugging Face model, and
retain the original processor, tokenizer, and chat template.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import shutil
import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .model_smoke import (
    ModelSmokeError,
    _chat_template_sha256,
    _load_model,
    _load_processor_tokenizer,
    _prompt_tensors,
    assert_runtime_dependencies,
    load_model_snapshot,
    snapshot_download_exact,
)


class MergeVerificationError(ModelSmokeError):
    pass


@dataclass(frozen=True)
class LogitMetrics:
    base_adapter_max_abs: float
    base_merged_max_abs: float
    adapter_merged_max_abs: float
    merged_reload_max_abs: float
    adapter_abs_max: float
    merged_abs_max: float


@dataclass(frozen=True)
class BehavioralEquivalenceMetrics:
    """Distribution-level evidence that a BF16 merge preserves adapter behavior."""

    base_adapter_relative_l2: float
    adapter_merged_relative_l2: float
    relative_l2_error_ratio: float
    base_adapter_symmetric_kl: float
    adapter_merged_symmetric_kl: float
    symmetric_kl_error_ratio: float
    adapter_merged_cosine: float
    adapter_merged_top5_overlap: float
    adapter_merged_argmax_equal: bool


def checkpoint_kind(path: str | Path) -> str:
    """Classify a PEFT adapter or a complete Hugging Face checkpoint."""

    root = Path(path)
    if not root.is_dir():
        raise MergeVerificationError(f"checkpoint directory does not exist: {root}")
    if (root / "adapter_config.json").is_file():
        adapter_weights = list(root.glob("adapter_model*.safetensors")) + list(
            root.glob("adapter_model*.bin")
        )
        if not adapter_weights:
            raise MergeVerificationError("PEFT adapter has no adapter weight file")
        return "peft_adapter"
    full_weights = (
        list(root.glob("*.safetensors"))
        + list(root.glob("pytorch_model*.bin"))
        + list(root.glob("*.safetensors.index.json"))
    )
    if (root / "config.json").is_file() and full_weights:
        return "merged_hf"
    raise MergeVerificationError(
        "checkpoint is neither a PEFT adapter nor a complete merged Hugging Face model"
    )


def validate_logit_metrics(
    metrics: LogitMetrics,
    *,
    nonnoop_atol: float,
    reload_atol: float,
    reload_rtol: float,
) -> None:
    """Pure guard for non-noop and lossless save/reload checks."""

    if metrics.base_adapter_max_abs <= nonnoop_atol:
        raise MergeVerificationError("adapter is a numerical no-op relative to base")
    if metrics.base_merged_max_abs <= nonnoop_atol:
        raise MergeVerificationError("merged checkpoint is a numerical no-op relative to base")
    reload_limit = reload_atol + reload_rtol * metrics.merged_abs_max
    if metrics.merged_reload_max_abs > reload_limit:
        raise MergeVerificationError("saved and reloaded merged logits exceed reload tolerance")


def validate_behavioral_equivalence(
    metrics: BehavioralEquivalenceMetrics,
    *,
    max_relative_l2: float,
    min_cosine: float,
    max_symmetric_kl: float,
    min_top5_overlap: float,
    max_error_ratio: float,
) -> None:
    """Fail closed unless the merged BF16 model preserves adapter behavior.

    A PEFT adapter applies its low-rank update as a separate operation, while a
    deployable BF16 merge first rounds that update into each BF16 base weight.
    Elementwise logit equality is therefore not expected.  This guard instead
    requires close logit geometry and next-token distributions, plus errors
    substantially smaller than the adapter's real change from the base model.
    """

    numeric = {
        key: value
        for key, value in asdict(metrics).items()
        if key != "adapter_merged_argmax_equal"
    }
    if any(not math.isfinite(float(value)) for value in numeric.values()):
        raise MergeVerificationError("behavioral equivalence metrics are non-finite")
    if metrics.adapter_merged_relative_l2 > max_relative_l2:
        raise MergeVerificationError("adapter and merged relative-L2 error exceeds tolerance")
    if metrics.adapter_merged_cosine < min_cosine:
        raise MergeVerificationError("adapter and merged logit cosine is below tolerance")
    if metrics.adapter_merged_symmetric_kl > max_symmetric_kl:
        raise MergeVerificationError("adapter and merged symmetric KL exceeds tolerance")
    if metrics.adapter_merged_top5_overlap < min_top5_overlap:
        raise MergeVerificationError("adapter and merged top-5 overlap is below tolerance")
    if metrics.relative_l2_error_ratio > max_error_ratio:
        raise MergeVerificationError(
            "merge relative-L2 error is not sufficiently below the adapter's base change"
        )
    if metrics.symmetric_kl_error_ratio > max_error_ratio:
        raise MergeVerificationError(
            "merge symmetric-KL error is not sufficiently below the adapter's base change"
        )


def _finite_ratio(numerator: float, denominator: float) -> float:
    if denominator > 0.0:
        return numerator / denominator
    return 0.0 if numerator == 0.0 else math.inf


def behavioral_equivalence_metrics(
    base_logits: Any,
    adapter_logits: Any,
    merged_logits: Any,
) -> BehavioralEquivalenceMetrics:
    """Compute deterministic BF16-appropriate merge evidence in FP32."""

    import torch
    import torch.nn.functional as functional

    base = base_logits.detach().float().reshape(-1)
    adapter = adapter_logits.detach().float().reshape(-1)
    merged = merged_logits.detach().float().reshape(-1)
    if base.shape != adapter.shape or adapter.shape != merged.shape or adapter.numel() == 0:
        raise MergeVerificationError("merge logits have incompatible shapes")
    if not all(torch.isfinite(value).all() for value in (base, adapter, merged)):
        raise MergeVerificationError("merge logits contain non-finite values")

    def relative_l2(reference: Any, candidate: Any) -> float:
        numerator = float(torch.linalg.vector_norm(reference - candidate))
        denominator = float(torch.linalg.vector_norm(reference))
        return _finite_ratio(numerator, denominator)

    def symmetric_kl(left: Any, right: Any) -> float:
        left_log_probability = functional.log_softmax(left, dim=0)
        right_log_probability = functional.log_softmax(right, dim=0)
        left_probability = left_log_probability.exp()
        right_probability = right_log_probability.exp()
        value = 0.5 * (
            torch.sum(left_probability * (left_log_probability - right_log_probability))
            + torch.sum(right_probability * (right_log_probability - left_log_probability))
        )
        # Roundoff may put a mathematically non-negative divergence just below zero.
        return max(0.0, float(value))

    base_adapter_l2 = relative_l2(base, adapter)
    adapter_merged_l2 = relative_l2(adapter, merged)
    base_adapter_kl = symmetric_kl(base, adapter)
    adapter_merged_kl = symmetric_kl(adapter, merged)
    top_k = min(5, adapter.numel())
    adapter_top = set(adapter.topk(top_k).indices.tolist())
    merged_top = set(merged.topk(top_k).indices.tolist())
    return BehavioralEquivalenceMetrics(
        base_adapter_relative_l2=base_adapter_l2,
        adapter_merged_relative_l2=adapter_merged_l2,
        relative_l2_error_ratio=_finite_ratio(adapter_merged_l2, base_adapter_l2),
        base_adapter_symmetric_kl=base_adapter_kl,
        adapter_merged_symmetric_kl=adapter_merged_kl,
        symmetric_kl_error_ratio=_finite_ratio(adapter_merged_kl, base_adapter_kl),
        adapter_merged_cosine=float(
            functional.cosine_similarity(adapter, merged, dim=0, eps=1e-12)
        ),
        adapter_merged_top5_overlap=len(adapter_top & merged_top) / top_k,
        adapter_merged_argmax_equal=bool(adapter.argmax() == merged.argmax()),
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def checkpoint_manifest(path: str | Path) -> dict[str, dict[str, Any]]:
    root = Path(path).resolve()
    result: dict[str, dict[str, Any]] = {}
    for candidate in sorted(item for item in root.rglob("*") if item.is_file()):
        if candidate.name == "merge_provenance.json":
            continue
        result[str(candidate.relative_to(root))] = {
            "size": candidate.stat().st_size,
            "sha256": _sha256(candidate),
        }
    return result


def _prepare_output(path: str | Path) -> Path:
    target = Path(path).resolve()
    if target.exists() and any(target.iterdir()):
        raise MergeVerificationError(f"output directory must be absent or empty: {target}")
    target.mkdir(parents=True, exist_ok=True)
    return target


def _logits(model: Any, inputs: Mapping[str, Any]) -> Any:
    import torch

    model.eval()
    with torch.no_grad():
        logits = model(**inputs).logits[:, -1, :].detach().float().cpu()
    if not torch.isfinite(logits).all():
        raise MergeVerificationError("checkpoint produced non-finite deterministic logits")
    return logits


def _collect(*, cuda: bool) -> None:
    gc.collect()
    if cuda:
        import torch

        torch.cuda.empty_cache()


def _validate_adapter_base(adapter_path: Path, model_id: str, snapshot_path: Path) -> None:
    config = json.loads((adapter_path / "adapter_config.json").read_text(encoding="utf-8"))
    declared = str(config.get("base_model_name_or_path", ""))
    allowed = {model_id, str(snapshot_path), str(snapshot_path.resolve())}
    if declared and declared not in allowed:
        raise MergeVerificationError(
            f"adapter declares a different base model {declared!r}; expected {model_id!r}"
        )
    declared_revision = config.get("revision")
    if declared_revision is not None and str(declared_revision) != snapshot_path.name:
        raise MergeVerificationError("adapter revision does not match the selected exact snapshot")


def _verify_and_merge_into(
    model_config: str | Path,
    adapter_path: str | Path,
    output_dir: str | Path,
    *,
    role: str = "primary",
    prime_merged_path: str | Path | None = None,
    device: str = "cuda:0",
    hf_token: str | None = None,
    nonnoop_atol: float = 1e-7,
    nonnoop_rtol: float = 1e-6,
    max_relative_l2: float = 0.10,
    min_cosine: float = 0.99,
    max_symmetric_kl: float = 0.01,
    min_top5_overlap: float = 0.8,
    max_error_ratio: float = 0.5,
    reload_atol: float = 5e-2,
    reload_rtol: float = 5e-3,
    published_output_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Merge PEFT weights or validate a PRIME-exported complete HF model.

    ``adapter_path`` may be a PEFT adapter or PRIME's already-merged complete HF
    export.  When ``prime_merged_path`` is supplied alongside PEFT, it is checked
    instead of producing a fresh merge.  Optimizer/FSDP shards are rejected.
    """

    runtime = assert_runtime_dependencies(require_cuda=device.startswith("cuda"))
    snapshot = load_model_snapshot(model_config, role=role)
    token = hf_token or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    snapshot_path = snapshot_download_exact(snapshot, token=token)
    adapter = Path(adapter_path).resolve()
    training_kind = checkpoint_kind(adapter)
    if training_kind == "peft_adapter":
        _validate_adapter_base(adapter, snapshot.model_id, snapshot_path)
    candidate = Path(prime_merged_path).resolve() if prime_merged_path is not None else None
    if candidate is not None and checkpoint_kind(candidate) != "merged_hf":
        raise MergeVerificationError("PRIME output must first be exported as merged HF weights")
    if training_kind == "merged_hf" and candidate is not None:
        raise MergeVerificationError(
            "prime_merged_path is redundant when adapter_path is already merged HF"
        )
    destination = _prepare_output(output_dir)
    published_destination = (
        Path(published_output_dir).resolve()
        if published_output_dir is not None
        else destination
    )

    import torch
    from peft import PeftModel

    torch.manual_seed(20260807)
    processor, tokenizer = _load_processor_tokenizer(snapshot_path)
    processor_class = f"{type(processor).__module__}.{type(processor).__qualname__}"
    template_hash = _chat_template_sha256(tokenizer)
    inputs = _prompt_tensors(tokenizer, device=device)
    input_ids_hash = hashlib.sha256(
        inputs["input_ids"].detach().cpu().numpy().tobytes()
    ).hexdigest()
    cuda = device.startswith("cuda")

    base_model = _load_model(snapshot_path, device=device)
    base_logits = _logits(base_model, inputs)
    base_architectures = tuple(getattr(base_model.config, "architectures", ()) or ())
    del base_model
    _collect(cuda=cuda)

    if training_kind == "peft_adapter":
        adapter_base = _load_model(snapshot_path, device=device)
        adapter_model = PeftModel.from_pretrained(adapter_base, adapter, is_trainable=False)
        del adapter_base
    else:
        adapter_model = _load_model(adapter, device=device)
        trained_architectures = tuple(getattr(adapter_model.config, "architectures", ()) or ())
        if trained_architectures != base_architectures:
            raise MergeVerificationError(
                "PRIME checkpoint architecture differs from the exact base wrapper"
            )
    adapter_logits = _logits(adapter_model, inputs)
    if torch.allclose(
        base_logits,
        adapter_logits,
        atol=nonnoop_atol,
        rtol=nonnoop_rtol,
    ):
        raise MergeVerificationError("adapter logits are a numerical no-op relative to base")

    if training_kind == "merged_hf":
        merged_model = adapter_model
        del adapter_model
        merged_source = "prime_merged_hf"
    elif candidate is None:
        merged_model = adapter_model.merge_and_unload(safe_merge=True)
        del adapter_model
        merged_source = "peft_merge_and_unload"
    else:
        del adapter_model
        _collect(cuda=cuda)
        merged_model = _load_model(candidate, device=device)
        merged_source = "prime_merged_hf"
    merged_logits = _logits(merged_model, inputs)
    if torch.allclose(
        base_logits,
        merged_logits,
        atol=nonnoop_atol,
        rtol=nonnoop_rtol,
    ):
        raise MergeVerificationError("merged logits are a numerical no-op relative to base")
    behavioral_metrics = behavioral_equivalence_metrics(
        base_logits,
        adapter_logits,
        merged_logits,
    )
    validate_behavioral_equivalence(
        behavioral_metrics,
        max_relative_l2=max_relative_l2,
        min_cosine=min_cosine,
        max_symmetric_kl=max_symmetric_kl,
        min_top5_overlap=min_top5_overlap,
        max_error_ratio=max_error_ratio,
    )

    merged_model.save_pretrained(
        destination,
        safe_serialization=True,
        max_shard_size="10GB",
    )
    processor.save_pretrained(destination)
    tokenizer.save_pretrained(destination)
    del merged_model
    _collect(cuda=cuda)

    if checkpoint_kind(destination) != "merged_hf":
        raise MergeVerificationError("saved output is not a complete Hugging Face checkpoint")
    reload_processor, reload_tokenizer = _load_processor_tokenizer(destination)
    reload_processor_class = (
        f"{type(reload_processor).__module__}.{type(reload_processor).__qualname__}"
    )
    if reload_processor_class != processor_class:
        raise MergeVerificationError("merged checkpoint changed the processor class")
    if _chat_template_sha256(reload_tokenizer) != template_hash:
        raise MergeVerificationError("merged checkpoint did not preserve the chat template")
    del reload_processor
    reload_inputs = _prompt_tensors(reload_tokenizer, device=device)
    if not torch.equal(
        inputs["input_ids"].detach().cpu(),
        reload_inputs["input_ids"].detach().cpu(),
    ):
        raise MergeVerificationError("merged checkpoint changed deterministic input token IDs")
    reloaded = _load_model(destination, device=device)
    reload_architectures = tuple(getattr(reloaded.config, "architectures", ()) or ())
    if reload_architectures != base_architectures:
        raise MergeVerificationError("merged checkpoint changed the multimodal model architecture")
    reload_logits = _logits(reloaded, reload_inputs)
    if not torch.allclose(
        merged_logits,
        reload_logits,
        atol=reload_atol,
        rtol=reload_rtol,
    ):
        raise MergeVerificationError("saved/reloaded merged logits are not numerically equivalent")

    metrics = LogitMetrics(
        base_adapter_max_abs=float((base_logits - adapter_logits).abs().max()),
        base_merged_max_abs=float((base_logits - merged_logits).abs().max()),
        adapter_merged_max_abs=float((adapter_logits - merged_logits).abs().max()),
        merged_reload_max_abs=float((merged_logits - reload_logits).abs().max()),
        adapter_abs_max=float(adapter_logits.abs().max()),
        merged_abs_max=float(merged_logits.abs().max()),
    )
    # Tensor-level non-noop and reload checks remain authoritative.  This pure
    # scalar guard independently checks the compact provenance measurements.
    validate_logit_metrics(
        metrics,
        nonnoop_atol=nonnoop_atol,
        reload_atol=reload_atol,
        reload_rtol=reload_rtol,
    )
    del reloaded
    _collect(cuda=cuda)

    provenance = {
        "schema_version": 2,
        "status": "ok",
        "snapshot": asdict(snapshot),
        "resolved_snapshot": str(snapshot_path),
        "runtime": runtime,
        "training_checkpoint_kind": training_kind,
        "merge_source": merged_source,
        "adapter_path": str(adapter),
        "prime_merged_path": str(candidate) if candidate is not None else None,
        "output_dir": str(published_destination),
        "input_ids_sha256": input_ids_hash,
        "chat_template_sha256": template_hash,
        "processor_class": processor_class,
        "architectures": list(base_architectures),
        "tolerances": {
            "nonnoop_atol": nonnoop_atol,
            "nonnoop_rtol": nonnoop_rtol,
            "reload_atol": reload_atol,
            "reload_rtol": reload_rtol,
        },
        "logit_metrics": asdict(metrics),
        "behavioral_equivalence": {
            "metrics": asdict(behavioral_metrics),
            "thresholds": {
                "max_relative_l2": max_relative_l2,
                "min_cosine": min_cosine,
                "max_symmetric_kl": max_symmetric_kl,
                "min_top5_overlap": min_top5_overlap,
                "max_error_ratio": max_error_ratio,
            },
        },
        "adapter_manifest": checkpoint_manifest(adapter),
        "merged_manifest": checkpoint_manifest(destination),
        "launcher_provenance": {
            key: os.environ.get(key)
            for key in (
                "LAST_CONTAINER_IMAGE_DIGEST",
                "LAST_SOURCE_GIT_SHA",
                "LAST_CLUSTER_PRIORITY_REQUEST",
                "LAST_CLUSTER_PRIORITY_CLASS",
                "LAST_ALLOCATED_GPUS",
            )
        },
    }
    (destination / "merge_provenance.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return provenance


def _completed_merge(
    model_config: str | Path,
    adapter_path: str | Path,
    output_dir: Path,
    *,
    role: str,
    prime_merged_path: str | Path | None,
) -> dict[str, Any] | None:
    """Validate a published merge left just before phase-marker creation."""

    provenance_path = output_dir / "merge_provenance.json"
    if not provenance_path.is_file():
        return None
    try:
        provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MergeVerificationError("published merge provenance is unreadable") from exc
    if not isinstance(provenance, dict):
        raise MergeVerificationError("published merge provenance is not an object")
    snapshot = load_model_snapshot(model_config, role=role)
    adapter = Path(adapter_path).resolve()
    candidate = Path(prime_merged_path).resolve() if prime_merged_path is not None else None
    expected = {
        "schema_version": 2,
        "status": "ok",
        "snapshot": asdict(snapshot),
        "adapter_path": str(adapter),
        "prime_merged_path": str(candidate) if candidate is not None else None,
        "output_dir": str(output_dir),
    }
    for key, value in expected.items():
        if provenance.get(key) != value:
            raise MergeVerificationError(f"published merge provenance changed: {key}")
    if provenance.get("adapter_manifest") != checkpoint_manifest(adapter):
        raise MergeVerificationError("published merge adapter bytes changed")
    if provenance.get("merged_manifest") != checkpoint_manifest(output_dir):
        raise MergeVerificationError("published merged checkpoint bytes changed")
    return provenance


def verify_and_merge(
    model_config: str | Path,
    adapter_path: str | Path,
    output_dir: str | Path,
    *,
    role: str = "primary",
    prime_merged_path: str | Path | None = None,
    device: str = "cuda:0",
    hf_token: str | None = None,
    nonnoop_atol: float = 1e-7,
    nonnoop_rtol: float = 1e-6,
    max_relative_l2: float = 0.10,
    min_cosine: float = 0.99,
    max_symmetric_kl: float = 0.01,
    min_top5_overlap: float = 0.8,
    max_error_ratio: float = 0.5,
    reload_atol: float = 5e-2,
    reload_rtol: float = 5e-3,
) -> dict[str, Any]:
    """Atomically verify and publish a complete merged checkpoint.

    Verification writes only to a unique sibling staging directory.  A normal
    exception removes that staging tree; a hard-kill orphan is harmless to a
    retry because the canonical destination remains absent.  If publication
    completed immediately before the phase marker was written, the exact input
    and output manifests are revalidated and reused without another GPU pass.
    """

    destination = Path(output_dir).resolve()
    if destination.exists():
        if not destination.is_dir():
            raise MergeVerificationError(f"merge output is not a directory: {destination}")
        if not any(destination.iterdir()):
            destination.rmdir()
        else:
            completed = _completed_merge(
                model_config,
                adapter_path,
                destination,
                role=role,
                prime_merged_path=prime_merged_path,
            )
            if completed is None:
                raise MergeVerificationError(
                    f"unattested merge output already exists: {destination}"
                )
            return completed

    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    try:
        provenance = _verify_and_merge_into(
            model_config,
            adapter_path,
            staging,
            role=role,
            prime_merged_path=prime_merged_path,
            device=device,
            hf_token=hf_token,
            nonnoop_atol=nonnoop_atol,
            nonnoop_rtol=nonnoop_rtol,
            max_relative_l2=max_relative_l2,
            min_cosine=min_cosine,
            max_symmetric_kl=max_symmetric_kl,
            min_top5_overlap=min_top5_overlap,
            max_error_ratio=max_error_ratio,
            reload_atol=reload_atol,
            reload_rtol=reload_rtol,
            published_output_dir=destination,
        )
        persisted = json.loads(
            (staging / "merge_provenance.json").read_text(encoding="utf-8")
        )
        if persisted != provenance or provenance.get("status") != "ok":
            raise MergeVerificationError("staged merge provenance is incomplete")
        staging.replace(destination)
        return provenance
    except BaseException:
        if staging.exists():
            shutil.rmtree(staging)
        raise


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-config", type=Path, required=True)
    parser.add_argument("--adapter", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--prime-merged", type=Path)
    parser.add_argument("--role", choices=("primary", "fallback"), default="primary")
    parser.add_argument("--device", default="cuda:0")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        report = verify_and_merge(
            args.model_config,
            args.adapter,
            args.output_dir,
            role=args.role,
            prime_merged_path=args.prime_merged,
            device=args.device,
        )
    except Exception as exc:  # noqa: BLE001 - CLI must serialize the failure
        print(json.dumps({"status": "error", "error": str(exc)}, sort_keys=True))
        return 2
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
