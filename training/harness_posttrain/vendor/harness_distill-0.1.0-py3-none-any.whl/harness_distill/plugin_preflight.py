"""Fail-closed Verifiers V1 loading check for the decision-replay plugin."""

from __future__ import annotations

import hashlib
import tempfile
from pathlib import Path
from typing import Any

from .materialize import MATERIALIZED_SCHEMA, canonical_json, sha256_json
from .shadow import (
    ClaimDerivation,
    EvidenceRef,
    PublicEvidence,
    PublicEvidenceSource,
    ShadowPhase,
    ShadowPhaseStateBuilder,
)

PLUGIN_ID = "decision-replay-v1"


def _fixture_row() -> dict[str, Any]:
    evidence = PublicEvidence(
        evidence_id="preflight-instruction",
        source=PublicEvidenceSource.USER_INSTRUCTION,
        turn_index=0,
        payload={"text": "Choose the best available option."},
    )
    builder = ShadowPhaseStateBuilder(0, [evidence])
    builder.claim(
        phase=ShadowPhase.CONTRACT,
        key="selection_rule",
        value="best available",
        evidence_refs=[EvidenceRef(evidence.evidence_id, ("text",))],
        derivation=ClaimDerivation.LITERAL_PARSE,
    )
    privilege = builder.build()
    request = {
        "messages": [
            {"role": "system", "content": "Use the browser tools."},
            {"role": "user", "content": "Choose the best available option."},
        ],
        "tools": [
            {
                "type": "function",
                "function": {
                    "name": "click",
                    "description": "Click one visible element.",
                    "parameters": {
                        "type": "object",
                        "properties": {"index": {"type": "integer"}},
                        "required": ["index"],
                    },
                },
            }
        ],
        "tool_choice": "auto",
        "parallel_tool_calls": False,
    }
    request_hash = sha256_json(request)
    return {
        "schema": MATERIALIZED_SCHEMA,
        "idx": 0,
        "replay_id": hashlib.sha256(b"decision-replay-plugin-preflight").hexdigest(),
        "split": "train",
        "session_sha256": hashlib.sha256(b"preflight-session").hexdigest(),
        "source_sequence": 0,
        "source_turn_index": 0,
        "request_sha256": request_hash,
        "request": request,
        "privileged_context": privilege.prompt_json(),
        "privilege_audit": privilege.audit.to_dict(),
        "reference_completion": None,
    }


def run_decision_replay_plugin_preflight() -> dict[str, Any]:
    """Resolve, instantiate, and load both Verifiers plugin specializations."""

    import verifiers.v1 as vf

    row = _fixture_row()
    with tempfile.TemporaryDirectory(prefix="decision-replay-preflight-") as temporary:
        replay_path = Path(temporary) / "replay.jsonl"
        replay_path.write_text(canonical_json(row) + "\n", encoding="utf-8")

        taskset_config_cls = vf.taskset_config_type(PLUGIN_ID)
        taskset_config = taskset_config_cls.model_validate(
            {"id": PLUGIN_ID, "path": str(replay_path), "split": "train", "limit": 1}
        )
        taskset = vf.load_taskset(taskset_config)
        tasks = taskset.load()

        harness_config_cls = vf.harness_config_type(PLUGIN_ID)
        harness_config = harness_config_cls.model_validate({"id": PLUGIN_ID})
        harness = vf.load_harness(harness_config)

    if taskset_config_cls.__name__ != "DecisionReplayTasksetConfig":
        raise RuntimeError("Verifiers resolved the wrong decision-replay taskset config")
    if harness_config_cls.__name__ != "DecisionReplayHarnessConfig":
        raise RuntimeError("Verifiers resolved the wrong decision-replay harness config")
    if type(taskset).__name__ != "DecisionReplayTaskset" or len(tasks) != 1:
        raise RuntimeError("decision-replay taskset did not load exactly one fixture task")
    if type(harness).__name__ != "DecisionReplayHarness":
        raise RuntimeError("decision-replay harness loaded the wrong implementation")
    data = tasks[0].data
    policy_request = data.request
    if "privileged_context" in policy_request or any(
        "privileged_context" in message for message in policy_request["messages"]
    ):
        raise RuntimeError("teacher-only privilege entered the policy request")
    if not isinstance(data.privileged_context, str) or not data.privileged_context:
        raise RuntimeError("teacher-only privilege was not retained on TaskData")
    if sha256_json(policy_request) != data.replay_request_sha256:
        raise RuntimeError("loaded policy request differs from its replay digest")

    return {
        "status": "ok",
        "plugin_id": PLUGIN_ID,
        "taskset_config_type": taskset_config_cls.__name__,
        "taskset_type": type(taskset).__name__,
        "loaded_tasks": len(tasks),
        "harness_config_type": harness_config_cls.__name__,
        "harness_type": type(harness).__name__,
        "policy_request_sha256": data.replay_request_sha256,
        "privilege_in_policy_request": False,
        "privilege_retained_on_task_data": True,
        "training_sample_smoke": "not_run",
        "training_sample_limitation": (
            "TrainingSample construction requires a token-bearing vf.Trace from a live "
            "renderer/inference rollout; the CPU container preflight intentionally stops "
            "before model execution"
        ),
    }
