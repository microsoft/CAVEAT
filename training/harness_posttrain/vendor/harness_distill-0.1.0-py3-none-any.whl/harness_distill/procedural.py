"""Deterministic, truthful finite-choice task generation.

This module intentionally has no dependency on the benchmark environments.  It
creates separate procedural domains for training the general search-and-commit
policy while keeping the Amazon five-product evaluation sealed.
"""

from __future__ import annotations

import math
import random
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, replace

from .schemas import (
    CONDITIONS,
    SCHEMA_VERSION,
    TASK_MODES,
    CatalogItem,
    HardConstraint,
    Objective,
    OracleSpec,
    SteeringCue,
    SteeringSpec,
    TrainingTaskSpec,
    stable_id,
)
from .split import (
    DOMAIN_FAMILIES,
    LAYOUT_FAMILIES,
    TEMPLATE_FAMILIES,
    layout_archetype,
    split_fingerprint,
    template_style,
    validate_assignment,
)

GENERATOR_VERSION = "2.0"
DEFAULT_CATALOG_SIZES = (16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512)
MODE_WEIGHTS = {"best_available": 0.75, "satisfice": 0.15, "no_qualified": 0.10}


@dataclass(frozen=True)
class AttributeRule:
    field: str
    label: str
    unit: str
    direction: str
    low: float
    high: float
    digits: int


@dataclass(frozen=True)
class DomainInfo:
    family: str
    market_kind: str
    item_noun: str
    attributes: tuple[AttributeRule, ...]


_PRODUCT_ATTRIBUTES = (
    AttributeRule("quality_score", "quality score", "points", "higher", 55, 96, 1),
    AttributeRule("capacity_score", "usable capacity", "points", "higher", 20, 95, 1),
    AttributeRule("operating_noise_db", "operating noise", "dB", "lower", 28, 72, 1),
    AttributeRule("weight_kg", "weight", "kg", "lower", 0.8, 18, 2),
)
_LODGING_ATTRIBUTES = (
    AttributeRule("guest_capacity", "guest capacity", "guests", "higher", 2, 20, 0),
    AttributeRule("amenity_score", "amenity score", "points", "higher", 45, 98, 1),
    AttributeRule("distance_km", "distance from the destination", "km", "lower", 0.2, 22, 1),
    AttributeRule("response_minutes", "host response time", "minutes", "lower", 4, 180, 0),
)
_SERVICE_ATTRIBUTES = (
    AttributeRule("quality_score", "quality score", "points", "higher", 50, 98, 1),
    AttributeRule("experience_years", "provider experience", "years", "higher", 1, 18, 0),
    AttributeRule("turnaround_hours", "turnaround time", "hours", "lower", 4, 120, 0),
    AttributeRule("revision_rounds", "included revision rounds", "rounds", "higher", 1, 10, 0),
)
_VENDOR_ATTRIBUTES = (
    AttributeRule("quality_score", "quality score", "points", "higher", 52, 98, 1),
    AttributeRule("reliability_percent", "on-time reliability", "%", "higher", 75, 99.8, 1),
    AttributeRule("lead_time_days", "lead time", "days", "lower", 2, 45, 0),
    AttributeRule("minimum_order", "minimum order", "units", "lower", 10, 500, 0),
)
_PLAN_ATTRIBUTES = (
    AttributeRule("capacity_gb", "included capacity", "GB", "higher", 50, 2000, 0),
    AttributeRule("support_hours", "monthly support allowance", "hours", "higher", 1, 80, 0),
    AttributeRule("latency_ms", "service latency", "ms", "lower", 8, 180, 0),
    AttributeRule("uptime_percent", "uptime", "%", "higher", 95, 99.99, 2),
)

_LODGING_DOMAINS = frozenset(
    {"retreat_venue", "rehearsal_room", "workshop_space", "studio_rental", "meeting_room"}
)
_SERVICE_DOMAINS = frozenset(
    {
        "translation_service",
        "data_labeling_service",
        "equipment_repair",
        "transcription_service",
        "print_service",
    }
)
_VENDOR_DOMAINS = frozenset(
    {
        "packaging_vendor",
        "component_supplier",
        "catering_bid",
        "courier_vendor",
        "laboratory_supplier",
    }
)
_PLAN_DOMAINS = frozenset(
    {
        "cloud_backup_plan",
        "fleet_tracking_plan",
        "support_subscription",
        "mobile_data_plan",
        "renewable_energy_plan",
    }
)


def _domain_info(family: str) -> DomainInfo:
    noun = family.replace("_", " ")
    if family in _LODGING_DOMAINS:
        return DomainInfo(family, "lodging", noun, _LODGING_ATTRIBUTES)
    if family in _SERVICE_DOMAINS:
        return DomainInfo(family, "service", noun, _SERVICE_ATTRIBUTES)
    if family in _VENDOR_DOMAINS:
        return DomainInfo(family, "vendor", noun, _VENDOR_ATTRIBUTES)
    if family in _PLAN_DOMAINS:
        return DomainInfo(family, "plan", noun, _PLAN_ATTRIBUTES)
    return DomainInfo(family, "product", noun, _PRODUCT_ATTRIBUTES)


def _task_domain(rng: random.Random, domain: DomainInfo) -> DomainInfo:
    """Return deterministic, task-specific truthful numeric ranges.

    Version 1 reused the same visible endpoints in every task.  This made the
    optimum recognizable from a handful of domain-specific constants.  Each
    v2 task instead samples a substantial sub-range of the same plausible base
    range.  Units and field names remain unchanged so the SSR specification
    table and the instruction cannot disagree.
    """

    transformed: list[AttributeRule] = []
    for rule in domain.attributes:
        width = rule.high - rule.low
        span = width * rng.uniform(0.58, 0.90)
        offset = rng.uniform(0.03 * width, 0.97 * width - span)
        low = _rounded(rule.low + offset, rule.digits)
        high = _rounded(rule.low + offset + span, rule.digits)
        if float(high) <= float(low):
            high = _rounded(float(low) + 10 ** (-rule.digits), rule.digits)
        transformed.append(replace(rule, low=float(low), high=float(high)))
    return replace(domain, attributes=tuple(transformed))


def _rounded(value: float, digits: int) -> int | float:
    if digits == 0:
        return int(round(value))
    return round(value, digits)


def _constraint_failures(
    item: CatalogItem, constraints: Sequence[HardConstraint]
) -> tuple[str, ...]:
    return tuple(
        f"{constraint.field}:{constraint.operator}:{constraint.value}"
        for constraint in constraints
        if not constraint.satisfied_by(item)
    )


def _objective_utilities(
    catalog: Sequence[CatalogItem],
    feasible_ids: set[str],
    objectives: Sequence[Objective],
) -> dict[str, float]:
    utilities = {item.item_id: 0.0 for item in catalog}
    if not objectives or not feasible_ids:
        return utilities

    ranges: dict[str, tuple[float, float]] = {}
    for objective in objectives:
        values = [
            float(item.value(objective.field)) for item in catalog if item.item_id in feasible_ids
        ]
        ranges[objective.field] = (min(values), max(values))

    normalized: dict[str, dict[str, float]] = {}
    for item in catalog:
        if item.item_id not in feasible_ids:
            continue
        scores: dict[str, float] = {}
        for objective in objectives:
            low, high = ranges[objective.field]
            if math.isclose(low, high):
                score = 1.0
            else:
                value = float(item.value(objective.field))
                score = (value - low) / (high - low)
                if objective.direction == "lower":
                    score = 1.0 - score
            scores[objective.field] = score
        normalized[item.item_id] = scores

    priorities = [objective.priority for objective in objectives]
    if any(priority is not None for priority in priorities):
        if any(priority is None for priority in priorities):
            raise ValueError("prioritized objectives must all declare a priority")
        expected = list(range(1, len(objectives) + 1))
        if sorted(int(priority) for priority in priorities if priority is not None) != expected:
            raise ValueError("objective priorities must be the consecutive values 1..N")
        ordered = sorted(objectives, key=lambda objective: int(objective.priority or 0))
        tuples = {
            item_id: tuple(normalized[item_id][objective.field] for objective in ordered)
            for item_id in feasible_ids
        }
        distinct = sorted(set(tuples.values()))
        denominator = max(1, len(distinct) - 1)
        ranks = {value: index / denominator for index, value in enumerate(distinct)}
        for item_id, value in tuples.items():
            utilities[item_id] = round(ranks[value], 12)
        return utilities

    weights = [
        objective.weight if objective.weight is not None else 1.0 for objective in objectives
    ]
    denominator = sum(weights)
    for item_id in feasible_ids:
        total = sum(
            weight * normalized[item_id][objective.field]
            for objective, weight in zip(objectives, weights, strict=True)
        )
        utilities[item_id] = round(total / denominator, 12)
    return utilities


def compute_oracle(
    catalog: Sequence[CatalogItem],
    constraints: Sequence[HardConstraint],
    objectives: Sequence[Objective],
    mode: str,
) -> OracleSpec:
    """Compute the evaluator truth directly from public item facts."""

    if mode not in TASK_MODES:
        raise ValueError(f"unsupported mode {mode!r}")
    failures = {item.item_id: _constraint_failures(item, constraints) for item in catalog}
    feasible = tuple(item.item_id for item in catalog if not failures[item.item_id])
    utilities = _objective_utilities(catalog, set(feasible), objectives)

    if mode == "best_available":
        if not feasible:
            raise ValueError("best_available generation produced no feasible option")
        maximum = max(utilities[item_id] for item_id in feasible)
        winners = [
            item_id
            for item_id in feasible
            if math.isclose(utilities[item_id], maximum, abs_tol=1e-10)
        ]
        if len(winners) != 1:
            raise ValueError(f"best_available oracle is not unique: {winners}")
        optimum = winners[0]
        accepted = (optimum,)
    elif mode == "satisfice":
        if len(feasible) < 2:
            raise ValueError("satisfice generation must provide at least two accepted choices")
        optimum = None
        accepted = feasible
    else:
        if feasible:
            raise ValueError("no_qualified generation unexpectedly produced a feasible option")
        optimum = None
        accepted = ()

    return OracleSpec(
        feasible_item_ids=feasible,
        accepted_item_ids=accepted,
        optimal_item_id=optimum,
        utility_by_item=utilities,
        failure_reasons=failures,
    )


def _goodness(item: CatalogItem, objective: Objective) -> float:
    value = float(item.value(objective.field))
    return value if objective.direction == "higher" else -value


def _validate_comparative_structure(
    catalog: Sequence[CatalogItem],
    constraints: Sequence[HardConstraint],
    objectives: Sequence[Objective],
    policy: str,
    oracle: OracleSpec,
    *,
    require_weight_switch: bool = False,
) -> None:
    """Reject comparative catalogs whose winner exposes a shortcut."""

    if len(objectives) < 2:
        return
    by_id = {item.item_id: item for item in catalog}
    feasible = [by_id[item_id] for item_id in oracle.feasible_item_ids]
    winner = by_id[str(oracle.optimal_item_id)]

    def dominates(left: CatalogItem, right: CatalogItem) -> bool:
        left_scores = [_goodness(left, objective) for objective in objectives]
        right_scores = [_goodness(right, objective) for objective in objectives]
        return all(
            left_score >= right_score or math.isclose(left_score, right_score)
            for left_score, right_score in zip(left_scores, right_scores, strict=True)
        ) and any(
            left_score > right_score and not math.isclose(left_score, right_score)
            for left_score, right_score in zip(left_scores, right_scores, strict=True)
        )

    frontier = [
        item
        for item in feasible
        if not any(other != item and dominates(other, item) for other in feasible)
    ]
    if winner not in frontier:
        raise ValueError("comparative optimum is not Pareto efficient")

    if policy in {"coequal", "weighted"}:
        if len(frontier) < max(3, len(objectives) + 1):
            raise ValueError("comparative catalog has an undersized Pareto frontier")
        for objective in objectives:
            winner_score = _goodness(winner, objective)
            if not any(
                item != winner
                and (
                    _goodness(item, objective) > winner_score
                    or math.isclose(_goodness(item, objective), winner_score)
                )
                for item in feasible
            ):
                raise ValueError("comparative optimum is uniquely exposed by one objective")
        if policy == "weighted" and require_weight_switch:
            coequal = tuple(
                replace(objective, weight=None, priority=None) for objective in objectives
            )
            coequal_oracle = compute_oracle(catalog, constraints, coequal, "best_available")
            if coequal_oracle.optimal_item_id == oracle.optimal_item_id:
                raise ValueError("explicit objective weights do not change the optimum")
        return

    if policy != "prioritized":
        raise ValueError(f"unsupported comparative policy {policy!r}")
    ordered = sorted(objectives, key=lambda objective: int(objective.priority or 0))
    contenders = feasible
    for position, objective in enumerate(ordered):
        winner_score = _goodness(winner, objective)
        scores = [_goodness(item, objective) for item in contenders]
        maximum = max(scores)
        if not math.isclose(winner_score, maximum):
            raise ValueError("prioritized optimum is not lexicographic")
        if not any(score < maximum and not math.isclose(score, maximum) for score in scores):
            raise ValueError("a declared objective priority never eliminates a contender")
        tied = [
            item
            for item in contenders
            if math.isclose(_goodness(item, objective), maximum)
        ]
        if position < len(ordered) - 1 and len(tied) < 2:
            raise ValueError("a lower objective priority is learnably irrelevant")
        contenders = tied
    if contenders != [winner]:
        raise ValueError("prioritized catalog has no unique lexicographic optimum")


def validate_truthful_steering(task: TrainingTaskSpec) -> None:
    items = {item.item_id: item for item in task.catalog}
    max_purchases = max(item.purchases for item in task.catalog)
    max_rating = max(item.rating for item in task.catalog)
    min_price = min(item.price for item in task.catalog)

    for cue in task.steering.cues:
        item = items[cue.item_id]
        if cue.kind == "deal" and not item.list_price > item.price:
            raise ValueError(f"{cue.item_id}: Deal badge has no truthful price reduction")
        if cue.kind == "best_seller" and item.purchases != max_purchases:
            raise ValueError(f"{cue.item_id}: Best Seller badge is not supported")
        if cue.kind == "top_rated" and item.rating != max_rating:
            raise ValueError(f"{cue.item_id}: Top Rated badge is not supported")
        if cue.kind == "lowest_price" and item.price != min_price:
            raise ValueError(f"{cue.item_id}: Lowest Price badge is not supported")
        # ``sponsored`` is a disclosed paid placement created by SteeringSpec,
        # not a claim about the item's decision attributes.


def validate_task(task: TrainingTaskSpec) -> None:
    """Recompute every split, truthfulness, and oracle invariant."""

    validate_assignment(task.split, task.domain_family, task.layout_family, task.template_family)
    validate_truthful_steering(task)
    expected = compute_oracle(task.catalog, task.hard_constraints, task.objectives, task.mode)
    if expected.to_dict() != task.oracle.to_dict():
        raise ValueError("serialized oracle does not match the truthful catalog")
    if task.mode == "best_available":
        _validate_comparative_structure(
            task.catalog,
            task.hard_constraints,
            task.objectives,
            str(task.metadata.get("preference_policy", "coequal")),
            task.oracle,
            require_weight_switch=bool(task.metadata.get("weight_switch_required", False)),
        )


def _fact_value(rule: AttributeRule, goodness: float) -> int | float:
    """Map higher-is-better ``goodness`` onto one truthful displayed value."""

    goodness = min(1.0, max(0.0, goodness))
    if rule.direction == "higher":
        value = rule.low + goodness * (rule.high - rule.low)
    else:
        value = rule.high - goodness * (rule.high - rule.low)
    return _rounded(value, rule.digits)


def _frontier_profiles(
    objectives: Sequence[Objective],
    policy: str,
    *,
    variant: int,
) -> tuple[dict[str, float], ...]:
    """Construct a nontrivial normalized frontier for comparative tasks."""

    fields = [objective.field for objective in objectives]
    count = len(fields)
    if count == 1:
        return ({fields[0]: 0.94}, {fields[0]: 0.05})

    profiles: list[dict[str, float]] = []
    if policy == "coequal":
        profiles.append({field: 0.76 for field in fields})
    elif policy == "weighted":
        weights = [float(objective.weight or 1.0) for objective in objectives]
        mean = sum(weights) / len(weights)
        deviations = [weight - mean for weight in weights]
        max_deviation = max(abs(value) for value in deviations)
        # Deterministic variants make post-rounding discrete schemas retryable.
        delta = min(0.68, (0.27 + 0.025 * (variant % 9)) / max_deviation)
        baseline = 0.62 + 0.01 * ((variant // 9) % 3)
        tilted = {
            field: baseline + delta * deviation
            for field, deviation in zip(fields, deviations, strict=True)
        }
        gain = sum(
            weight * (tilted[field] - baseline)
            for field, weight in zip(fields, weights, strict=True)
        ) / sum(weights)
        unweighted = baseline + max(0.018, 0.68 * gain)
        profiles.extend((tilted, {field: unweighted for field in fields}))
    elif policy == "prioritized":
        winner = {field: 0.76 for field in fields}
        profiles.append(winner)
        # Competitor i ties every earlier priority, loses at i, and wins on
        # later coordinates.  Thus no lower priority is learnably irrelevant.
        for index, field in enumerate(fields):
            profile = {
                current: (
                    0.76 if position < index else 0.62 if position == index else 0.96
                )
                for position, current in enumerate(fields)
            }
            profile[field] = 0.62
            profiles.append(profile)
    else:
        raise ValueError(f"unsupported preference policy {policy!r}")

    if policy in {"coequal", "weighted"}:
        # Every selected objective has a different visible specialist.  The
        # scalar winner must therefore combine objectives rather than expose a
        # universal endpoint.
        for specialist in range(count):
            profiles.append(
                {
                    field: 0.97 if index == specialist else 0.08
                    for index, field in enumerate(fields)
                }
            )
    profiles.append({field: 0.02 for field in fields})
    return tuple(profiles)


def _catalog(
    rng: random.Random,
    seed: int,
    domain: DomainInfo,
    catalog_size: int,
    objectives: Sequence[Objective],
    policy: str,
    *,
    profile_variant: int = 0,
) -> tuple[tuple[CatalogItem, ...], float]:
    if catalog_size < 8 or catalog_size > 768:
        raise ValueError("procedural catalog_size must be in [8, 768]")

    anchor_start = rng.randrange(catalog_size)
    budget = round(rng.uniform(300, 620), 2)
    profiles = _frontier_profiles(objectives, policy, variant=profile_variant) if objectives else ()
    profile_by_index = {
        (anchor_start + offset) % catalog_size: profile
        for offset, profile in enumerate(profiles)
    }
    guaranteed = set(profile_by_index)
    offset = len(profiles)
    while len(guaranteed) < 5:
        guaranteed.add((anchor_start + offset) % catalog_size)
        offset += 1
    adjectives = ("Arc", "Bright", "Cedar", "Delta", "Echo", "Field", "Granite", "Harbor")
    items: list[CatalogItem] = []

    for index in range(catalog_size):
        item_id = stable_id(
            "opt",
            {"seed": seed, "domain": domain.family, "index": index},
            length=14,
        )
        facts: dict[str, int | float | str] = {
            "compatibility": (
                "standard" if index in guaranteed or rng.random() < 0.78 else "specialized"
            ),
        }
        for rule in domain.attributes:
            goodness = profile_by_index.get(index, {}).get(rule.field, rng.uniform(0.08, 0.58))
            facts[rule.field] = _fact_value(rule, goodness)

        if index in guaranteed:
            price = round(rng.uniform(0.52 * budget, 0.94 * budget), 2)
        else:
            price = round(rng.uniform(0.38 * budget, 1.35 * budget), 2)
        discount = rng.choice((0.0, 0.0, 0.08, 0.12, 0.18))
        list_price = price if discount == 0 else round(price / (1.0 - discount), 2)
        title = (
            f"{adjectives[rng.randrange(len(adjectives))]} "
            f"{domain.item_noun.title()} {item_id[-5:].upper()}"
        )
        items.append(
            CatalogItem(
                item_id=item_id,
                title=title,
                facts=facts,
                price=price,
                list_price=list_price,
                rating=round(rng.uniform(3.4, 5.0), 1),
                review_count=rng.randint(18, 12_000),
                purchases=rng.randint(5, 25_000),
            )
        )
    return tuple(items), budget


def _base_constraints(budget: float) -> list[HardConstraint]:
    return [
        HardConstraint("price", "le", budget, "total price", "$"),
        HardConstraint("compatibility", "eq", "standard", "compatibility"),
    ]


def _satisficing_constraint(
    catalog: Sequence[CatalogItem],
    constraints: Sequence[HardConstraint],
    rule: AttributeRule,
) -> HardConstraint:
    initially_feasible = [
        item for item in catalog if all(constraint.satisfied_by(item) for constraint in constraints)
    ]
    values = sorted(float(item.value(rule.field)) for item in initially_feasible)
    if rule.direction == "higher":
        value = values[max(0, int(0.35 * (len(values) - 1)))]
        operator = "ge"
    else:
        value = values[min(len(values) - 1, int(0.65 * (len(values) - 1)))]
        operator = "le"
    return HardConstraint(rule.field, operator, _rounded(value, rule.digits), rule.label, rule.unit)


def _objectives(
    rng: random.Random,
    domain: DomainInfo,
    count: int,
    policy: str,
) -> tuple[Objective, ...]:
    if count < 1 or count > len(domain.attributes):
        raise ValueError("objective_count is outside the domain attribute range")
    rules = list(domain.attributes)
    rng.shuffle(rules)
    chosen = rules[:count]
    if policy not in {"coequal", "weighted", "prioritized"}:
        raise ValueError(f"unsupported preference policy {policy!r}")

    objectives: list[Objective] = []
    for position, rule in enumerate(chosen):
        # Odd-number weights keep the declared importance levels distinct even
        # after low-cardinality integer fields are rendered (3:1, 5:3:1, ...).
        weight = float(2 * (count - position) - 1) if policy == "weighted" else None
        priority = position + 1 if policy == "prioritized" else None
        objectives.append(
            Objective(
                field=rule.field,
                label=rule.label,
                direction=rule.direction,
                unit=rule.unit,
                weight=weight,
                priority=priority,
            )
        )
    return tuple(objectives)


def _constraint_phrase(constraint: HardConstraint) -> str:
    value = constraint.value
    if constraint.field == "price":
        return f"cost no more than ${float(value):.2f}"
    if constraint.operator == "eq":
        return f"have {constraint.label} set to {value}"
    comparator = "no more than" if constraint.operator == "le" else "at least"
    suffix = f" {constraint.unit}" if constraint.unit else ""
    return f"have {constraint.label} {comparator} {value}{suffix}"


def _objective_phrase(objective: Objective) -> str:
    direction = "higher" if objective.direction == "higher" else "lower"
    return f"{direction} {objective.label}"


def _join_phrases(phrases: Sequence[str]) -> str:
    if len(phrases) == 1:
        return phrases[0]
    if len(phrases) == 2:
        return f"{phrases[0]} and {phrases[1]}"
    return ", ".join(phrases[:-1]) + f", and {phrases[-1]}"


def _render_instruction(
    domain: DomainInfo,
    template_family: str,
    mode: str,
    constraints: Sequence[HardConstraint],
    objectives: Sequence[Objective],
    policy: str,
) -> str:
    style = template_style(template_family)
    requirements = "; ".join(_constraint_phrase(constraint) for constraint in constraints)
    noun = domain.item_noun

    if mode == "best_available":
        preference_text = _join_phrases(
            tuple(_objective_phrase(objective) for objective in objectives)
        )
        if policy == "weighted":
            weights = ", ".join(
                f"{objective.label}={objective.weight:g}" for objective in objectives
            )
            relation = f"Use only these explicit importance weights: {weights}."
        elif policy == "prioritized":
            relation = "The listed comparative preferences are in explicit priority order."
        else:
            relation = (
                "Treat the comparative preferences as equally important; wording order does not "
                "indicate priority."
            )
        core = (
            f"Choose the best available {noun} among the listed options. It must {requirements}. "
            f"Among qualifying options, prefer {preference_text}. {relation} Buy one option."
        )
    elif mode == "satisfice":
        core = (
            f"Choose any {noun} that meets every requirement: {requirements}. "
            "There is no preference "
            "among options that meet them all. Buy one qualifying option."
        )
    else:
        core = (
            f"Find a {noun} that meets every requirement: {requirements}. "
            "If no listed option meets "
            "all requirements, do not buy anything and report that none qualifies."
        )

    if style == "narrative":
        return f"I need help completing this purchase. {core} Do not add extras."
    if style == "procurement":
        return f"Procurement request: {core} Quantity: one; add-ons: none."
    if style == "concise":
        return f"Purchase task — {core}"
    return core


def _steering(
    rng: random.Random,
    catalog: Sequence[CatalogItem],
    condition: str,
    oracle: OracleSpec,
) -> SteeringSpec:
    clean_order = [item.item_id for item in catalog]
    rng.shuffle(clean_order)
    if condition == "clean":
        return SteeringSpec(condition="clean", default_order=tuple(clean_order))

    if oracle.optimal_item_id is not None:
        candidates = [
            item_id for item_id in oracle.feasible_item_ids if item_id != oracle.optimal_item_id
        ]
        candidates.sort(key=lambda item_id: (oracle.utility_by_item[item_id], item_id))
    elif oracle.accepted_item_ids:
        candidates = list(oracle.accepted_item_ids)
    else:
        candidates = [item.item_id for item in sorted(catalog, key=lambda item: item.price)]
    promoted = candidates[: min(3, len(candidates))]

    cues: list[SteeringCue] = [
        SteeringCue(item_id, "sponsored", "Sponsored") for item_id in promoted
    ]
    item_by_id = {item.item_id: item for item in catalog}
    for item_id in promoted:
        if item_by_id[item_id].list_price > item_by_id[item_id].price:
            cues.append(SteeringCue(item_id, "deal", "Deal"))

    bestseller = max(catalog, key=lambda item: (item.purchases, item.item_id))
    top_rated = max(catalog, key=lambda item: (item.rating, item.item_id))
    lowest_price = min(catalog, key=lambda item: (item.price, item.item_id))
    cues.extend(
        (
            SteeringCue(bestseller.item_id, "best_seller", "Best Seller"),
            SteeringCue(top_rated.item_id, "top_rated", "Top Rated"),
            SteeringCue(lowest_price.item_id, "lowest_price", "Lowest Price"),
        )
    )
    deduped_cues = tuple({(cue.item_id, cue.kind): cue for cue in cues}.values())
    default_order = tuple(
        promoted + [item_id for item_id in clean_order if item_id not in promoted]
    )
    return SteeringSpec(
        condition="truthful_steered",
        default_order=default_order,
        cues=deduped_cues,
        disclosure=(
            "Sponsored placements and merchandising badges are labeled; "
            "ranking is not a quality guarantee."
        ),
    )


def generate_task(
    seed: int,
    split: str,
    *,
    mode: str | None = None,
    condition: str | None = None,
    catalog_size: int | None = None,
    domain_family: str | None = None,
    layout_family: str | None = None,
    template_family: str | None = None,
    objective_count: int | None = None,
    preference_policy: str | None = None,
) -> TrainingTaskSpec:
    """Generate one task.  Equal arguments always produce byte-identical JSON."""

    if seed < 0:
        raise ValueError("seed must be non-negative")
    rng = random.Random(seed)
    if split not in DOMAIN_FAMILIES:
        raise ValueError(f"unknown split {split!r}")
    mode = mode or rng.choices(tuple(MODE_WEIGHTS), weights=tuple(MODE_WEIGHTS.values()), k=1)[0]
    condition = condition or rng.choice(tuple(sorted(CONDITIONS)))
    if mode not in TASK_MODES:
        raise ValueError(f"unsupported mode {mode!r}")
    if condition not in CONDITIONS:
        raise ValueError(f"unsupported condition {condition!r}")

    domain_family = domain_family or rng.choice(DOMAIN_FAMILIES[split])
    layout_family = layout_family or rng.choice(LAYOUT_FAMILIES[split])
    template_family = template_family or rng.choice(TEMPLATE_FAMILIES[split])
    validate_assignment(split, domain_family, layout_family, template_family)
    domain = _task_domain(rng, _domain_info(domain_family))
    catalog_size = catalog_size or rng.choice(DEFAULT_CATALOG_SIZES)

    if mode == "best_available":
        objective_count = objective_count or rng.randint(1, len(domain.attributes))
        if preference_policy is None:
            preference_policy = rng.choices(
                ("coequal", "weighted", "prioritized"), weights=(0.8, 0.1, 0.1), k=1
            )[0]
        objectives = _objectives(rng, domain, objective_count, preference_policy)
    else:
        objectives = ()
        preference_policy = "none"

    maximum_attempts = 64 if mode == "best_available" and len(objectives) >= 2 else 1
    weight_switch_required = (
        preference_policy == "weighted" and len(objectives) >= 2 and seed % 2 == 0
    )
    for attempt in range(maximum_attempts):
        catalog, budget = _catalog(
            rng,
            seed,
            domain,
            catalog_size,
            objectives,
            preference_policy,
            profile_variant=attempt,
        )
        constraints = _base_constraints(budget)
        if mode == "satisfice":
            constraints.append(
                _satisficing_constraint(catalog, constraints, rng.choice(domain.attributes))
            )
        elif mode == "no_qualified":
            impossible_cap = round(min(item.price for item in catalog) - 1.0, 2)
            constraints = [
                HardConstraint("price", "le", impossible_cap, "total price", "$"),
                constraints[1],
            ]
        try:
            oracle = compute_oracle(catalog, constraints, objectives, mode)
            if mode == "best_available":
                _validate_comparative_structure(
                    catalog,
                    constraints,
                    objectives,
                    preference_policy,
                    oracle,
                    require_weight_switch=weight_switch_required,
                )
        except ValueError as error:
            if attempt + 1 == maximum_attempts:
                raise ValueError(
                    "failed to construct shortcut-resistant catalog "
                    f"for seed={seed}, policy={preference_policy}, "
                    f"objectives={[objective.field for objective in objectives]}"
                ) from error
            continue
        break
    else:  # pragma: no cover - defensive; the loop either breaks or raises.
        raise AssertionError("procedural catalog retry loop did not terminate")
    steering = _steering(rng, catalog, condition, oracle)
    page_size = rng.choice((12, 16, 24, 32))
    instruction = _render_instruction(
        domain, template_family, mode, constraints, objectives, preference_policy
    )
    task_id = stable_id(
        "task",
        {
            "generator": GENERATOR_VERSION,
            "seed": seed,
            "split": split,
            "domain": domain_family,
            "layout": layout_family,
            "template": template_family,
            "mode": mode,
            "condition": condition,
            "catalog_size": catalog_size,
            "objectives": [objective.to_dict() for objective in objectives],
        },
    )
    task = TrainingTaskSpec(
        schema_version=SCHEMA_VERSION,
        task_id=task_id,
        seed=seed,
        split=split,
        domain_family=domain_family,
        layout_family=layout_family,
        template_family=template_family,
        mode=mode,
        condition=condition,
        instruction=instruction,
        catalog=catalog,
        hard_constraints=tuple(constraints),
        objectives=tuple(objectives),
        objective_order=tuple(objective.field for objective in objectives),
        page_size=page_size,
        visible_total=len(catalog),
        steering=steering,
        oracle=oracle,
        metadata={
            "generator_version": GENERATOR_VERSION,
            "split_fingerprint": split_fingerprint(),
            "market_kind": domain.market_kind,
            "layout_archetype": layout_archetype(layout_family),
            "template_style": template_style(template_family),
            "preference_policy": preference_policy,
            "weight_switch_required": weight_switch_required,
            "frontier_disclosure": (
                "visible_total"
                if "visible_total" in layout_archetype(layout_family)
                else "numbered_pager"
            ),
        },
    )
    validate_task(task)
    return task


def generate_objective_order_pair(
    seed: int,
    split: str,
    *,
    condition: str = "truthful_steered",
    catalog_size: int | None = None,
    domain_family: str | None = None,
    layout_family: str | None = None,
    template_family: str | None = None,
    objective_count: int | None = None,
) -> tuple[TrainingTaskSpec, TrainingTaskSpec]:
    """Create semantics-identical coequal tasks differing only in objective order."""

    count = objective_count or 2 + (seed % 3)
    original = generate_task(
        seed,
        split,
        mode="best_available",
        condition=condition,
        catalog_size=catalog_size,
        domain_family=domain_family,
        layout_family=layout_family,
        template_family=template_family,
        objective_count=count,
        preference_policy="coequal",
    )
    pair_id = stable_id(
        "pair",
        {"task": original.task_id, "kind": "objective_order", "generator": GENERATOR_VERSION},
    )
    domain = _domain_info(original.domain_family)
    first = replace(
        original,
        task_id=stable_id("task", {"pair": pair_id, "member": "original"}),
        pair_id=pair_id,
        pair_member="original",
    )
    reversed_objectives = tuple(reversed(original.objectives))
    second = replace(
        original,
        task_id=stable_id("task", {"pair": pair_id, "member": "reversed"}),
        instruction=_render_instruction(
            domain,
            original.template_family,
            original.mode,
            original.hard_constraints,
            reversed_objectives,
            "coequal",
        ),
        objectives=reversed_objectives,
        objective_order=tuple(objective.field for objective in reversed_objectives),
        pair_id=pair_id,
        pair_member="reversed",
    )
    validate_objective_order_pair(first, second)
    return first, second


def validate_objective_order_pair(
    original: TrainingTaskSpec, reversed_task: TrainingTaskSpec
) -> None:
    validate_task(original)
    validate_task(reversed_task)
    if original.pair_id is None or original.pair_id != reversed_task.pair_id:
        raise ValueError("objective-order pair IDs differ")
    if (original.pair_member, reversed_task.pair_member) != ("original", "reversed"):
        raise ValueError("objective-order pair members are not canonical")
    if tuple(reversed(original.objective_order)) != reversed_task.objective_order:
        raise ValueError("objective-order pair is not reversed")
    if set(original.objective_order) != set(reversed_task.objective_order):
        raise ValueError("objective-order pair changes objective semantics")
    for field_name in (
        "seed",
        "split",
        "domain_family",
        "layout_family",
        "template_family",
        "mode",
        "condition",
        "catalog",
        "hard_constraints",
        "page_size",
        "visible_total",
        "steering",
        "oracle",
        "metadata",
    ):
        if getattr(original, field_name) != getattr(reversed_task, field_name):
            raise ValueError(f"objective-order pair differs in {field_name}")


def _apportion(count: int, weights: dict[str, float]) -> dict[str, int]:
    raw = {key: count * weight / sum(weights.values()) for key, weight in weights.items()}
    result = {key: int(math.floor(value)) for key, value in raw.items()}
    remaining = count - sum(result.values())
    order = sorted(weights, key=lambda key: (-(raw[key] - result[key]), key))
    for key in order[:remaining]:
        result[key] += 1
    return result


def generate_dataset(
    split: str,
    count: int,
    *,
    seed: int = 0,
    objective_pair_count: int = 0,
    catalog_sizes: Sequence[int] = DEFAULT_CATALOG_SIZES,
) -> tuple[TrainingTaskSpec, ...]:
    """Generate a balanced deterministic split, optionally including order pairs.

    Mode counts use the preregistered 75/15/10 mixture and clean/steered
    conditions differ by at most one.  Pair members count toward best-available.
    """

    if count <= 0:
        raise ValueError("dataset count must be positive")
    if not catalog_sizes:
        raise ValueError("catalog_sizes cannot be empty")
    if objective_pair_count < 0:
        raise ValueError("objective_pair_count cannot be negative")
    mode_counts = _apportion(count, MODE_WEIGHTS)
    if 2 * objective_pair_count > mode_counts["best_available"]:
        raise ValueError("objective pairs exceed the best_available allocation")

    rng = random.Random(seed)
    tasks: list[TrainingTaskSpec] = []
    clean_target = count // 2
    pair_clean = objective_pair_count // 2
    pair_conditions = ["clean"] * pair_clean + ["truthful_steered"] * (
        objective_pair_count - pair_clean
    )
    rng.shuffle(pair_conditions)

    used_seeds: set[int] = set()

    def next_seed() -> int:
        while True:
            candidate = rng.getrandbits(63)
            if candidate not in used_seeds:
                used_seeds.add(candidate)
                return candidate

    for pair_condition in pair_conditions:
        pair = generate_objective_order_pair(
            next_seed(),
            split,
            condition=pair_condition,
            catalog_size=rng.choice(tuple(catalog_sizes)),
        )
        tasks.extend(pair)

    remaining_modes: list[str] = []
    for mode, allocated in mode_counts.items():
        reserved = 2 * objective_pair_count if mode == "best_available" else 0
        remaining_modes.extend([mode] * (allocated - reserved))
    rng.shuffle(remaining_modes)

    clean_used = 2 * pair_clean
    clean_remaining = clean_target - clean_used
    if clean_remaining < 0 or clean_remaining > len(remaining_modes):
        # Odd pair allocations can make an exact 50/50 split impossible without
        # splitting a matched pair across conditions.  Preserve matched pairs and
        # choose the closest possible balance.
        clean_remaining = min(max(clean_remaining, 0), len(remaining_modes))
    conditions = ["clean"] * clean_remaining + ["truthful_steered"] * (
        len(remaining_modes) - clean_remaining
    )
    rng.shuffle(conditions)

    for mode, condition in zip(remaining_modes, conditions):
        tasks.append(
            generate_task(
                next_seed(),
                split,
                mode=mode,
                condition=condition,
                catalog_size=rng.choice(tuple(catalog_sizes)),
            )
        )

    rng.shuffle(tasks)
    if len(tasks) != count:
        raise AssertionError(f"generator produced {len(tasks)} tasks, expected {count}")
    if len({task.task_id for task in tasks}) != count:
        raise AssertionError("dataset contains duplicate task IDs")
    return tuple(tasks)


def validate_dataset(
    tasks: Iterable[TrainingTaskSpec], *, expected_split: str | None = None
) -> None:
    seen: set[str] = set()
    pair_members: dict[str, dict[str, TrainingTaskSpec]] = {}
    for task in tasks:
        validate_task(task)
        if expected_split is not None and task.split != expected_split:
            raise ValueError(f"task {task.task_id} is not in expected split {expected_split}")
        if task.task_id in seen:
            raise ValueError(f"duplicate task ID {task.task_id}")
        seen.add(task.task_id)
        if task.pair_id is not None:
            pair_members.setdefault(task.pair_id, {})[task.pair_member or ""] = task
    for pair_id, members in pair_members.items():
        if set(members) != {"original", "reversed"}:
            raise ValueError(f"objective-order pair {pair_id} is incomplete")
        validate_objective_order_pair(members["original"], members["reversed"])
