"""Reproducible, resumable materialization of the sealed procedural splits."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any

from .config import Campaign, atomic_json
from .procedural import generate_dataset, validate_dataset
from .schemas import read_tasks_jsonl, write_tasks_jsonl
from .split import assert_split_disjoint, split_fingerprint

SPLIT_NAME_MAP = {
    "train": "train",
    "validation": "validation",
    "procedural_test": "test",
}


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _catalog_sizes(campaign: Campaign, configured_split: str) -> tuple[int, ...]:
    data = campaign.campaign["data"]
    minimum = int(data["catalog_size"]["train_min"])
    maximum = int(
        data["catalog_size"]["procedural_test_max"]
        if configured_split == "procedural_test"
        else data["catalog_size"]["train_max"]
    )
    canonical = (16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768)
    sizes = tuple(value for value in canonical if minimum <= value <= maximum)
    if not sizes or sizes[0] != minimum or sizes[-1] != maximum:
        raise ValueError(
            f"catalog bounds {minimum}..{maximum} are not represented by canonical sizes"
        )
    return sizes


def _split_seed(root_seed: int, configured_split: str) -> int:
    payload = f"harness-distill:{root_seed}:{configured_split}".encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def _summary(tasks: tuple[Any, ...]) -> dict[str, Any]:
    return {
        "count": len(tasks),
        "mode_counts": dict(sorted(Counter(task.mode for task in tasks).items())),
        "condition_counts": dict(sorted(Counter(task.condition for task in tasks).items())),
        "domain_family_count": len({task.domain_family for task in tasks}),
        "layout_family_count": len({task.layout_family for task in tasks}),
        "template_family_count": len({task.template_family for task in tasks}),
        "catalog_size_min": min(len(task.catalog) for task in tasks),
        "catalog_size_max": max(len(task.catalog) for task in tasks),
        "paired_task_count": sum(task.pair_id is not None for task in tasks),
        "pair_count": len({task.pair_id for task in tasks if task.pair_id is not None}),
    }


def generate_campaign_data(campaign: Campaign, output_dir: str | Path) -> dict[str, Any]:
    """Generate all three split files and refuse silent drift on resume."""

    assert_split_disjoint()
    root = Path(output_dir).resolve() / "data" / "procedural"
    root.mkdir(parents=True, exist_ok=True)
    split_counts = campaign.campaign["data"]["splits"]
    pair_counts = campaign.campaign["data"]["objective_order_pairs"]
    split_records: dict[str, Any] = {}
    all_task_ids: set[str] = set()

    for configured_split, count_value in split_counts.items():
        if configured_split not in SPLIT_NAME_MAP:
            raise ValueError(f"unknown configured split {configured_split!r}")
        logical_split = SPLIT_NAME_MAP[configured_split]
        count = int(count_value)
        tasks = generate_dataset(
            logical_split,
            count,
            seed=_split_seed(int(campaign.campaign["seed"]), configured_split),
            objective_pair_count=int(pair_counts[configured_split]),
            catalog_sizes=_catalog_sizes(campaign, configured_split),
        )
        validate_dataset(tasks, expected_split=logical_split)
        ids = {task.task_id for task in tasks}
        overlap = all_task_ids & ids
        if overlap:
            raise ValueError(f"task IDs overlap across splits: {sorted(overlap)[:3]}")
        all_task_ids.update(ids)

        destination = root / f"{configured_split}.jsonl"
        temporary = destination.with_name(f".{destination.name}.tmp")
        generated_hash = write_tasks_jsonl(temporary, tasks)
        if destination.exists():
            existing_hash = _sha256_file(destination)
            if existing_hash != generated_hash:
                temporary.unlink()
                raise RuntimeError(
                    f"existing split drift at {destination}: {existing_hash} != {generated_hash}"
                )
            temporary.unlink()
        else:
            temporary.replace(destination)
        reloaded = read_tasks_jsonl(destination)
        validate_dataset(reloaded, expected_split=logical_split)
        if len(reloaded) != count or _sha256_file(destination) != generated_hash:
            raise RuntimeError(f"post-write validation failed for {configured_split}")
        split_records[configured_split] = {
            "logical_split": logical_split,
            "path": str(destination),
            "sha256": generated_hash,
            **_summary(reloaded),
        }

    manifest = {
        "schema": "harness-distill.procedural-manifest.v1",
        "campaign_sha256": campaign.digest,
        "generator_seed": int(campaign.campaign["seed"]),
        "split_fingerprint": split_fingerprint(),
        "total_tasks": sum(record["count"] for record in split_records.values()),
        "globally_unique_task_ids": len(all_task_ids),
        "original_amazon_five_present": False,
        "deliberately_false_product_fields_present": False,
        "splits": split_records,
    }
    if manifest["total_tasks"] != int(campaign.campaign["data"]["total_tasks"]):
        raise RuntimeError("generated task total differs from campaign")
    atomic_json(root / "manifest.json", manifest)
    # Parse the manifest back to catch partial/corrupt filesystem writes.
    if json.loads((root / "manifest.json").read_text(encoding="utf-8")) != manifest:
        raise RuntimeError("procedural manifest failed round-trip validation")
    return manifest
