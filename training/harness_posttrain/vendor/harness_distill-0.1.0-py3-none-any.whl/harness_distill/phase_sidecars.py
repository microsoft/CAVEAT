"""Build same-turn, public-evidence-only phase-state sidecars.

The input boundary is deliberately narrow: a successful audited-proxy record
and, within it, only the original OpenAI request's user/tool *text*.  The
adapter never consumes the proxy response, effective/provider request, system
prompt, assistant generation, task specification, catalog, evaluator state,
reward, credentials, or a later request.  A frozen extraction model may
organize that public text, but every resulting claim is independently rebuilt
through :mod:`harness_distill.shadow` and must cite a resolvable evidence path.

The extractor is not trusted.  Its output must contain all five general phases
and use a small claim vocabulary.  Unknowns are preferable to invention;
non-direct scalar values must either occur in the cited text or belong to a
small phase-control vocabulary.  Invalid, future, private, or hallucinated
citations fail the whole build rather than silently dropping a decision.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import parse_qsl, urlsplit

import httpx

from .materialize import (
    PRIVILEGE_SIDECAR_SCHEMA,
    PROXY_TRACE_SCHEMA,
    canonical_json,
    infer_turn_index,
    replay_request,
    sha256_json,
)
from .shadow import (
    ClaimDerivation,
    ClaimStatus,
    EvidenceRef,
    PrivilegeAuditError,
    PublicEvidence,
    PublicEvidenceSource,
    ShadowPhase,
    ShadowPhaseStateBuilder,
    TeacherPrivilege,
    audit_public_payload,
)


class PhaseSidecarError(ValueError):
    """A proxy decision cannot produce a provenance-closed phase sidecar."""


@dataclass(frozen=True, slots=True)
class PhaseExtractionInput:
    """The complete and sole payload an extractor is allowed to inspect."""

    turn_index: int
    request_sha256: str
    public_evidence: tuple[PublicEvidence, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "turn_index": self.turn_index,
            "request_sha256": self.request_sha256,
            "public_evidence": [item.to_dict() for item in self.public_evidence],
        }


class PhaseExtractor(Protocol):
    """Frozen public-evidence interpreter used by sidecar orchestration."""

    def extract(self, item: PhaseExtractionInput) -> Mapping[str, Any]: ...

    def descriptor(self) -> Mapping[str, Any]: ...


_PHASE_KEYS: dict[ShadowPhase, frozenset[str]] = {
    ShadowPhase.CONTRACT: frozenset(
        {"requirement", "search_mode", "objective", "constraint", "preference"}
    ),
    ShadowPhase.COVERAGE: frozenset(
        {"frontier_status", "page_seen", "page_total", "candidate_seen", "coverage_gap"}
    ),
    ShadowPhase.FACT_RESOLUTION: frozenset({"known_fact", "unknown_fact", "conflicting_fact"}),
    ShadowPhase.DECISION: frozenset(
        {
            "feasible_candidate",
            "rejected_candidate",
            "pareto_candidate",
            "provisional_choice",
            "decision_gap",
        }
    ),
    ShadowPhase.PRECOMMIT: frozenset(
        {"selected_identity", "selected_quantity", "selected_total", "precommit_gap"}
    ),
}

_CONTROL_VALUES = frozenset(
    {
        "best_available",
        "threshold",
        "coequal",
        "complete",
        "incomplete",
        "not_started",
        "frontier_open",
        "frontier_closed",
        "known",
        "unknown",
        "conflict",
        "feasible",
        "infeasible",
        "dominated",
        "nondominated",
        "provisional",
        "final",
        "minimize",
        "maximize",
        "hard_constraint",
        "soft_preference",
        "not_selected",
        "not_calculated",
    }
)

_PRIVATE_TEXT_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"\bstorefront[\s_-]*ops[\s_-]*token\b",
        r"\bx-storefront-ops\b",
        r"\b(?:authorization|proxy-authorization)\s*[:=]\s*(?:bearer\s+)?\S+",
        r"\b(?:cookie|set-cookie)\s*:\s*\S+",
        r"\b(?:api[_-]?key|access[_-]?token|secret[_-]?key)\s*[:=]\s*\S+",
        r"\b(?:storefront[_-]?client[_-]?token|x-storefront-client)\s*[:=]\s*\S+",
        r"\b(?:hero(?:_?id)?|pin(?:_?id)?|oracle(?:_?score)?|evaluator(?:_?score)?|"
        r"reward|strict[_-]?binary|preservation[_-]?strict)\s*[:=]\s*\S+",
        r"/(?:api/)?(?:admin|internal|ops|oracle|evaluator)(?:[/#?]|$)",
        r"/api/orders(?:[/#?]|$)",
        r"\.(?:db|sqlite|sqlite3)(?:\b|[?#])",
    )
)
_URL_PATTERN = re.compile(r"https?://[^\s<>'\"]+")
_SENSITIVE_QUERY_KEYS = {
    "token",
    "access_token",
    "api_key",
    "apikey",
    "authorization",
    "cookie",
    "oracle",
    "evaluator",
    "reward",
    "hero",
    "hero_id",
    "pin",
    "pin_id",
    "storefront_ops_token",
}
_REVISION_PATTERN = re.compile(r"[0-9a-f]{40}")
_DISPLAYED_NUMBER_PATTERN = re.compile(r"(?<![\w.])[-+]?\d+(?:,\d{3})*(?:\.\d+)?(?![\w.])")
_OBSERVATION_REQUIRED_KEYS = frozenset(
    {
        "feasible_candidate",
        "rejected_candidate",
        "pareto_candidate",
        "provisional_choice",
        "selected_identity",
    }
)


def _visible_text_parts(content: Any, *, path: str) -> list[str]:
    if isinstance(content, str):
        return [content] if content else []
    if not isinstance(content, list):
        raise PhaseSidecarError(f"{path} must be text or content parts")
    texts: list[str] = []
    for index, part in enumerate(content):
        if not isinstance(part, Mapping):
            raise PhaseSidecarError(f"{path}[{index}] must be an object")
        part_type = part.get("type")
        if part_type == "text":
            text = part.get("text")
            if not isinstance(text, str):
                raise PhaseSidecarError(f"{path}[{index}].text must be text")
            if text:
                texts.append(text)
        elif part_type == "image_url":
            # Pixel content is not recoverable from a proxy JSON request in a
            # provenance-preserving way.  An OCR capture must enter through a
            # separately audited public-observation adapter, not this one.
            continue
        else:
            raise PhaseSidecarError(f"{path}[{index}] has unsupported content type")
    return texts


def _assert_public_text(text: str, *, path: str) -> None:
    for pattern in _PRIVATE_TEXT_PATTERNS:
        if pattern.search(text):
            raise PhaseSidecarError(f"{path} contains private-route or credential-like text")
    for match in _URL_PATTERN.finditer(text):
        parsed = urlsplit(match.group(0).rstrip(".,);]"))
        segments = {part.casefold() for part in parsed.path.split("/") if part}
        if segments & {"admin", "internal", "ops", "oracle", "evaluator", "private"}:
            raise PhaseSidecarError(f"{path} contains a private URL")
        query_keys = {key.casefold() for key, _ in parse_qsl(parsed.query, keep_blank_values=True)}
        if query_keys & _SENSITIVE_QUERY_KEYS or any(key.endswith("token") for key in query_keys):
            raise PhaseSidecarError(f"{path} contains a credential-like URL query")


def public_evidence_from_request(
    request: Mapping[str, Any],
    *,
    request_sha256: str | None = None,
    turn_index_override: int | None = None,
) -> tuple[int, tuple[PublicEvidence, ...]]:
    """Project an OpenAI request onto the text already visible to the agent.

    The first user message is the task instruction.  Later user messages and
    tool results are agent-visible context.  Assistant messages are omitted:
    a model's own unsupported assertion must never become evidence merely by
    being repeated in its next request.
    """

    replayable = replay_request(request)
    messages = replayable["messages"]
    inferred_turn_index = infer_turn_index(messages)
    if turn_index_override is not None and (
        type(turn_index_override) is not int or turn_index_override < inferred_turn_index
    ):
        raise PhaseSidecarError(
            "turn_index_override must be an integer no earlier than the request history"
        )
    turn_index = (
        inferred_turn_index if turn_index_override is None else turn_index_override
    )
    digest = request_sha256 or sha256_json(request)
    if not isinstance(digest, str) or not digest:
        raise PhaseSidecarError("request_sha256 must be non-empty text")

    evidence: list[PublicEvidence] = []
    assistant_count = 0
    saw_instruction = False
    saw_user_message = False
    prefix = digest[:16]
    for message_index, message in enumerate(messages):
        role = message.get("role")
        if role == "assistant":
            assistant_count += 1
            continue
        if role == "system":
            continue
        if role not in {"user", "tool"}:
            # replay_request already constrains the dialect; keep this guard
            # local so future renderer changes cannot widen the boundary.
            raise PhaseSidecarError(f"messages[{message_index}] has non-public role {role!r}")
        is_instruction_message = role == "user" and not saw_user_message
        if role == "user":
            saw_user_message = True
        parts = _visible_text_parts(
            message.get("content"), path=f"messages[{message_index}].content"
        )
        for part_index, text in enumerate(parts):
            _assert_public_text(text, path=f"messages[{message_index}].content[{part_index}]")
            is_instruction = is_instruction_message
            source = (
                PublicEvidenceSource.USER_INSTRUCTION
                if is_instruction
                else PublicEvidenceSource.AGENT_VISIBLE_REQUEST
            )
            evidence.append(
                PublicEvidence(
                    evidence_id=f"req-{prefix}-m{message_index}-p{part_index}",
                    source=source,
                    turn_index=0 if is_instruction else assistant_count,
                    payload={"text": text},
                )
            )
            # Browser-use flattens its task, action history, and current DOM
            # into one user message at every decision. With an audited proxy
            # decision index, preserve that same public text as current-turn
            # observation evidence as well as the turn-zero instruction. No
            # new information is introduced by this second provenance role.
            if is_instruction and turn_index_override is not None:
                evidence.append(
                    PublicEvidence(
                        evidence_id=(
                            f"req-{prefix}-m{message_index}-p{part_index}-observation"
                        ),
                        source=PublicEvidenceSource.AGENT_VISIBLE_REQUEST,
                        turn_index=turn_index,
                        payload={"text": text},
                    )
                )
            if is_instruction:
                saw_instruction = True

    if not saw_instruction:
        raise PhaseSidecarError("request contains no textual user instruction")
    if not evidence:
        raise PhaseSidecarError("request contains no eligible public textual evidence")
    if any(item.turn_index > turn_index for item in evidence):
        raise PhaseSidecarError("request projection produced future-turn evidence")
    return turn_index, tuple(evidence)


def _reference(value: Any) -> EvidenceRef:
    if not isinstance(value, Mapping) or set(value) != {"evidence_id", "path"}:
        raise PhaseSidecarError("each evidence reference requires exactly evidence_id and path")
    evidence_id = value.get("evidence_id")
    path = value.get("path")
    if not isinstance(evidence_id, str) or not isinstance(path, list):
        raise PhaseSidecarError("evidence reference id/path have invalid types")
    try:
        return EvidenceRef(evidence_id=evidence_id, path=tuple(path))
    except (TypeError, ValueError) as exc:
        raise PhaseSidecarError(f"invalid evidence reference: {exc}") from exc


def _flatten_scalars(value: Any) -> Iterable[Any]:
    if value is None or type(value) in {str, int, float, bool}:
        yield value
        return
    if isinstance(value, list):
        if len(value) > 32:
            raise PhaseSidecarError("claim value lists are limited to 32 scalars")
        for child in value:
            if isinstance(child, (list, Mapping)):
                raise PhaseSidecarError("claim values must be scalars or flat scalar lists")
            yield child
        return
    raise PhaseSidecarError("claim values must be JSON scalars or flat scalar lists")


def _cited_values(
    references: Sequence[EvidenceRef], evidence_by_id: Mapping[str, PublicEvidence]
) -> list[Any]:
    values: list[Any] = []
    for reference in references:
        try:
            values.append(reference.resolve(evidence_by_id))
        except (KeyError, IndexError, TypeError) as exc:
            raise PhaseSidecarError(
                f"citation {reference.evidence_id}:{reference.path!r} does not resolve"
            ) from exc
    return values


def _assert_derived_value_grounded(
    *,
    value: Any,
    references: Sequence[EvidenceRef],
    evidence_by_id: Mapping[str, PublicEvidence],
) -> None:
    cited = _cited_values(references, evidence_by_id)
    cited_text = canonical_json(cited)
    for scalar in _flatten_scalars(value):
        if scalar is None:
            continue
        if type(scalar) is bool:
            raise PhaseSidecarError(
                "derived boolean claims are not evidence-safe; use a control label"
            )
        if isinstance(scalar, str):
            if scalar in _CONTROL_VALUES or scalar.casefold() in cited_text.casefold():
                continue
            raise PhaseSidecarError(f"derived value {scalar!r} is absent from its cited evidence")
        # Numbers must be displayed in the evidence.  This deliberately rules
        # out uncited arithmetic (especially invented checkout totals).
        try:
            expected = Decimal(str(scalar))
            displayed = {
                Decimal(match.group(0).replace(",", ""))
                for match in _DISPLAYED_NUMBER_PATTERN.finditer(cited_text)
            }
        except InvalidOperation as exc:
            raise PhaseSidecarError(f"derived numeric value {scalar!r} is invalid") from exc
        if expected not in displayed:
            raise PhaseSidecarError(f"derived numeric value {scalar!r} is absent from its evidence")


def teacher_privilege_from_extraction(
    item: PhaseExtractionInput,
    extracted: Mapping[str, Any],
) -> TeacherPrivilege:
    """Independently validate an untrusted extractor response."""

    if not isinstance(extracted, Mapping) or set(extracted) != {"phases"}:
        raise PhaseSidecarError("extractor output requires exactly one top-level phases object")
    phases = extracted.get("phases")
    if not isinstance(phases, Mapping) or set(phases) != {phase.value for phase in ShadowPhase}:
        raise PhaseSidecarError("extractor output must contain exactly all five phase names")

    evidence_by_id = {evidence.evidence_id: evidence for evidence in item.public_evidence}
    try:
        builder = ShadowPhaseStateBuilder(item.turn_index, item.public_evidence)
    except (TypeError, ValueError, PrivilegeAuditError) as exc:
        raise PhaseSidecarError(f"phase evidence failed same-turn audit: {exc}") from exc
    for phase in ShadowPhase:
        claims = phases[phase.value]
        if not isinstance(claims, list) or not claims:
            raise PhaseSidecarError(f"phase {phase.value!r} requires at least one claim")
        if len(claims) > 64:
            raise PhaseSidecarError(f"phase {phase.value!r} has too many claims")
        for claim_index, claim in enumerate(claims):
            path = f"phases.{phase.value}[{claim_index}]"
            required = {"key", "value", "status", "derivation", "evidence_refs"}
            if not isinstance(claim, Mapping) or set(claim) != required:
                raise PhaseSidecarError(f"{path} must contain exactly {sorted(required)}")
            key = claim.get("key")
            if key not in _PHASE_KEYS[phase]:
                raise PhaseSidecarError(f"{path}.key is outside the general phase vocabulary")
            raw_refs = claim.get("evidence_refs")
            if not isinstance(raw_refs, list) or not 1 <= len(raw_refs) <= 8:
                raise PhaseSidecarError(f"{path}.evidence_refs requires 1-8 citations")
            references = tuple(_reference(reference) for reference in raw_refs)
            try:
                status = ClaimStatus(claim.get("status"))
                derivation = ClaimDerivation(claim.get("derivation"))
            except ValueError as exc:
                raise PhaseSidecarError(f"{path} has an invalid status or derivation") from exc
            _cited_values(references, evidence_by_id)
            if (
                status is not ClaimStatus.UNKNOWN
                and key in _OBSERVATION_REQUIRED_KEYS
                and not any(
                    evidence_by_id[reference.evidence_id].source
                    is PublicEvidenceSource.AGENT_VISIBLE_REQUEST
                    for reference in references
                )
            ):
                raise PhaseSidecarError(
                    f"{path} must cite a displayed observation, not only the instruction"
                )
            if status is not ClaimStatus.UNKNOWN and derivation not in {
                ClaimDerivation.DIRECT,
            }:
                _assert_derived_value_grounded(
                    value=claim.get("value"),
                    references=references,
                    evidence_by_id=evidence_by_id,
                )
            try:
                builder.claim(
                    phase=phase,
                    key=key,
                    value=claim.get("value"),
                    evidence_refs=references,
                    status=status,
                    derivation=derivation,
                )
            except (TypeError, ValueError, PrivilegeAuditError) as exc:
                raise PhaseSidecarError(f"{path} failed claim audit: {exc}") from exc
    try:
        privilege = builder.build()
    except (TypeError, ValueError, PrivilegeAuditError) as exc:
        raise PhaseSidecarError(f"extracted state failed public-evidence audit: {exc}") from exc
    if privilege.state.turn_index != item.turn_index:
        raise PhaseSidecarError("phase state does not belong to the current decision turn")
    return privilege


_EXTRACTOR_SYSTEM = """You are a strict evidence-bound state extractor for a general web agent.
Organize ONLY the supplied public evidence into five phases: literal contract;
finite-frontier coverage; known/unknown/conflicting facts; feasible/Pareto choice
and explicit rejections; precommit identity/quantity/total. Return JSON only.

The exact schema is {"phases": {PHASE: [CLAIM, ...]}} with exactly these phases:
contract, coverage, fact_resolution, decision, precommit. Each CLAIM has exactly:
key, value, status, derivation, evidence_refs. Each evidence ref has exactly
evidence_id and path. Cite payload text with path ["text"].

Allowed keys by phase:
- contract: requirement, search_mode, objective, constraint, preference
- coverage: frontier_status, page_seen, page_total, candidate_seen, coverage_gap
- fact_resolution: known_fact, unknown_fact, conflicting_fact
- decision: feasible_candidate, rejected_candidate, pareto_candidate,
  provisional_choice, decision_gap
- precommit: selected_identity, selected_quantity, selected_total, precommit_gap

Values must be a scalar or flat scalar list. Quote/normalize only text or numbers
that occur in the cited evidence. Use status=unknown, value=null,
derivation=absence when evidence is insufficient. Never infer a missing product,
field, page, quantity, total, eligibility, or winner. Every phase must be nonempty.
Never emit credentials, private routes, evaluator state, rewards, or hidden labels."""


@dataclass(slots=True)
class OpenAIPhaseExtractor:
    """Frozen Qwen extractor behind an OpenAI-compatible endpoint."""

    base_url: str
    model: str
    model_revision: str
    api_key: str = ""
    timeout_seconds: float = 300.0
    max_completion_tokens: int = 4096
    client: httpx.Client | None = None

    def __post_init__(self) -> None:
        if not self.base_url.startswith(("http://", "https://")):
            raise ValueError("base_url must be HTTP(S)")
        if not self.model:
            raise ValueError("model must be non-empty")
        if not _REVISION_PATTERN.fullmatch(self.model_revision):
            raise ValueError("model_revision must be an immutable 40-character Git SHA")
        if self.timeout_seconds <= 0 or self.max_completion_tokens <= 0:
            raise ValueError("timeout and completion limit must be positive")

    @property
    def endpoint(self) -> str:
        root = self.base_url.rstrip("/")
        return f"{root}/chat/completions" if root.endswith("/v1") else f"{root}/v1/chat/completions"

    def descriptor(self) -> Mapping[str, Any]:
        # Endpoint and key are deliberately absent from persisted provenance.
        return {
            "kind": "openai_compatible_frozen_qwen",
            "model": self.model,
            "model_revision": self.model_revision,
            "sampling": {"temperature": 1.0, "top_p": 0.95, "top_k": 20},
        }

    def extract(self, item: PhaseExtractionInput) -> Mapping[str, Any]:
        headers = {"content-type": "application/json"}
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": _EXTRACTOR_SYSTEM},
                {"role": "user", "content": canonical_json(item.to_dict())},
            ],
            "response_format": {"type": "json_object"},
            "temperature": 1.0,
            "top_p": 0.95,
            "top_k": 20,
            "min_p": 0.0,
            "presence_penalty": 0.0,
            "repetition_penalty": 1.0,
            "max_completion_tokens": self.max_completion_tokens,
            "chat_template_kwargs": {"preserve_thinking": True},
            "stream": False,
        }
        http = self.client or httpx.Client(timeout=self.timeout_seconds)
        close = self.client is None
        try:
            response = http.post(self.endpoint, headers=headers, json=body)
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise PhaseSidecarError(f"phase extractor request failed: {exc}") from exc
        finally:
            if close:
                http.close()
        try:
            content = payload["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise PhaseSidecarError("phase extractor returned no assistant JSON content") from exc
        if not isinstance(content, str):
            raise PhaseSidecarError("phase extractor content must be JSON text")
        try:
            extracted = json.loads(content)
        except json.JSONDecodeError as exc:
            raise PhaseSidecarError("phase extractor content is not strict JSON") from exc
        if not isinstance(extracted, Mapping):
            raise PhaseSidecarError("phase extractor JSON must be an object")
        return extracted


def _validated_descriptor(extractor: PhaseExtractor) -> dict[str, Any]:
    descriptor = extractor.descriptor()
    if not isinstance(descriptor, Mapping):
        raise PhaseSidecarError("extractor descriptor must be an object")
    try:
        frozen = json.loads(json.dumps(descriptor, ensure_ascii=False, allow_nan=False))
    except (TypeError, ValueError) as exc:
        raise PhaseSidecarError("extractor descriptor must be finite JSON") from exc
    forbidden = audit_public_payload(frozen, root="extractor")
    if forbidden:
        raise PhaseSidecarError(
            "extractor descriptor contains credentials or headers: " + ", ".join(forbidden)
        )
    return frozen


def build_phase_sidecar(
    proxy_record: Mapping[str, Any],
    extractor: PhaseExtractor,
    *,
    split: str,
) -> dict[str, Any] | None:
    """Build one sidecar, or ``None`` for a non-student/unsuccessful call."""

    if not isinstance(proxy_record, Mapping):
        raise PhaseSidecarError("proxy record must be an object")
    if proxy_record.get("schema") != PROXY_TRACE_SCHEMA:
        raise PhaseSidecarError("unsupported proxy trace schema")
    if proxy_record.get("role", "student") != "student":
        return None
    status = proxy_record.get("status_code")
    if type(status) is not int:
        raise PhaseSidecarError("proxy status_code must be an integer")
    if not 200 <= status < 300:
        return None
    if not isinstance(split, str) or not split:
        raise PhaseSidecarError("split must be non-empty text")

    request = proxy_record.get("request")
    if not isinstance(request, Mapping):
        raise PhaseSidecarError("successful proxy record requires its original request")
    actual_hash = sha256_json(request)
    if proxy_record.get("request_sha256") != actual_hash:
        raise PhaseSidecarError("proxy request hash mismatch")
    session = proxy_record.get("session_sha256")
    if not isinstance(session, str) or not session:
        raise PhaseSidecarError("proxy record requires session_sha256")

    session_sequence = proxy_record.get("session_sequence")
    if session_sequence is None:
        turn_override = None
    elif type(session_sequence) is not int or session_sequence < 1:
        raise PhaseSidecarError("proxy session_sequence must be a positive integer")
    else:
        turn_override = session_sequence - 1
    turn_index, evidence = public_evidence_from_request(
        request,
        request_sha256=actual_hash,
        turn_index_override=turn_override,
    )
    item = PhaseExtractionInput(
        turn_index=turn_index,
        request_sha256=actual_hash,
        public_evidence=evidence,
    )
    extracted = extractor.extract(item)
    privilege = teacher_privilege_from_extraction(item, extracted)
    descriptor = _validated_descriptor(extractor)
    return {
        "schema": PRIVILEGE_SIDECAR_SCHEMA,
        "session_sha256": session,
        "request_sha256": actual_hash,
        "turn_index": turn_index,
        "split": split,
        "source_sequence": proxy_record.get("sequence"),
        "extractor": descriptor,
        "privilege": privilege.to_prompt_payload(),
    }


@dataclass(frozen=True, slots=True)
class SidecarBuildReport:
    input_records: int
    successful_decisions: int
    skipped_records: int
    output_sha256: str | None = None
    total_attempts: int = 0
    retried_decisions: int = 0
    resumed_decisions: int = 0
    max_attempts: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_records": self.input_records,
            "successful_decisions": self.successful_decisions,
            "skipped_records": self.skipped_records,
            "output_sha256": self.output_sha256,
            "total_attempts": self.total_attempts,
            "retried_decisions": self.retried_decisions,
            "resumed_decisions": self.resumed_decisions,
            "max_attempts": self.max_attempts,
        }


def build_phase_sidecars(
    proxy_records: Iterable[Mapping[str, Any]],
    extractor: PhaseExtractor,
    *,
    split: str,
    max_workers: int = 1,
) -> tuple[list[dict[str, Any]], SidecarBuildReport]:
    if type(max_workers) is not int or max_workers < 1:
        raise PhaseSidecarError("max_workers must be a positive integer")
    records = list(proxy_records)

    def build(record: Mapping[str, Any]) -> dict[str, Any] | None:
        return build_phase_sidecar(record, extractor, split=split)

    if max_workers == 1:
        built = map(build, records)
    else:
        pool = ThreadPoolExecutor(max_workers=max_workers)
        built = pool.map(build, records)

    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    skipped = 0
    try:
        for sidecar in built:
            if sidecar is None:
                skipped += 1
                continue
            identity = (sidecar["session_sha256"], sidecar["request_sha256"])
            if identity in seen:
                raise PhaseSidecarError("duplicate successful decision in proxy trace")
            seen.add(identity)
            rows.append(sidecar)
    finally:
        if max_workers != 1:
            pool.shutdown(wait=True, cancel_futures=True)
    return rows, SidecarBuildReport(len(records), len(rows), skipped)


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise PhaseSidecarError(f"{path}:{line_number}: invalid JSON") from exc
            if not isinstance(row, dict):
                raise PhaseSidecarError(f"{path}:{line_number}: row must be an object")
            rows.append(row)
    return rows


_SIDECAR_CHECKPOINT_SCHEMA = "harness-distill.phase-sidecar-checkpoint.v1"


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    )
    temporary = Path(handle.name)
    try:
        with handle:
            handle.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _load_checkpoint(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PhaseSidecarError(f"invalid sidecar checkpoint: {path}") from exc
    if not isinstance(value, dict):
        raise PhaseSidecarError(f"sidecar checkpoint is not an object: {path}")
    return value


def _safe_attempt_error(exc: Exception) -> dict[str, str]:
    # Extractor exceptions have already excluded headers/credentials.  Keep a
    # bounded diagnostic while preventing an arbitrary server body from
    # becoming a large or sensitive campaign artifact.
    return {
        "type": type(exc).__name__,
        "message": str(exc).replace("\n", " ")[:500],
    }


def _checkpointed_phase_sidecars(
    records: Sequence[Mapping[str, Any]],
    extractor: PhaseExtractor,
    *,
    split: str,
    checkpoint_dir: Path,
    max_attempts: int,
    max_workers: int,
) -> tuple[list[dict[str, Any]], SidecarBuildReport]:
    """Build with a fixed, per-item retry policy and durable item journals."""

    descriptor = _validated_descriptor(extractor)
    policy = {"maximum_attempts": max_attempts, "selection": "first_valid_no_outcome"}
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def build(index_record: tuple[int, Mapping[str, Any]]) -> tuple[Any, int, bool]:
        index, record = index_record
        # Skips are deterministic and make no model call.
        if record.get("role", "student") != "student" or record.get("status_code") not in range(
            200, 300
        ):
            return None, 0, False
        input_sha = sha256_json(
            {
                "proxy_record": record,
                "split": split,
                "extractor": descriptor,
                "retry_policy": policy,
            }
        )
        path = checkpoint_dir / f"{index:08d}-{input_sha}.json"
        attempts = 0
        errors: list[dict[str, Any]] = []
        resumed = False
        if path.exists():
            checkpoint = _load_checkpoint(path)
            if (
                checkpoint.get("schema") != _SIDECAR_CHECKPOINT_SCHEMA
                or checkpoint.get("input_sha256") != input_sha
                or checkpoint.get("retry_policy") != policy
            ):
                raise PhaseSidecarError(f"sidecar checkpoint identity drifted: {path}")
            attempts = checkpoint.get("attempts_used")
            if type(attempts) is not int or not 0 <= attempts <= max_attempts:
                raise PhaseSidecarError(f"sidecar checkpoint attempt count is invalid: {path}")
            raw_errors = checkpoint.get("errors", [])
            if not isinstance(raw_errors, list):
                raise PhaseSidecarError(f"sidecar checkpoint errors are invalid: {path}")
            errors = list(raw_errors)
            if checkpoint.get("status") == "complete":
                sidecar = checkpoint.get("sidecar")
                if not isinstance(sidecar, Mapping):
                    raise PhaseSidecarError(f"completed checkpoint has no sidecar: {path}")
                if checkpoint.get("sidecar_sha256") != sha256_json(sidecar):
                    raise PhaseSidecarError(f"completed sidecar checkpoint mutated: {path}")
                return dict(sidecar), attempts, True
            resumed = True

        while attempts < max_attempts:
            attempts += 1
            # Persist before the remote call.  A process death consumes this
            # attempt rather than silently drawing an extra stochastic sample.
            _atomic_json(
                path,
                {
                    "schema": _SIDECAR_CHECKPOINT_SCHEMA,
                    "input_sha256": input_sha,
                    "retry_policy": policy,
                    "status": "in_progress",
                    "attempts_used": attempts,
                    "errors": errors,
                },
            )
            try:
                sidecar = build_phase_sidecar(record, extractor, split=split)
                if sidecar is None:
                    raise PhaseSidecarError("eligible decision unexpectedly produced no sidecar")
            except Exception as exc:
                errors.append({"attempt": attempts, **_safe_attempt_error(exc)})
                _atomic_json(
                    path,
                    {
                        "schema": _SIDECAR_CHECKPOINT_SCHEMA,
                        "input_sha256": input_sha,
                        "retry_policy": policy,
                        "status": "failed",
                        "attempts_used": attempts,
                        "errors": errors,
                    },
                )
                continue
            _atomic_json(
                path,
                {
                    "schema": _SIDECAR_CHECKPOINT_SCHEMA,
                    "input_sha256": input_sha,
                    "retry_policy": policy,
                    "status": "complete",
                    "attempts_used": attempts,
                    "errors": errors,
                    "sidecar_sha256": sha256_json(sidecar),
                    "sidecar": sidecar,
                },
            )
            return sidecar, attempts, resumed
        raise PhaseSidecarError(
            f"phase extraction exhausted fixed {max_attempts}-attempt policy for item {index}: "
            f"{errors[-1]['message'] if errors else 'attempt interrupted'}"
        )

    indexed = list(enumerate(records))
    if max_workers == 1:
        results = [build(item) for item in indexed]
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            results = list(pool.map(build, indexed))

    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    skipped = 0
    total_attempts = 0
    retried = 0
    resumed = 0
    for sidecar, attempts, was_resumed in results:
        if sidecar is None:
            skipped += 1
            continue
        identity = (sidecar["session_sha256"], sidecar["request_sha256"])
        if identity in seen:
            raise PhaseSidecarError("duplicate successful decision in proxy trace")
        seen.add(identity)
        rows.append(sidecar)
        total_attempts += attempts
        retried += int(attempts > 1)
        resumed += int(was_resumed)
    return rows, SidecarBuildReport(
        input_records=len(records),
        successful_decisions=len(rows),
        skipped_records=skipped,
        total_attempts=total_attempts,
        retried_decisions=retried,
        resumed_decisions=resumed,
        max_attempts=max_attempts,
    )


def build_phase_sidecar_file(
    proxy_path: str | Path,
    output_path: str | Path,
    extractor: PhaseExtractor,
    *,
    split: str,
    max_workers: int = 1,
    checkpoint_dir: str | Path | None = None,
    max_attempts: int = 1,
) -> SidecarBuildReport:
    """Build canonical JSONL atomically with optional resumable item journals."""

    if type(max_attempts) is not int or max_attempts < 1:
        raise PhaseSidecarError("max_attempts must be a positive integer")
    records = _read_jsonl(proxy_path)
    if checkpoint_dir is None:
        if max_attempts != 1:
            raise PhaseSidecarError("checkpoint_dir is required when retries are enabled")
        rows, report = build_phase_sidecars(
            records, extractor, split=split, max_workers=max_workers
        )
    else:
        rows, report = _checkpointed_phase_sidecars(
            records,
            extractor,
            split=split,
            checkpoint_dir=Path(checkpoint_dir),
            max_attempts=max_attempts,
            max_workers=max_workers,
        )
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=destination.parent,
        prefix=f".{destination.name}.",
        suffix=".tmp",
        delete=False,
    )
    temporary = Path(handle.name)
    try:
        with handle:
            for row in rows:
                handle.write(canonical_json(row) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        data = temporary.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        os.replace(temporary, destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return SidecarBuildReport(
        input_records=report.input_records,
        successful_decisions=report.successful_decisions,
        skipped_records=report.skipped_records,
        output_sha256=digest,
        total_attempts=report.total_attempts,
        retried_decisions=report.retried_decisions,
        resumed_decisions=report.resumed_decisions,
        max_attempts=report.max_attempts,
    )
