"""Exact-token records for paired-context policy distillation.

The student and shadow teacher are allowed to see different prefixes, but
they must score *the same token ids* for the sampled completion.  Keeping that
invariant in the data model prevents a surprisingly easy failure mode: decode
the student's answer, render a second chat template, and accidentally train on
a different sequence after re-tokenization.

This module deliberately knows nothing about AgentArena or any benchmark
oracle.  Records contain token ids and hashes/provenance identifiers only.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

IGNORE_INDEX = -100


def _token_tuple(name: str, values: Iterable[int], *, nonempty: bool) -> tuple[int, ...]:
    tokens = tuple(values)
    if nonempty and not tokens:
        raise ValueError(f"{name} must not be empty")
    for index, token in enumerate(tokens):
        # bool is an int subclass but is never a meaningful token id.
        if type(token) is not int or token < 0:
            raise ValueError(f"{name}[{index}] must be a non-negative integer token id")
    return tokens


def assistant_only_mask(
    token_count: int,
    assistant_spans: Iterable[tuple[int, int]],
) -> tuple[bool, ...]:
    """Return a mask for half-open assistant spans in a token sequence.

    Spans must be ordered and non-overlapping.  Requiring an explicit mask is
    useful for multi-turn packed records where tool/environment text can occur
    between assistant turns.  For a single sampled assistant completion, use
    one span ``(0, token_count)``.
    """

    if type(token_count) is not int or token_count < 0:
        raise ValueError("token_count must be a non-negative integer")

    mask = [False] * token_count
    previous_end = 0
    for span_index, span in enumerate(assistant_spans):
        if (
            not isinstance(span, (tuple, list))
            or len(span) != 2
            or type(span[0]) is not int
            or type(span[1]) is not int
        ):
            raise ValueError(f"assistant_spans[{span_index}] must be an integer (start, end) pair")
        start, end = span
        if start < 0 or end < 0 or start >= end or end > token_count:
            raise ValueError(
                f"assistant_spans[{span_index}]={span!r} is outside [0, {token_count})"
            )
        if span_index and start < previous_end:
            raise ValueError("assistant spans must be ordered and non-overlapping")
        for index in range(start, end):
            mask[index] = True
        previous_end = end
    return tuple(mask)


def _mask_tuple(values: Iterable[bool], expected_length: int) -> tuple[bool, ...]:
    mask = tuple(values)
    if len(mask) != expected_length:
        raise ValueError(
            "assistant_mask length must equal completion_ids length "
            f"({len(mask)} != {expected_length})"
        )
    for index, value in enumerate(mask):
        if type(value) is not bool:
            raise ValueError(f"assistant_mask[{index}] must be bool")
    if not any(mask):
        raise ValueError("assistant_mask must select at least one completion token")
    return mask


@dataclass(frozen=True, slots=True)
class PairedTokenAlignment:
    """The two causal-LM inputs and their aligned completion positions."""

    student_input_ids: tuple[int, ...]
    teacher_input_ids: tuple[int, ...]
    completion_ids: tuple[int, ...]
    assistant_mask: tuple[bool, ...]
    student_prediction_positions: tuple[int, ...]
    teacher_prediction_positions: tuple[int, ...]

    def labels(self, side: str, *, ignore_index: int = IGNORE_INDEX) -> tuple[int, ...]:
        """Return Hugging Face-style labels for one side's full input.

        Prefix and non-assistant tokens are ignored.  The returned labels line
        up with the input token positions; a causal language model performs the
        usual one-token shift internally.
        """

        if side == "student":
            input_ids = self.student_input_ids
        elif side == "teacher":
            input_ids = self.teacher_input_ids
        else:
            raise ValueError("side must be 'student' or 'teacher'")
        prefix_length = len(input_ids) - len(self.completion_ids)
        return (ignore_index,) * prefix_length + tuple(
            token if active else ignore_index
            for token, active in zip(self.completion_ids, self.assistant_mask)
        )

    @property
    def selected_completion_ids(self) -> tuple[int, ...]:
        return tuple(
            token for token, active in zip(self.completion_ids, self.assistant_mask) if active
        )


@dataclass(frozen=True, slots=True)
class PairedDecisionTrace:
    """One student-sampled decision scored under two context prefixes.

    ``completion_ids`` is the sole source of truth for both sides.  Callers
    should never decode it and re-tokenize it for the teacher.
    """

    trace_id: str
    task_id: str
    turn_index: int
    student_prefix_ids: tuple[int, ...]
    teacher_prefix_ids: tuple[int, ...]
    completion_ids: tuple[int, ...]
    assistant_mask: tuple[bool, ...]
    tokenizer_revision: str
    model_revision: str
    evidence_digest: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for name in (
            "trace_id",
            "task_id",
            "tokenizer_revision",
            "model_revision",
            "evidence_digest",
        ):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if type(self.turn_index) is not int or self.turn_index < 0:
            raise ValueError("turn_index must be a non-negative integer")

        student_prefix = _token_tuple("student_prefix_ids", self.student_prefix_ids, nonempty=True)
        teacher_prefix = _token_tuple("teacher_prefix_ids", self.teacher_prefix_ids, nonempty=True)
        completion = _token_tuple("completion_ids", self.completion_ids, nonempty=True)
        mask = _mask_tuple(self.assistant_mask, len(completion))
        if not isinstance(self.metadata, Mapping):
            raise ValueError("metadata must be a mapping")

        # Normalize mutable input containers at the boundary of this frozen
        # record.  Nested metadata is intentionally not used in loss math.
        object.__setattr__(self, "student_prefix_ids", student_prefix)
        object.__setattr__(self, "teacher_prefix_ids", teacher_prefix)
        object.__setattr__(self, "completion_ids", completion)
        object.__setattr__(self, "assistant_mask", mask)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @classmethod
    def from_full_sequences(
        cls,
        *,
        trace_id: str,
        task_id: str,
        turn_index: int,
        student_input_ids: Sequence[int],
        teacher_input_ids: Sequence[int],
        student_prefix_length: int,
        teacher_prefix_length: int,
        assistant_mask: Sequence[bool] | None = None,
        tokenizer_revision: str,
        model_revision: str,
        evidence_digest: str,
        metadata: Mapping[str, Any] | None = None,
    ) -> PairedDecisionTrace:
        """Construct a trace only if both full sequences share an exact suffix."""

        if type(student_prefix_length) is not int or student_prefix_length < 1:
            raise ValueError("student_prefix_length must be at least 1")
        if type(teacher_prefix_length) is not int or teacher_prefix_length < 1:
            raise ValueError("teacher_prefix_length must be at least 1")
        student = _token_tuple("student_input_ids", student_input_ids, nonempty=True)
        teacher = _token_tuple("teacher_input_ids", teacher_input_ids, nonempty=True)
        if student_prefix_length >= len(student):
            raise ValueError("student sequence must contain a non-empty completion")
        if teacher_prefix_length >= len(teacher):
            raise ValueError("teacher sequence must contain a non-empty completion")
        student_completion = student[student_prefix_length:]
        teacher_completion = teacher[teacher_prefix_length:]
        if student_completion != teacher_completion:
            raise ValueError(
                "student and teacher sequences must share identical completion token ids"
            )
        mask = (
            tuple(True for _ in student_completion)
            if assistant_mask is None
            else tuple(assistant_mask)
        )
        return cls(
            trace_id=trace_id,
            task_id=task_id,
            turn_index=turn_index,
            student_prefix_ids=student[:student_prefix_length],
            teacher_prefix_ids=teacher[:teacher_prefix_length],
            completion_ids=student_completion,
            assistant_mask=mask,
            tokenizer_revision=tokenizer_revision,
            model_revision=model_revision,
            evidence_digest=evidence_digest,
            metadata={} if metadata is None else metadata,
        )

    def alignment(self) -> PairedTokenAlignment:
        completion_length = len(self.completion_ids)
        student_prefix_length = len(self.student_prefix_ids)
        teacher_prefix_length = len(self.teacher_prefix_ids)
        return PairedTokenAlignment(
            student_input_ids=self.student_prefix_ids + self.completion_ids,
            teacher_input_ids=self.teacher_prefix_ids + self.completion_ids,
            completion_ids=self.completion_ids,
            assistant_mask=self.assistant_mask,
            # Logit at position prefix_len - 1 predicts completion token 0.
            student_prediction_positions=tuple(
                range(
                    student_prefix_length - 1,
                    student_prefix_length + completion_length - 1,
                )
            ),
            teacher_prediction_positions=tuple(
                range(
                    teacher_prefix_length - 1,
                    teacher_prefix_length + completion_length - 1,
                )
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "task_id": self.task_id,
            "turn_index": self.turn_index,
            "student_prefix_ids": list(self.student_prefix_ids),
            "teacher_prefix_ids": list(self.teacher_prefix_ids),
            "completion_ids": list(self.completion_ids),
            "assistant_mask": list(self.assistant_mask),
            "tokenizer_revision": self.tokenizer_revision,
            "model_revision": self.model_revision,
            "evidence_digest": self.evidence_digest,
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> PairedDecisionTrace:
        required = {
            "trace_id",
            "task_id",
            "turn_index",
            "student_prefix_ids",
            "teacher_prefix_ids",
            "completion_ids",
            "assistant_mask",
            "tokenizer_revision",
            "model_revision",
            "evidence_digest",
        }
        missing = sorted(required - set(value))
        if missing:
            raise ValueError(f"paired trace is missing required fields: {missing}")
        return cls(
            trace_id=value["trace_id"],
            task_id=value["task_id"],
            turn_index=value["turn_index"],
            student_prefix_ids=value["student_prefix_ids"],
            teacher_prefix_ids=value["teacher_prefix_ids"],
            completion_ids=value["completion_ids"],
            assistant_mask=value["assistant_mask"],
            tokenizer_revision=value["tokenizer_revision"],
            model_revision=value["model_revision"],
            evidence_digest=value["evidence_digest"],
            metadata=value.get("metadata", {}),
        )
