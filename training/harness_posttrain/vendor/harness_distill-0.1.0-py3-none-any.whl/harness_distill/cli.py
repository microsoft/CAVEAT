"""Resumable phase driver for the single-job B200 distillation campaign."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import traceback
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .config import Campaign, atomic_json
from .evaluation import run_final_evaluation, run_headroom
from .generation import generate_campaign_data
from .model_merge import verify_and_merge
from .model_smoke import run_full_model_smoke

PHASES = (
    "validate-config",
    "smoke",
    "headroom",
    "generate",
    "sft",
    "distill",
    "merge",
    "eval",
)


def _canonical(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")
    )


def _result_digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _marker_path(output: Path, phase: str) -> Path:
    return output / "phases" / f"{phase}.json"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _attest_path(path: Path) -> dict[str, Any]:
    target = path.resolve()
    if target.is_file():
        return {
            "path": str(target),
            "kind": "file",
            "bytes": target.stat().st_size,
            "sha256": _sha256_file(target),
        }
    if not target.is_dir():
        raise RuntimeError(f"required completed-phase artifact is missing: {target}")
    digest = hashlib.sha256()
    file_count = 0
    total_bytes = 0
    for candidate in sorted(item for item in target.rglob("*") if item.is_file()):
        relative = candidate.relative_to(target).as_posix()
        size = candidate.stat().st_size
        entry = {
            "path": relative,
            "bytes": size,
            "sha256": _sha256_file(candidate),
            "symlink_target": os.readlink(candidate) if candidate.is_symlink() else None,
        }
        encoded = _canonical(entry).encode()
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        file_count += 1
        total_bytes += size
    return {
        "path": str(target),
        "kind": "directory",
        "file_count": file_count,
        "total_bytes": total_bytes,
        "tree_sha256": digest.hexdigest(),
    }


def _phase_artifact_paths(
    campaign: Campaign,
    output: Path,
    phase: str,
    result: Mapping[str, Any],
) -> list[Path]:
    """Semantically validate a phase result and return its immutable outputs."""

    def same_json(path: Path) -> None:
        if not path.is_file():
            raise RuntimeError(f"completed {phase} artifact is missing: {path}")
        value = json.loads(path.read_text(encoding="utf-8"))
        if _canonical(value) != _canonical(result):
            raise RuntimeError(f"completed {phase} result differs from {path}")

    if phase == "validate-config":
        path = output / "validation.json"
        same_json(path)
        return [path]
    if phase == "smoke":
        gate = output / "smoke" / "gate.json"
        same_json(gate)
        report = Path(str(result.get("report", ""))).resolve()
        report_value = json.loads(report.read_text(encoding="utf-8"))
        snapshot = Path(str(result.get("resolved_snapshot", ""))).resolve()
        if (
            report_value.get("status") != "ok"
            or Path(str(report_value.get("resolved_snapshot", ""))).resolve() != snapshot
        ):
            raise RuntimeError("smoke report does not attest its resolved snapshot")
        return [gate, report.parent, snapshot]
    if phase == "headroom":
        selected = output / "selected_model.json"
        same_json(selected)
        if (
            result.get("schema") != "harness-distill.selected-model.v1"
            or result.get("campaign_sha256") != campaign.digest
        ):
            raise RuntimeError("selected-model artifact is incompatible with the campaign")
        snapshot = Path(str(result.get("snapshot", ""))).resolve()
        return [selected, output / "eval" / "headroom", snapshot]
    if phase == "generate":
        manifest = output / "data" / "procedural" / "manifest.json"
        same_json(manifest)
        if result.get("campaign_sha256") != campaign.digest:
            raise RuntimeError("procedural manifest belongs to another campaign")
        return [output / "data" / "procedural"]
    if phase in {"sft", "distill"}:
        from .campaign_phases import (
            _validated_phase_result,
            resolve_selected_adapter,
        )

        phase_file = output / "checkpoints" / f"{phase}_phase.json"
        validated = _validated_phase_result(phase_file, campaign)
        if validated is None or _canonical(validated) != _canonical(result):
            raise RuntimeError(f"{phase} phase result failed semantic validation")
        if phase == "sft":
            return [
                phase_file,
                output / "checkpoints" / "prime-sft",
                output / "checkpoints" / "launch-sft",
                output / "models" / "stages" / "sft",
                output / "data" / "sft" / "seed",
                output / "rollouts" / "seed",
                output / "configs" / "generated-sft.toml",
            ]
        resolve_selected_adapter(output)
        generated = sorted((output / "configs").glob("generated-*-round-*.toml"))
        if not generated:
            raise RuntimeError("distillation generated no immutable PRIME configurations")
        return [
            phase_file,
            output / "checkpoints" / "selection.json",
            output / "models" / "stages",
            output / "rollouts" / "on-policy",
            *sorted((output / "checkpoints").glob("distill-round-*")),
            *generated,
        ]
    if phase == "merge":
        provenance = output / "models" / "merged" / "merge_provenance.json"
        same_json(provenance)
        if result.get("status") != "ok":
            raise RuntimeError("merged checkpoint provenance is not successful")
        return [output / "models" / "merged"]
    if phase == "eval":
        comparison = output / "eval" / "full" / "comparison.json"
        same_json(comparison)
        if result.get("schema") != "harness-distill.final-evaluation.v1" or result.get(
            "observed_runs"
        ) != result.get("expected_runs"):
            raise RuntimeError("final evaluation result is incomplete")
        return [output / "eval" / "full"]
    raise RuntimeError(f"no artifact validator exists for phase {phase!r}")


def _artifact_attestation(
    campaign: Campaign,
    output: Path,
    phase: str,
    result: Mapping[str, Any],
) -> dict[str, Any]:
    paths = _phase_artifact_paths(campaign, output, phase, result)
    resolved: set[Path] = set()
    roots = []
    for path in paths:
        target = path.resolve()
        if target in resolved:
            continue
        resolved.add(target)
        roots.append(_attest_path(target))
    payload = {
        "schema": "harness-distill.phase-artifacts.v1",
        "phase": phase,
        "roots": roots,
    }
    payload["digest"] = _result_digest(roots)
    return payload


def _completed(campaign: Campaign, output: Path, phase: str) -> dict[str, Any] | None:
    marker = _marker_path(output, phase)
    if not marker.is_file():
        return None
    try:
        value = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"cannot resume corrupt phase marker: {marker}") from exc
    if (
        value.get("schema") != "harness-distill.phase.v1"
        or value.get("status") != "complete"
        or value.get("campaign_sha256") != campaign.digest
    ):
        raise RuntimeError(f"incompatible phase marker already exists: {marker}")
    result = value.get("result")
    if _result_digest(result) != value.get("result_sha256"):
        raise RuntimeError(f"phase marker result hash mismatch: {marker}")
    expected_artifacts = value.get("artifact_attestation")
    if not isinstance(expected_artifacts, dict):
        raise RuntimeError(f"phase marker lacks artifact attestation: {marker}")
    current_artifacts = _artifact_attestation(campaign, output, phase, result)
    if current_artifacts != expected_artifacts:
        raise RuntimeError(f"completed phase artifacts changed: {marker}")
    return value


def _record_complete(
    campaign: Campaign, output: Path, phase: str, result: dict[str, Any]
) -> dict[str, Any]:
    artifacts = _artifact_attestation(campaign, output, phase, result)
    marker = {
        "schema": "harness-distill.phase.v1",
        "status": "complete",
        "phase": phase,
        "campaign_sha256": campaign.digest,
        "result_sha256": _result_digest(result),
        "result": result,
        "artifact_attestation": artifacts,
    }
    atomic_json(_marker_path(output, phase), marker)
    return marker


def _record_failure(campaign: Campaign, output: Path, phase: str, exc: BaseException) -> None:
    # Exception text and a stack are useful, but never serialize environment
    # variables, request headers, model calls, or process command lines here.
    atomic_json(
        output / "phases" / f"{phase}.failure.json",
        {
            "schema": "harness-distill.phase-failure.v1",
            "status": "failed",
            "phase": phase,
            "campaign_sha256": campaign.digest,
            "exception_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        },
    )


def _validate(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .split import assert_split_disjoint

    assert_split_disjoint()
    result = {
        "status": "ok",
        "campaign_sha256": campaign.digest,
        "model_order": list(campaign.models["selection_gate"]["order"]),
        "procedural_tasks": int(campaign.campaign["data"]["total_tasks"]),
        "evaluation_runs": int(campaign.evaluation["expected_runs"]["both_arms_full"]),
    }
    atomic_json(output / "validation.json", result)
    return result


def _smoke(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .plugin_preflight import run_decision_replay_plugin_preflight

    plugin_report = run_decision_replay_plugin_preflight()
    atomic_json(output / "preflight" / "decision-replay-before-smoke.json", plugin_report)
    role = str(campaign.models["selection_gate"]["order"][0])
    report = run_full_model_smoke(
        campaign.root / campaign.campaign["model_config"],
        output / "smoke" / role,
        role=role,
        rank=8,
        alpha=16,
    )
    result = {
        "status": "ok",
        "role": role,
        "model_id": campaign.model(role)["model_id"],
        "report": str(output / "smoke" / role / "smoke_report.json"),
        "resolved_snapshot": report["resolved_snapshot"],
    }
    atomic_json(output / "smoke" / "gate.json", result)
    return result


def _headroom(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .plugin_preflight import run_decision_replay_plugin_preflight

    plugin_report = run_decision_replay_plugin_preflight()
    atomic_json(output / "preflight" / "decision-replay-before-headroom.json", plugin_report)
    selected = run_headroom(campaign, output)
    smoke_gate = output / "smoke" / "gate.json"
    smoke_role = None
    if smoke_gate.is_file():
        smoke_role = json.loads(smoke_gate.read_text(encoding="utf-8")).get("role")
    if selected["role"] != smoke_role:
        role = str(selected["role"])
        run_full_model_smoke(
            campaign.root / campaign.campaign["model_config"],
            output / "smoke" / role,
            role=role,
            rank=8,
            alpha=16,
        )
        selected["fallback_smoke_report"] = str(output / "smoke" / role / "smoke_report.json")
        atomic_json(output / "selected_model.json", selected)
    return selected


def _generate(campaign: Campaign, output: Path) -> dict[str, Any]:
    return generate_campaign_data(campaign, output)


def _sft(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .campaign_phases import run_sft_phase

    return run_sft_phase(campaign, output)


def _distill(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .campaign_phases import run_distillation_phase

    return run_distillation_phase(campaign, output)


def _merge(campaign: Campaign, output: Path) -> dict[str, Any]:
    from .campaign_phases import resolve_selected_adapter

    selected = json.loads((output / "selected_model.json").read_text(encoding="utf-8"))
    adapter = resolve_selected_adapter(output)
    merged_dir = output / "models" / "merged"
    return verify_and_merge(
        campaign.root / campaign.campaign["model_config"],
        adapter,
        merged_dir,
        role=str(selected["role"]),
    )


def _eval(campaign: Campaign, output: Path) -> dict[str, Any]:
    selected = json.loads((output / "selected_model.json").read_text(encoding="utf-8"))
    merged = output / "models" / "merged"
    if not (merged / "merge_provenance.json").is_file():
        raise RuntimeError("verified merged model is missing")
    return run_final_evaluation(
        campaign,
        output,
        base_model_path=str(selected["snapshot"]),
        trained_model_path=merged,
        served_model_name=str(selected["model"]["model_id"]),
    )


RUNNERS: dict[str, Callable[[Campaign, Path], dict[str, Any]]] = {
    "validate-config": _validate,
    "smoke": _smoke,
    "headroom": _headroom,
    "generate": _generate,
    "sft": _sft,
    "distill": _distill,
    "merge": _merge,
    "eval": _eval,
}


def execute_phase(
    campaign: Campaign,
    output_dir: str | Path,
    phase: str,
    *,
    runners: dict[str, Callable[[Campaign, Path], dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    if phase not in PHASES:
        raise ValueError(f"unknown phase {phase!r}")
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    prior = _completed(campaign, output, phase)
    if prior is not None:
        return prior
    selected_runners = RUNNERS if runners is None else runners
    try:
        result = selected_runners[phase](campaign, output)
        if not isinstance(result, dict):
            raise TypeError(f"{phase} runner did not return a result mapping")
        return _record_complete(campaign, output, phase, result)
    except BaseException as exc:
        _record_failure(campaign, output, phase, exc)
        raise


def run_campaign(campaign: Campaign, output_dir: str | Path) -> dict[str, Any]:
    completed = []
    for phase in PHASES:
        execute_phase(campaign, output_dir, phase)
        completed.append(phase)
    result = {
        "schema": "harness-distill.campaign-completion.v1",
        "campaign_sha256": campaign.digest,
        "phases": completed,
        "status": "complete",
    }
    atomic_json(Path(output_dir).resolve() / "campaign_complete.json", result)
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=(*PHASES, "campaign"))
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    campaign = Campaign.load(args.config)
    result = (
        run_campaign(campaign, args.output)
        if args.phase == "campaign"
        else execute_phase(campaign, args.output, args.phase)
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
