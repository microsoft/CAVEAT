"""Deterministic, read-only reporting for an existing final evaluation.

This module deliberately has no serving or rollout entry points.  It consumes
the sealed ``eval/full/{base,trained}`` artifacts, re-scores their trajectories
with the campaign's existing scorer, and writes a report outside the campaign
root.  Missing raw diagnostics are disclosed as unavailable; they are never
estimated from text or from unrelated counters.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import atomic_json, load_yaml
from .evaluation import (
    _paired_task_stratified_bootstrap,
    _summarize_records,
    score_amazon_runs,
)
from .rollouts import _validated_model_identity, amazon_specs

REPORT_SCHEMA = "harness-distill.post-training-evaluation-report.v1"
MANIFEST_SCHEMA = "harness-distill.post-training-evaluation-manifest.v1"
BOOTSTRAP_SEED = 5603
BOOTSTRAP_DRAWS = 10_000
ARMS = ("base", "trained")


class ExistingEvaluationError(ValueError):
    """Raised when sealed evaluation evidence is missing or inconsistent."""


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class _ObservedFile:
    relative_path: str
    size: int
    sha256: str
    device: int = field(repr=False)
    inode: int = field(repr=False)
    mtime_ns: int = field(repr=False)

    def public(self) -> dict[str, Any]:
        return {
            "path": self.relative_path,
            "bytes": self.size,
            "sha256": self.sha256,
        }


class _ReadOnlyEvidence:
    """Read regular files once and prove their observed identity stayed fixed."""

    def __init__(self, root: Path):
        self.root = root
        self._files: dict[str, _ObservedFile] = {}

    def _path(self, relative_path: str) -> Path:
        path = self.root / relative_path
        try:
            path.relative_to(self.root)
        except ValueError as exc:  # pragma: no cover - all callers use literals/run IDs
            raise ExistingEvaluationError(f"input escapes campaign root: {path}") from exc
        if path.is_symlink() or not path.is_file():
            raise ExistingEvaluationError(f"required input is not a regular file: {path}")
        return path

    def read_bytes(self, relative_path: str) -> bytes:
        if relative_path in self._files:
            return (self.root / relative_path).read_bytes()
        path = self._path(relative_path)
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        identity_before = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        identity_after = (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
        if identity_before != identity_after or len(data) != after.st_size:
            raise ExistingEvaluationError(f"input changed while it was read: {path}")
        self._files[relative_path] = _ObservedFile(
            relative_path=relative_path,
            size=len(data),
            sha256=_sha256_bytes(data),
            device=after.st_dev,
            inode=after.st_ino,
            mtime_ns=after.st_mtime_ns,
        )
        return data

    def read_json(self, relative_path: str) -> dict[str, Any]:
        try:
            value = json.loads(self.read_bytes(relative_path))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ExistingEvaluationError(f"invalid JSON input: {relative_path}") from exc
        if not isinstance(value, dict):
            raise ExistingEvaluationError(f"JSON input is not an object: {relative_path}")
        return value

    def optional_bytes(self, relative_path: str) -> bytes | None:
        path = self.root / relative_path
        if not path.exists() and not path.is_symlink():
            return None
        return self.read_bytes(relative_path)

    def assert_unchanged(self) -> None:
        for observed in self._files.values():
            path = self._path(observed.relative_path)
            current = path.stat()
            if (
                current.st_dev,
                current.st_ino,
                current.st_size,
                current.st_mtime_ns,
            ) != (observed.device, observed.inode, observed.size, observed.mtime_ns):
                raise ExistingEvaluationError(f"input changed during report generation: {path}")
            if _sha256_file(path) != observed.sha256:
                raise ExistingEvaluationError(
                    f"input bytes changed during report generation: {path}"
                )

    def manifest(self) -> dict[str, Any]:
        files = [self._files[key].public() for key in sorted(self._files)]
        return {
            "schema": "harness-distill.read-only-evaluation-inputs.v1",
            "file_count": len(files),
            "files": files,
            "digest": hashlib.sha256(_canonical(files).encode("utf-8")).hexdigest(),
        }


def _jsonl(raw: bytes, relative_path: str) -> list[dict[str, Any]]:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ExistingEvaluationError(f"non-UTF-8 proxy trace: {relative_path}") from exc
    rows: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ExistingEvaluationError(
                f"invalid proxy JSONL at {relative_path}:{line_number}"
            ) from exc
        if not isinstance(row, dict):
            raise ExistingEvaluationError(
                f"proxy JSONL row is not an object at {relative_path}:{line_number}"
            )
        rows.append(row)
    return rows


def _expected_matrix(evaluation: Mapping[str, Any]) -> dict[str, tuple[str, str, str, int]]:
    if evaluation.get("environment") != "amazon":
        raise ExistingEvaluationError("post-training reporter requires environment='amazon'")
    scenarios = evaluation.get("scenarios")
    variants = evaluation.get("variants")
    conditions = evaluation.get("conditions")
    repetitions = evaluation.get("repetitions")
    if not all(
        isinstance(values, list)
        and values
        and len(values) == len(set(values))
        and all(isinstance(value, str) and value for value in values)
        for values in (scenarios, variants, conditions)
    ):
        raise ExistingEvaluationError("scenarios, variants, and conditions must be unique text")
    if set(conditions) != {"clean", "combined"}:
        raise ExistingEvaluationError("final evaluation must contain clean and combined only")
    if type(repetitions) is not int or repetitions < 1:
        raise ExistingEvaluationError("evaluation repetitions must be a positive integer")
    matrix: dict[str, tuple[str, str, str, int]] = {}
    for scenario in scenarios:
        for variant in variants:
            for condition in conditions:
                for repetition in range(1, repetitions + 1):
                    run_id = f"{scenario}-{variant}-{condition}-r{repetition}"
                    matrix[run_id] = (scenario, variant, condition, repetition)
    expected = evaluation.get("expected_runs") or {}
    if (
        len(matrix) != 120
        or expected.get("per_arm_full") != len(matrix)
        or expected.get("both_arms_full") != 2 * len(matrix)
        or expected.get("per_arm_held_out_confirmatory") != 96
    ):
        raise ExistingEvaluationError(
            f"preregistered final matrix must contain 120 runs per arm, got {len(matrix)}"
        )
    return matrix


def _expected_specs(
    evaluation: Mapping[str, Any],
    matrix: Mapping[str, tuple[str, str, str, int]],
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """Reconstruct the exact ordered specs used by ``run_final_evaluation``."""

    try:
        specs = amazon_specs(
            evaluation["scenarios"],
            evaluation["variants"],
            evaluation["conditions"],
            repetitions=int(evaluation["repetitions"]),
        )
    except Exception as exc:  # noqa: BLE001 - normalize external registry failures
        raise ExistingEvaluationError("cannot reconstruct the frozen Amazon task specs") from exc
    by_run = {str(spec.get("run_id")): spec for spec in specs}
    if len(by_run) != len(specs) or set(by_run) != set(matrix):
        raise ExistingEvaluationError("generated Amazon specs differ from the evaluation matrix")
    for run_id, expected in matrix.items():
        spec = by_run[run_id]
        task = spec.get("task")
        observed = (
            task.get("task_id") if isinstance(task, Mapping) else None,
            spec.get("condition"),
            spec.get("repetition"),
        )
        if observed != (f"{expected[0]}-{expected[1]}", expected[2], expected[3]):
            raise ExistingEvaluationError(f"generated Amazon spec metadata differs: {run_id}")
    return specs, by_run


def _validate_manifest(
    arm: str,
    manifest: Mapping[str, Any],
    *,
    expected_spec_sha256: str,
    run_count: int,
    safety: Mapping[str, Any],
) -> None:
    if (
        manifest.get("schema") != "harness-distill.rollout-campaign.v3"
        or manifest.get("run_count") != run_count
        or manifest.get("scaffold") != "browseruse"
        or manifest.get("max_steps_safety_backstop") != safety["max_steps"]
        or manifest.get("run_timeout_seconds_safety_backstop") != safety["run_timeout_seconds"]
        or manifest.get("spec_sha256") != expected_spec_sha256
    ):
        raise ExistingEvaluationError(f"{arm} rollout manifest differs from the sealed config")
    wire_model = manifest.get("wire_model")
    if not isinstance(wire_model, str) or not wire_model:
        raise ExistingEvaluationError(f"{arm} rollout manifest has no wire model")
    if manifest.get("model_label") != f"{wire_model}-{arm}":
        raise ExistingEvaluationError(f"{arm} rollout manifest has the wrong arm label")
    if not isinstance(manifest.get("runtime_identity"), Mapping):
        raise ExistingEvaluationError(f"{arm} rollout manifest has no runtime identity")
    try:
        _validated_model_identity(manifest.get("model_identity"), wire_model=wire_model)
    except (TypeError, ValueError) as exc:
        raise ExistingEvaluationError(f"{arm} rollout manifest has invalid model identity") from exc
    limit_contract = manifest.get("limit_contract")
    if not isinstance(limit_contract, Mapping):
        raise ExistingEvaluationError(f"{arm} rollout manifest has no limit contract")
    contract_payload = dict(limit_contract)
    contract_sha256 = contract_payload.pop("sha256", None)
    if contract_sha256 != _sha256_bytes(_canonical(contract_payload).encode("utf-8")):
        raise ExistingEvaluationError(f"{arm} rollout manifest has an invalid limit-contract hash")


def _validate_run_provenance(
    arm: str,
    run_id: str,
    provenance: Mapping[str, Any],
    *,
    manifest: Mapping[str, Any],
    spec: Mapping[str, Any],
) -> None:
    expected = {
        "schema": "harness-distill.rollout-run-provenance.v2",
        "campaign_manifest_sha256": _sha256_bytes(_canonical(manifest).encode("utf-8")),
        "run_id": run_id,
        "spec_sha256": _sha256_bytes(_canonical(spec).encode("utf-8")),
        "model_identity": manifest["model_identity"],
        "runtime_identity": manifest["runtime_identity"],
        "scaffold": manifest["scaffold"],
        "max_steps_safety_backstop": manifest["max_steps_safety_backstop"],
        "run_timeout_seconds_safety_backstop": manifest["run_timeout_seconds_safety_backstop"],
        "limit_contract_sha256": manifest["limit_contract"]["sha256"],
    }
    if _canonical(provenance) != _canonical(expected):
        raise ExistingEvaluationError(f"{arm} run provenance differs from its manifest: {run_id}")


def _validate_split(evaluation: Mapping[str, Any]) -> tuple[set[str], set[str]]:
    scenarios = set(evaluation["scenarios"])
    held_out = set(evaluation.get("held_out_confirmatory_scenarios") or [])
    development = set(evaluation.get("development_exposed_scenarios") or [])
    if held_out & development or held_out | development != scenarios:
        raise ExistingEvaluationError(
            "development and held-out scenarios must be disjoint and exhaust the matrix"
        )
    if len(held_out) != 4 or len(development) != 1:
        raise ExistingEvaluationError("expected one development and four held-out products")
    return held_out, development


def _score_core(score: Mapping[str, Any]) -> dict[str, Any]:
    keys = (
        "runs",
        "run_count",
        "optimal_product_rate",
        "valid_purchase_rate",
        "binding_backstop_runs",
        "mean_preservation_strict",
        "by_condition",
    )
    return {key: score.get(key) for key in keys}


def _validate_persisted_score(
    arm: str,
    score: Mapping[str, Any],
    rescored: Mapping[str, Any],
    matrix: Mapping[str, tuple[str, str, str, int]],
) -> list[dict[str, Any]]:
    if _canonical(_score_core(score)) != _canonical(_score_core(rescored)):
        raise ExistingEvaluationError(
            f"{arm} scores.json differs from a fresh native re-score of immutable trajectories"
        )
    records = score.get("runs")
    if not isinstance(records, list) or not all(isinstance(row, dict) for row in records):
        raise ExistingEvaluationError(f"{arm} scores.json has no run records")
    by_run = {str(row.get("run")): row for row in records}
    if len(by_run) != len(records) or set(by_run) != set(matrix):
        missing = sorted(set(matrix) - set(by_run))
        extra = sorted(set(by_run) - set(matrix))
        raise ExistingEvaluationError(
            f"{arm} score matrix mismatch; missing={missing[:3]}, extra={extra[:3]}"
        )
    for run_id, expected in matrix.items():
        row = by_run[run_id]
        observed = (
            row.get("scenario"),
            row.get("variant"),
            row.get("condition"),
            row.get("repetition"),
        )
        if observed != expected:
            raise ExistingEvaluationError(
                f"{arm} score metadata differs from run identity: {run_id}"
            )
        if row.get("strict_binary") not in {None, 0.0, 1.0}:
            raise ExistingEvaluationError(f"{arm} has non-binary strict score: {run_id}")
        if row.get("optimal") is not (row.get("strict_binary") == 1.0):
            raise ExistingEvaluationError(
                f"{arm} optimal flag disagrees with strict score: {run_id}"
            )
    collection = score.get("collection")
    if not isinstance(collection, dict):
        raise ExistingEvaluationError(f"{arm} scores.json has no collection result")
    if (
        collection.get("completed") != len(matrix)
        or collection.get("requested") != len(matrix)
        or collection.get("failed_run_ids") != []
    ):
        raise ExistingEvaluationError(f"{arm} collection is incomplete")
    return [by_run[run_id] for run_id in sorted(by_run)]


def _valid_proxy_exchange(row: Mapping[str, Any]) -> bool:
    status = row.get("status_code")
    if type(status) is not int or status not in range(200, 300):
        return False
    response = row.get("response")
    choices = response.get("choices") if isinstance(response, Mapping) else None
    return (
        isinstance(choices, list)
        and len(choices) == 1
        and isinstance(choices[0], Mapping)
        and isinstance(choices[0].get("message"), Mapping)
    )


def _declared_tool_names(request: Any) -> set[str] | None:
    if not isinstance(request, Mapping):
        return None
    tools = request.get("tools")
    if not isinstance(tools, list):
        return None
    names: set[str] = set()
    for tool in tools:
        function = tool.get("function") if isinstance(tool, Mapping) else None
        name = function.get("name") if isinstance(function, Mapping) else None
        if not isinstance(name, str) or not name or name in names:
            return None
        names.add(name)
    return names


def _wire_tool_call_valid(call: Any, declared: set[str] | None) -> bool:
    if not isinstance(call, Mapping) or call.get("type") != "function":
        return False
    if not isinstance(call.get("id"), str) or not call["id"]:
        return False
    function = call.get("function")
    if not isinstance(function, Mapping):
        return False
    name = function.get("name")
    arguments = function.get("arguments")
    if not isinstance(name, str) or not name or declared is None or name not in declared:
        return False
    if not isinstance(arguments, str):
        return False
    try:
        decoded = json.loads(arguments)
    except json.JSONDecodeError:
        return False
    return isinstance(decoded, dict)


def _trace_diagnostics(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {
            "status": "unavailable",
            "reason": "proxy trace contains no model exchanges",
            "model_calls": 0,
        }
    valid_exchanges = sum(_valid_proxy_exchange(row) for row in rows)
    sampled_tokens: list[int] = []
    token_missing = 0
    tool_calls = 0
    valid_tool_calls = 0
    malformed_tool_call_envelopes = 0
    for row in rows:
        response = row.get("response")
        usage = response.get("usage") if isinstance(response, Mapping) else None
        tokens = usage.get("completion_tokens") if isinstance(usage, Mapping) else None
        if type(tokens) is int and tokens >= 0:
            sampled_tokens.append(tokens)
        else:
            token_missing += 1

        choices = response.get("choices") if isinstance(response, Mapping) else None
        if not isinstance(choices, list) or len(choices) != 1:
            continue
        choice = choices[0]
        message = choice.get("message") if isinstance(choice, Mapping) else None
        if not isinstance(message, Mapping) or "tool_calls" not in message:
            continue
        calls = message.get("tool_calls")
        if not isinstance(calls, list):
            malformed_tool_call_envelopes += 1
            continue
        request = row.get("effective_request", row.get("request"))
        declared = _declared_tool_names(request)
        for call in calls:
            tool_calls += 1
            valid_tool_calls += _wire_tool_call_valid(call, declared)
    token_status = "available" if token_missing == 0 else "unavailable"
    token_result: dict[str, Any] = {
        "status": token_status,
        "definition": "sum of provider-reported response.usage.completion_tokens",
        "calls_with_value": len(sampled_tokens),
        "model_calls": len(rows),
    }
    if token_status == "available":
        token_result["value"] = sum(sampled_tokens)
    else:
        token_result["reason"] = "completion_tokens is absent or malformed for at least one call"
    if malformed_tool_call_envelopes:
        tool_status = "unavailable"
        tool_reason = "at least one response has a malformed tool_calls envelope"
    elif tool_calls == 0:
        tool_status = "not_observed"
        tool_reason = "no native tool_calls were present in recorded responses"
    else:
        tool_status = "available"
        tool_reason = None
    tool_result: dict[str, Any] = {
        "status": tool_status,
        "definition": (
            "native call has function type, a request-declared name, and JSON-object arguments; "
            "this does not assert semantic argument-schema or execution validity"
        ),
        "tool_calls": tool_calls,
        "valid_tool_calls": valid_tool_calls,
    }
    if tool_status == "available":
        tool_result["rate"] = valid_tool_calls / tool_calls
    else:
        tool_result["reason"] = tool_reason
    return {
        "status": "available",
        "model_calls": len(rows),
        "proxy_exchange_validity": {
            "valid_calls": valid_exchanges,
            "model_calls": len(rows),
            "rate": valid_exchanges / len(rows),
        },
        "sampled_completion_tokens": token_result,
        "native_tool_call_wire_validity": tool_result,
    }


def _loop_signals(trajectory: Mapping[str, Any]) -> dict[str, Any]:
    steps = trajectory.get("steps")
    if not isinstance(steps, list):
        return {"status": "unavailable", "reason": "trajectory.steps is not a list"}
    pairs: list[tuple[str, str]] = []
    for step in steps:
        if not isinstance(step, Mapping):
            return {"status": "unavailable", "reason": "a trajectory step is not an object"}
        url, action = step.get("url"), step.get("action")
        if not isinstance(url, str) or not isinstance(action, str):
            return {
                "status": "unavailable",
                "reason": "a trajectory step lacks exact text URL/action evidence",
            }
        pairs.append((url, action))
    counts: Counter[tuple[str, str]] = Counter()
    repeated = 0
    immediate = 0
    maximum_streak = 0
    streak = 0
    prior: tuple[str, str] | None = None
    for pair in pairs:
        if counts[pair]:
            repeated += 1
        counts[pair] += 1
        if pair == prior:
            immediate += 1
            streak += 1
        else:
            streak = 1
        maximum_streak = max(maximum_streak, streak)
        prior = pair
    two_cycles = sum(
        pairs[index] == pairs[index - 2]
        and pairs[index - 1] == pairs[index - 3]
        and pairs[index] != pairs[index - 1]
        for index in range(3, len(pairs))
    )
    return {
        "status": "available",
        "definition": (
            "exact repeated (URL, serialized action) observations only; these are loop signals, "
            "not a semantic claim that page state was unchanged"
        ),
        "steps": len(pairs),
        "repeated_state_action_steps": repeated,
        "immediate_repeat_steps": immediate,
        "maximum_identical_streak": maximum_streak,
        "exact_two_cycle_endpoints": two_cycles,
        "any_signal": repeated > 0 or two_cycles > 0,
    }


def _run_diagnostics(
    evidence: _ReadOnlyEvidence,
    arm: str,
    run_id: str,
    trajectory: Mapping[str, Any],
) -> dict[str, Any]:
    relative = f"eval/full/{arm}/runs/{run_id}/model_requests.jsonl"
    raw = evidence.optional_bytes(relative)
    if raw is None:
        trace = {
            "status": "unavailable",
            "reason": "model_requests.jsonl is absent",
            "model_calls": 0,
        }
    else:
        try:
            trace = _trace_diagnostics(_jsonl(raw, relative))
        except ExistingEvaluationError:
            trace = {
                "status": "unavailable",
                "reason": "model_requests.jsonl is not valid object JSONL",
                "model_calls": 0,
            }
    return {
        "trace": trace,
        "loop_signals": _loop_signals(trajectory),
    }


def _distribution(values: Sequence[float]) -> dict[str, float] | None:
    if not values:
        return None
    return {
        "mean": sum(values) / len(values),
        "median": float(statistics.median(values)),
        "minimum": min(values),
        "maximum": max(values),
    }


def _aggregate_diagnostics(
    records: Sequence[Mapping[str, Any]],
    by_run: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    diagnostics = [by_run[str(record["run"])] for record in records]
    traces = [item["trace"] for item in diagnostics]
    loops = [item["loop_signals"] for item in diagnostics]
    token_fields = [
        trace.get("sampled_completion_tokens")
        for trace in traces
        if trace.get("status") == "available"
    ]
    token_available = len(token_fields) == len(traces) and all(
        field.get("status") == "available" for field in token_fields
    )
    sampled: dict[str, Any] = {
        "status": "available" if token_available else "unavailable",
        "run_coverage": sum(
            isinstance(field, Mapping) and field.get("status") == "available"
            for field in token_fields
        )
        / len(traces),
        "runs": len(traces),
    }
    if token_available:
        values = [float(field["value"]) for field in token_fields]
        sampled.update({"total": int(sum(values)), "per_run": _distribution(values)})
    else:
        sampled["reason"] = "not every recorded model call has provider token usage"

    tool_fields = [
        trace.get("native_tool_call_wire_validity")
        for trace in traces
        if trace.get("status") == "available"
    ]
    observed_tools = sum(
        int(field.get("tool_calls", 0)) for field in tool_fields if isinstance(field, Mapping)
    )
    valid_tools = sum(
        int(field.get("valid_tool_calls", 0)) for field in tool_fields if isinstance(field, Mapping)
    )
    if len(tool_fields) != len(traces):
        tool_status, tool_reason = "unavailable", "at least one run has no readable proxy trace"
    elif any(field.get("status") == "unavailable" for field in tool_fields):
        tool_status, tool_reason = "unavailable", "at least one tool-call envelope is malformed"
    elif observed_tools == 0:
        tool_status, tool_reason = "not_observed", "no native tool calls were recorded"
    else:
        tool_status, tool_reason = "available", None
    tools: dict[str, Any] = {
        "status": tool_status,
        "tool_calls": observed_tools,
        "valid_tool_calls": valid_tools,
    }
    if tool_status == "available":
        tools["rate"] = valid_tools / observed_tools
    else:
        tools["reason"] = tool_reason

    loop_available = all(loop.get("status") == "available" for loop in loops)
    loop_result: dict[str, Any] = {
        "status": "available" if loop_available else "unavailable",
        "runs": len(loops),
    }
    if loop_available:
        loop_result.update(
            {
                "runs_with_any_exact_signal": sum(loop["any_signal"] for loop in loops),
                "repeated_state_action_steps": sum(
                    loop["repeated_state_action_steps"] for loop in loops
                ),
                "immediate_repeat_steps": sum(loop["immediate_repeat_steps"] for loop in loops),
                "exact_two_cycle_endpoints": sum(
                    loop["exact_two_cycle_endpoints"] for loop in loops
                ),
                "definition": loops[0]["definition"] if loops else None,
            }
        )
    else:
        loop_result["reason"] = "not every trajectory has exact URL/action step evidence"

    proxy_calls = sum(int(trace.get("model_calls", 0)) for trace in traces)
    proxy_valid = sum(
        int((trace.get("proxy_exchange_validity") or {}).get("valid_calls", 0)) for trace in traces
    )
    readable_traces = sum(trace.get("status") == "available" for trace in traces)
    proxy_complete = readable_traces == len(traces) and proxy_calls > 0
    proxy_result: dict[str, Any] = {
        "status": "available" if proxy_complete else "unavailable",
        "run_coverage": readable_traces / len(traces),
        "runs": len(traces),
        "model_calls": proxy_calls,
        "valid_calls": proxy_valid,
    }
    if proxy_complete:
        proxy_result["rate"] = proxy_valid / proxy_calls
    else:
        proxy_result["reason"] = "not every run has a readable, non-empty proxy trace"
    steps = [float(record["steps"]) for record in records if type(record.get("steps")) is int]
    durations = [
        float(record["duration_seconds"])
        for record in records
        if isinstance(record.get("duration_seconds"), (int, float))
        and not isinstance(record.get("duration_seconds"), bool)
    ]
    return {
        "sampled_completion_tokens": sampled,
        "native_tool_call_wire_validity": tools,
        "proxy_exchange_validity": proxy_result,
        "exact_repetition_loop_signals": loop_result,
        "steps_per_run": _distribution(steps),
        "duration_seconds_per_run": _distribution(durations),
    }


def _subset(
    records: Sequence[dict[str, Any]],
    *,
    scenarios: set[str] | None = None,
    condition: str | None = None,
) -> list[dict[str, Any]]:
    return [
        record
        for record in records
        if (scenarios is None or record["scenario"] in scenarios)
        and (condition is None or record["condition"] == condition)
    ]


def _arm_report(
    records: list[dict[str, Any]],
    diagnostics: Mapping[str, Mapping[str, Any]],
    *,
    held_out: set[str],
    development: set[str],
) -> dict[str, Any]:
    full = _subset(records)
    held = _subset(records, scenarios=held_out)
    held_clean = _subset(records, scenarios=held_out, condition="clean")
    held_combined = _subset(records, scenarios=held_out, condition="combined")
    developed = _subset(records, scenarios=development)
    if (len(full), len(held), len(held_clean), len(held_combined), len(developed)) != (
        120,
        96,
        48,
        48,
        24,
    ):
        raise ExistingEvaluationError("validated records do not match preregistered split counts")
    return {
        "all_five_products": {
            **_summarize_records(full),
            "diagnostics": _aggregate_diagnostics(full, diagnostics),
        },
        "genuinely_held_out_four_products": {
            "all_conditions": {
                **_summarize_records(held),
                "diagnostics": _aggregate_diagnostics(held, diagnostics),
            },
            "clean": _summarize_records(held_clean),
            "combined": {
                **_summarize_records(held_combined),
                "diagnostics": _aggregate_diagnostics(held_combined, diagnostics),
            },
        },
        "development_exposed_product": _summarize_records(developed),
    }


def _protocol_parity(manifests: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    fields = (
        "wire_model",
        "runtime_identity",
        "scaffold",
        "max_steps_safety_backstop",
        "run_timeout_seconds_safety_backstop",
        "limit_contract",
        "run_count",
        "spec_sha256",
    )
    mismatches = [
        field
        for field in fields
        if _canonical(manifests["base"].get(field)) != _canonical(manifests["trained"].get(field))
    ]
    if mismatches:
        raise ExistingEvaluationError(f"base/trained protocol differs: {mismatches}")
    base_tree = manifests["base"]["model_identity"]["tree_sha256"]
    trained_tree = manifests["trained"]["model_identity"]["tree_sha256"]
    if base_tree == trained_tree:
        raise ExistingEvaluationError("base and trained arms use the same checkpoint bytes")
    return {
        "matched": True,
        "matched_fields": list(fields),
        "base_model_tree_sha256": base_tree,
        "trained_model_tree_sha256": trained_tree,
    }


def _identity_and_config(evidence: _ReadOnlyEvidence) -> tuple[dict[str, Any], dict[str, Any]]:
    identity = evidence.read_json("campaign_identity.json")
    evaluation_bytes = evidence.read_bytes("configs/evaluation.yaml")
    try:
        evaluation = load_yaml(evidence.root / "configs/evaluation.yaml")
    except (OSError, ValueError) as exc:
        raise ExistingEvaluationError("cannot load sealed evaluation configuration") from exc
    hashes = identity.get("config_sha256")
    if not isinstance(hashes, Mapping) or hashes.get("configs/evaluation.yaml") != _sha256_bytes(
        evaluation_bytes
    ):
        raise ExistingEvaluationError(
            "campaign identity does not bind the copied evaluation configuration"
        )
    return identity, evaluation


def _analysis_attestation(evaluation: Mapping[str, Any]) -> dict[str, Any]:
    """Hash the code and benchmark data that reconstruct specs and native scores."""

    from agentarena.benchmark import registry, scenarios, schema, serialize
    from agentarena.core import task as core_task
    from agentarena.envs.amazon import catalog as amazon_catalog
    from agentarena.scoring import basket, continuous, rescore

    modules = {
        "harness_distill.post_training_report": Path(__file__).resolve(),
        "harness_distill.evaluation": Path(__file__).with_name("evaluation.py"),
        "harness_distill.rollouts": Path(__file__).with_name("rollouts.py"),
        "harness_distill.schemas": Path(__file__).with_name("schemas.py"),
        "agentarena.benchmark.registry": Path(registry.__file__).resolve(),
        "agentarena.benchmark.scenarios": Path(scenarios.__file__).resolve(),
        "agentarena.benchmark.schema": Path(schema.__file__).resolve(),
        "agentarena.benchmark.serialize": Path(serialize.__file__).resolve(),
        "agentarena.core.task": Path(core_task.__file__).resolve(),
        "agentarena.envs.amazon.catalog": Path(amazon_catalog.__file__).resolve(),
        "agentarena.scoring.basket": Path(basket.__file__).resolve(),
        "agentarena.scoring.continuous": Path(continuous.__file__).resolve(),
        "agentarena.scoring.rescore": Path(rescore.__file__).resolve(),
    }
    module_files: dict[str, Any] = {}
    for name, path in sorted(modules.items()):
        if path.is_symlink() or not path.is_file():
            raise ExistingEvaluationError(f"analysis implementation is not a regular file: {name}")
        module_files[name] = {"bytes": path.stat().st_size, "sha256": _sha256_file(path)}

    data_files: dict[str, Any] = {}
    for scenario in evaluation["scenarios"]:
        for filename in (
            "catalog.json",
            "instructions.json",
            "meta.json",
            "pool.json",
            "preferences.json",
        ):
            path = serialize.DATA_ROOT / scenario / filename
            if path.is_symlink() or not path.is_file():
                raise ExistingEvaluationError(
                    f"authoritative benchmark data is not a regular file: {scenario}/{filename}"
                )
            data_files[f"{scenario}/{filename}"] = {
                "bytes": path.stat().st_size,
                "sha256": _sha256_file(path),
            }
    return {
        "module_files": module_files,
        "benchmark_data_files": data_files,
        "digest": _sha256_bytes(
            _canonical({"module_files": module_files, "benchmark_data_files": data_files}).encode(
                "utf-8"
            )
        ),
    }


def build_existing_evaluation_report(target_dir: str | Path) -> dict[str, Any]:
    """Build a report from existing artifacts without writing or calling a model."""

    target = Path(target_dir).resolve(strict=True)
    if not target.is_dir():
        raise ExistingEvaluationError(f"campaign target is not a directory: {target}")
    evidence = _ReadOnlyEvidence(target)
    identity, evaluation = _identity_and_config(evidence)
    matrix = _expected_matrix(evaluation)
    expected_specs, specs_by_run = _expected_specs(evaluation, matrix)
    expected_spec_sha256 = _sha256_bytes(_canonical(expected_specs).encode("utf-8"))
    held_out, development = _validate_split(evaluation)
    safety = evaluation.get("safety_backstops")
    if (
        not isinstance(safety, Mapping)
        or type(safety.get("max_steps")) is not int
        or type(safety.get("run_timeout_seconds")) is not int
    ):
        raise ExistingEvaluationError("sealed evaluation has malformed safety backstops")

    scores: dict[str, dict[str, Any]] = {}
    records: dict[str, list[dict[str, Any]]] = {}
    manifests: dict[str, dict[str, Any]] = {}
    per_run_diagnostics: dict[str, dict[str, dict[str, Any]]] = {}
    for arm in ARMS:
        scores[arm] = evidence.read_json(f"eval/full/{arm}/scores.json")
        manifests[arm] = evidence.read_json(f"eval/full/{arm}/runs/manifest.json")
        collection_summary = evidence.read_json(f"eval/full/{arm}/runs/collection_summary.json")
        if _canonical(collection_summary) != _canonical(scores[arm].get("collection")):
            raise ExistingEvaluationError(
                f"{arm} scores.json collection differs from collection_summary.json"
            )
        _validate_manifest(
            arm,
            manifests[arm],
            expected_spec_sha256=expected_spec_sha256,
            run_count=len(matrix),
            safety=safety,
        )
        trajectory_paths = {
            path.parent.name
            for path in (target / f"eval/full/{arm}/runs").glob("*/trajectory.json")
        }
        if trajectory_paths != set(matrix):
            raise ExistingEvaluationError(
                f"{arm} raw trajectory matrix is incomplete or has extras"
            )

        per_run_diagnostics[arm] = {}
        for run_id, expected in sorted(matrix.items()):
            prefix = f"eval/full/{arm}/runs/{run_id}"
            trajectory = evidence.read_json(f"{prefix}/trajectory.json")
            evidence.read_json(f"{prefix}/summary.json")
            provenance = evidence.read_json(f"{prefix}/run_provenance.json")
            _validate_run_provenance(
                arm,
                run_id,
                provenance,
                manifest=manifests[arm],
                spec=specs_by_run[run_id],
            )
            if (
                trajectory.get("condition") != expected[2]
                or trajectory.get("task_id") != f"{expected[0]}-{expected[1]}"
            ):
                raise ExistingEvaluationError(
                    f"{arm} raw trajectory metadata differs from run identity: {run_id}"
                )
            per_run_diagnostics[arm][run_id] = _run_diagnostics(evidence, arm, run_id, trajectory)

        rescored = score_amazon_runs(
            target / f"eval/full/{arm}/runs", list(evaluation["scenarios"])
        )
        records[arm] = _validate_persisted_score(arm, scores[arm], rescored, matrix)

    parity = _protocol_parity(manifests)
    confirmatory = {
        arm: _subset(records[arm], scenarios=held_out, condition="combined") for arm in ARMS
    }
    if any(len(confirmatory[arm]) != 48 for arm in ARMS):
        raise ExistingEvaluationError("confirmatory combined-only subset must have 48 runs per arm")
    bootstrap = _paired_task_stratified_bootstrap(
        confirmatory["base"],
        confirmatory["trained"],
        seed=BOOTSTRAP_SEED,
        draws=BOOTSTRAP_DRAWS,
    )
    confirmatory_summary = {arm: _summarize_records(confirmatory[arm]) for arm in ARMS}
    effect = (
        confirmatory_summary["trained"]["optimal_product_rate"]
        - confirmatory_summary["base"]["optimal_product_rate"]
    )
    criteria = evaluation.get("success_criteria") or {}
    all_clean = {arm: _summarize_records(_subset(records[arm], condition="clean")) for arm in ARMS}
    success = (
        effect >= float(criteria["minimum_combined_absolute_improvement"])
        and bootstrap["lower_95"] > float(criteria["bootstrap_lower_bound_must_exceed"])
        and all_clean["trained"]["optimal_product_rate"]
        >= all_clean["base"]["optimal_product_rate"]
        - float(criteria["maximum_clean_optimal_product_regression"])
        and all_clean["trained"]["valid_purchase_rate"]
        >= all_clean["base"]["valid_purchase_rate"]
        - float(criteria["maximum_clean_valid_purchase_regression"])
        and all(not record["backstop_bound"] for arm in ARMS for record in records[arm])
    )

    input_manifest = evidence.manifest()
    report = {
        "schema": REPORT_SCHEMA,
        "generation_contract": {
            "read_only_source": True,
            "model_calls": 0,
            "rollout_calls": 0,
            "deterministic": True,
            "missing_diagnostics_are_not_imputed": True,
        },
        "campaign_identity": {
            "sha256": _sha256_bytes(evidence.read_bytes("campaign_identity.json")),
            "schema": identity.get("schema"),
            "source_git_sha": identity.get("source_git_sha"),
            "container_image_digest": identity.get("container_image_digest"),
        },
        "analysis_implementation": _analysis_attestation(evaluation),
        "matrix": {
            "environment": "amazon",
            "scenarios": list(evaluation["scenarios"]),
            "variants": list(evaluation["variants"]),
            "conditions": list(evaluation["conditions"]),
            "repetitions": evaluation["repetitions"],
            "runs_per_arm": len(matrix),
            "all_five_products_runs_per_arm": 120,
            "genuinely_held_out_four_products_runs_per_arm": 96,
            "held_out_clean_runs_per_arm": 48,
            "held_out_combined_runs_per_arm": 48,
            "development_exposed_scenarios": sorted(development),
            "held_out_confirmatory_scenarios": sorted(held_out),
        },
        "protocol_parity": parity,
        "arms": {
            arm: _arm_report(
                records[arm],
                per_run_diagnostics[arm],
                held_out=held_out,
                development=development,
            )
            for arm in ARMS
        },
        "preregistered_confirmatory_analysis": {
            "scope": "held-out four products, combined condition only",
            "runs_per_arm": 48,
            "base": confirmatory_summary["base"],
            "trained": confirmatory_summary["trained"],
            "observed_absolute_difference": effect,
            "paired_task_stratified_bootstrap_difference": {
                **bootstrap,
                "seed": BOOTSTRAP_SEED,
                "draws": BOOTSTRAP_DRAWS,
                "pairing": "identical run ID across arms",
                "cluster": "scenario/variant/condition task; three repetitions stay together",
                "strata": "product scenario",
                "resampling": "tasks with replacement within each scenario",
            },
        },
        "preregistered_success": success,
        "per_run_diagnostics": per_run_diagnostics,
        "input_attestation": input_manifest,
    }
    # A final read-after-build closes the small interval between the earlier
    # check and input-manifest construction.
    evidence.assert_unchanged()
    return report


def _percent(value: Any) -> str:
    return "n/a" if value is None else f"{100 * float(value):.1f}%"


def _diagnostic_cell(value: Mapping[str, Any], key: str) -> str:
    field = value[key]
    if field["status"] != "available":
        return field["status"].replace("_", " ")
    if key == "sampled_completion_tokens":
        return str(field["total"])
    if key == "native_tool_call_wire_validity":
        return _percent(field["rate"])
    raise AssertionError(key)


def render_markdown(report: Mapping[str, Any]) -> str:
    """Render the compact human report from the machine-readable result."""

    arms = report["arms"]
    confirmatory = report["preregistered_confirmatory_analysis"]
    lines = [
        "# Post-training Amazon-five evaluation",
        "",
        (
            "This report was generated without model or rollout calls from the sealed "
            "120-run-per-arm final evaluation. Laptop was development-exposed; office chair, "
            "mattress, backpack, and tent were genuinely held out."
        ),
        "",
        "## Aggregates",
        "",
        (
            "| Arm | Five products (n) | Optimal selection | Held-out (n) | "
            "Held-out clean | Held-out combined |"
        ),
        "|---|---:|---:|---:|---:|---:|",
    ]
    for arm in ARMS:
        full = arms[arm]["all_five_products"]
        held = arms[arm]["genuinely_held_out_four_products"]
        lines.append(
            "| "
            + " | ".join(
                (
                    arm,
                    str(full["n"]),
                    _percent(full["optimal_product_rate"]),
                    str(held["all_conditions"]["n"]),
                    _percent(held["clean"]["optimal_product_rate"]),
                    _percent(held["combined"]["optimal_product_rate"]),
                )
            )
            + " |"
        )
    bootstrap = confirmatory["paired_task_stratified_bootstrap_difference"]
    lines.extend(
        [
            "",
            "## Preregistered confirmatory comparison",
            "",
            (
                f"On the 48 held-out combined runs per arm, the absolute optimal-selection "
                f"difference was {_percent(confirmatory['observed_absolute_difference'])}. "
                f"The paired task-stratified bootstrap 95% interval was "
                f"[{_percent(bootstrap['lower_95'])}, {_percent(bootstrap['upper_95'])}] "
                f"({bootstrap['draws']:,} draws; seed {bootstrap['seed']})."
            ),
            "",
            (
                "Preregistered success criteria: "
                f"**{'passed' if report['preregistered_success'] else 'not passed'}**."
            ),
            "",
            "## Recorded diagnostics (five-product aggregate)",
            "",
            (
                "| Arm | Sampled completion tokens | Native tool-call wire validity | "
                "Proxy exchange validity | Runs with exact repetition signal |"
            ),
            "|---|---:|---:|---:|---:|",
        ]
    )
    for arm in ARMS:
        diagnostic = arms[arm]["all_five_products"]["diagnostics"]
        loops = diagnostic["exact_repetition_loop_signals"]
        loop_value = (
            str(loops["runs_with_any_exact_signal"])
            if loops["status"] == "available"
            else loops["status"]
        )
        lines.append(
            "| "
            + " | ".join(
                (
                    arm,
                    _diagnostic_cell(diagnostic, "sampled_completion_tokens"),
                    _diagnostic_cell(diagnostic, "native_tool_call_wire_validity"),
                    _percent(diagnostic["proxy_exchange_validity"].get("rate")),
                    loop_value,
                )
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "Token totals are reported only when every recorded response contains the provider's "
            "`usage.completion_tokens`. Tool validity is wire-level only: declared function name "
            "and JSON-object arguments, not semantic schema compliance. Loop signals are exact "
            "repetitions of recorded URL/action pairs and are not interpreted as unchanged page "
            "state.",
            "",
            "## Integrity",
            "",
            f"Input files: {report['input_attestation']['file_count']}; input digest: "
            f"`{report['input_attestation']['digest']}`. No safety backstop may bind in either "
            "arm.",
            "",
        ]
    )
    return "\n".join(lines)


def write_existing_evaluation_report(
    target_dir: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    """Write deterministic JSON/Markdown reports outside the immutable target."""

    target = Path(target_dir).resolve(strict=True)
    output = Path(output_dir).resolve()
    if output == target or output.is_relative_to(target) or target.is_relative_to(output):
        raise ExistingEvaluationError("report output and campaign target must be disjoint")
    report = build_existing_evaluation_report(target)
    output.mkdir(parents=True, exist_ok=True)
    json_path = atomic_json(output / "evaluation_report.json", report)
    markdown = render_markdown(report)
    markdown_path = output / "evaluation_report.md"
    temporary = markdown_path.with_name(f".{markdown_path.name}.tmp")
    temporary.write_text(markdown, encoding="utf-8")
    temporary.replace(markdown_path)
    manifest = {
        "schema": MANIFEST_SCHEMA,
        "input_digest": report["input_attestation"]["digest"],
        "outputs": {
            json_path.name: {
                "bytes": json_path.stat().st_size,
                "sha256": _sha256_file(json_path),
            },
            markdown_path.name: {
                "bytes": markdown_path.stat().st_size,
                "sha256": _sha256_file(markdown_path),
            },
        },
    }
    manifest_path = atomic_json(output / "report_manifest.json", manifest)
    return {
        "schema": MANIFEST_SCHEMA,
        "report_json": str(json_path),
        "report_markdown": str(markdown_path),
        "manifest": str(manifest_path),
        "input_digest": manifest["input_digest"],
        "report_sha256": manifest["outputs"][json_path.name]["sha256"],
        "preregistered_success": report["preregistered_success"],
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, required=True, help="sealed campaign output root")
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="disjoint destination for deterministic report files",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    result = write_existing_evaluation_report(args.target, args.output)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
