"""Loss primitives for exact-token paired-context distillation.

PyTorch is imported lazily so dataset generation and audit tooling stay usable
in lightweight CPU environments.  Training functions raise a direct error if
called without PyTorch.
"""

from __future__ import annotations

from typing import Any


def _torch_modules() -> tuple[Any, Any]:
    try:
        import torch
        import torch.nn.functional as functional
    except ImportError as exc:  # pragma: no cover - exercised in minimal installs
        raise RuntimeError("harness_distill.losses requires PyTorch") from exc
    return torch, functional


def _require_tensor(name: str, value: Any) -> None:
    torch, _ = _torch_modules()
    if not torch.is_tensor(value):
        raise TypeError(f"{name} must be a torch.Tensor")


def gather_completion_logits(logits: Any, prediction_positions: Any) -> Any:
    """Gather causal-LM logits that predict a shared completion.

    ``prediction_positions`` should come from
    :class:`~harness_distill.traces.PairedTokenAlignment`.  Two shapes are
    supported:

    * ``logits=[sequence, vocab]``, ``positions=[completion]``;
    * ``logits=[batch, sequence, vocab]``, with either shared
      ``positions=[completion]`` or per-example ``[batch, completion]``.
    """

    torch, _ = _torch_modules()
    _require_tensor("logits", logits)
    if logits.ndim not in (2, 3):
        raise ValueError("logits must have shape [T,V] or [B,T,V]")
    positions = torch.as_tensor(prediction_positions, dtype=torch.long, device=logits.device)
    if positions.numel() == 0:
        raise ValueError("prediction_positions must not be empty")
    if bool((positions < 0).any()):
        raise ValueError("prediction_positions cannot be negative")

    sequence_length = logits.shape[-2]
    if bool((positions >= sequence_length).any()):
        raise ValueError("prediction_positions exceed the logits sequence length")

    if logits.ndim == 2:
        if positions.ndim != 1:
            raise ValueError("unbatched logits require one-dimensional positions")
        return logits.index_select(0, positions)

    batch_size, _, vocab_size = logits.shape
    if positions.ndim == 1:
        positions = positions.unsqueeze(0).expand(batch_size, -1)
    elif positions.ndim != 2 or positions.shape[0] != batch_size:
        raise ValueError("batched positions must have shape [completion] or [batch, completion]")
    index = positions.unsqueeze(-1).expand(-1, -1, vocab_size)
    return logits.gather(1, index)


def sampled_token_log_probs(aligned_logits: Any, token_ids: Any) -> Any:
    """Return log probabilities for exact sampled token ids.

    ``aligned_logits`` must already be gathered to completion positions.  A
    one-dimensional target is broadcast across a batch, but no tokenization or
    sequence alignment is performed here.
    """

    torch, functional = _torch_modules()
    _require_tensor("aligned_logits", aligned_logits)
    if aligned_logits.ndim not in (2, 3):
        raise ValueError("aligned_logits must have shape [C,V] or [B,C,V]")
    targets = torch.as_tensor(token_ids, dtype=torch.long, device=aligned_logits.device)
    expected_shape = aligned_logits.shape[:-1]
    if aligned_logits.ndim == 3 and targets.ndim == 1:
        if targets.shape[0] != expected_shape[1]:
            raise ValueError("token_ids length must equal completion length")
        targets = targets.unsqueeze(0).expand(expected_shape[0], -1)
    if tuple(targets.shape) != tuple(expected_shape):
        raise ValueError(
            f"token_ids shape {tuple(targets.shape)} does not match logits {tuple(expected_shape)}"
        )
    vocab_size = aligned_logits.shape[-1]
    if bool(((targets < 0) | (targets >= vocab_size)).any()):
        raise ValueError("token_ids contain an id outside the logits vocabulary")
    return (
        functional.log_softmax(aligned_logits, dim=-1).gather(-1, targets.unsqueeze(-1)).squeeze(-1)
    )


def opd_advantage(
    student_sample_log_probs: Any,
    teacher_sample_log_probs: Any,
    *,
    clip: float | None = None,
) -> Any:
    """Return the detached sampled-token OPD advantage.

    ``A = stop_gradient(log p_teacher(y) - log p_student(y))``.  Under
    student on-policy samples, ``-A * log p_student(y)`` is the score-function
    estimator for minimizing ``KL(student || teacher)``; the expectation of
    the omitted constant score term is zero.
    """

    torch, _ = _torch_modules()
    _require_tensor("student_sample_log_probs", student_sample_log_probs)
    _require_tensor("teacher_sample_log_probs", teacher_sample_log_probs)
    if student_sample_log_probs.shape != teacher_sample_log_probs.shape:
        raise ValueError("student and teacher sampled log-prob shapes must match")
    if clip is not None and (not isinstance(clip, (int, float)) or clip <= 0):
        raise ValueError("clip must be a positive number")
    advantage = teacher_sample_log_probs.detach() - student_sample_log_probs.detach()
    if clip is not None:
        advantage = torch.clamp(advantage, min=-float(clip), max=float(clip))
    return advantage


def _broadcast_like(name: str, value: Any, reference: Any, *, boolean: bool) -> Any:
    torch, _ = _torch_modules()
    tensor = torch.as_tensor(value, device=reference.device)
    if tensor.ndim == 1 and reference.ndim == 2:
        if tensor.shape[0] != reference.shape[1]:
            raise ValueError(f"{name} length must equal completion length")
        tensor = tensor.unsqueeze(0).expand(reference.shape[0], -1)
    if tensor.shape != reference.shape:
        raise ValueError(f"{name} shape must match per-token values")
    if boolean:
        return tensor.to(dtype=torch.bool)
    tensor = tensor.to(dtype=reference.dtype)
    if not bool(torch.isfinite(tensor).all()) or bool((tensor < 0).any()):
        raise ValueError(f"{name} must contain finite, non-negative weights")
    return tensor


def _masked_reduce(
    values: Any,
    *,
    mask: Any | None,
    token_weights: Any | None,
    reduction: str,
) -> Any:
    torch, _ = _torch_modules()
    if reduction not in {"none", "sum", "mean"}:
        raise ValueError("reduction must be 'none', 'sum', or 'mean'")
    active = (
        torch.ones_like(values, dtype=torch.bool)
        if mask is None
        else _broadcast_like("mask", mask, values, boolean=True)
    )
    weights = (
        torch.ones_like(values)
        if token_weights is None
        else _broadcast_like("token_weights", token_weights, values, boolean=False)
    )
    effective_weights = weights * active.to(dtype=values.dtype)
    weighted = values * effective_weights
    if reduction == "none":
        return weighted
    if reduction == "sum":
        return weighted.sum()
    denominator = effective_weights.sum()
    # Preserve a differentiable, finite zero for an all-padding microbatch.
    if bool(denominator.detach() == 0):
        return values.sum() * 0.0
    return weighted.sum() / denominator


def sampled_reverse_kl_loss(
    student_sample_log_probs: Any,
    teacher_sample_log_probs: Any,
    *,
    mask: Any | None = None,
    token_weights: Any | None = None,
    advantage_clip: float | None = None,
    reduction: str = "mean",
) -> Any:
    """Score-function estimate of reverse KL on student-sampled tokens.

    Teacher probabilities and the advantage are always detached.  Gradients
    flow only through the student's sampled log probabilities.
    """

    _require_tensor("student_sample_log_probs", student_sample_log_probs)
    advantage = opd_advantage(
        student_sample_log_probs,
        teacher_sample_log_probs,
        clip=advantage_clip,
    )
    per_token = -advantage * student_sample_log_probs
    return _masked_reduce(
        per_token,
        mask=mask,
        token_weights=token_weights,
        reduction=reduction,
    )


def corrective_cross_entropy(
    student_logits: Any,
    target_ids: Any,
    *,
    mask: Any | None = None,
    token_weights: Any | None = None,
    ignore_index: int = -100,
    reduction: str = "mean",
) -> Any:
    """Completion-only cross entropy for shadow-teacher corrective actions.

    ``student_logits`` must be aligned to the corrective completion positions,
    with shape ``[C,V]`` or ``[B,C,V]``.  Targets equal to ``ignore_index`` are
    excluded in addition to the optional assistant mask.
    """

    torch, functional = _torch_modules()
    _require_tensor("student_logits", student_logits)
    if student_logits.ndim not in (2, 3):
        raise ValueError("student_logits must have shape [C,V] or [B,C,V]")
    targets = torch.as_tensor(target_ids, dtype=torch.long, device=student_logits.device)
    expected_shape = student_logits.shape[:-1]
    if student_logits.ndim == 3 and targets.ndim == 1:
        if targets.shape[0] != expected_shape[1]:
            raise ValueError("target_ids length must equal completion length")
        targets = targets.unsqueeze(0).expand(expected_shape[0], -1)
    if tuple(targets.shape) != tuple(expected_shape):
        raise ValueError("target_ids shape must match student_logits without vocab")

    valid_targets = targets != ignore_index
    vocab_size = student_logits.shape[-1]
    if bool(((targets[valid_targets] < 0) | (targets[valid_targets] >= vocab_size)).any()):
        raise ValueError("target_ids contain an id outside the logits vocabulary")
    safe_targets = targets.masked_fill(~valid_targets, 0)
    per_token = functional.cross_entropy(
        student_logits.reshape(-1, vocab_size),
        safe_targets.reshape(-1),
        reduction="none",
    ).reshape(expected_shape)
    combined_mask = valid_targets
    if mask is not None:
        combined_mask = combined_mask & _broadcast_like("mask", mask, per_token, boolean=True)
    return _masked_reduce(
        per_token,
        mask=combined_mask,
        token_weights=token_weights,
        reduction=reduction,
    )


def exact_reverse_kl(
    student_logits: Any,
    teacher_logits: Any,
    *,
    mask: Any | None = None,
    token_weights: Any | None = None,
    reduction: str = "mean",
) -> Any:
    """Exact ``KL(student || teacher)`` diagnostic over the full vocabulary."""

    _torch, functional = _torch_modules()
    _require_tensor("student_logits", student_logits)
    _require_tensor("teacher_logits", teacher_logits)
    if student_logits.shape != teacher_logits.shape:
        raise ValueError("student and teacher logits shapes must match")
    if student_logits.ndim not in (2, 3):
        raise ValueError("logits must have shape [C,V] or [B,C,V]")
    student_log_probs = functional.log_softmax(student_logits, dim=-1)
    teacher_log_probs = functional.log_softmax(teacher_logits.detach(), dim=-1)
    per_token = (student_log_probs.exp() * (student_log_probs - teacher_log_probs)).sum(dim=-1)
    return _masked_reduce(
        per_token,
        mask=mask,
        token_weights=token_weights,
        reduction=reduction,
    )


def combined_distillation_loss(
    opd_loss: Any,
    corrective_loss: Any,
    *,
    corrective_weight: float = 0.5,
) -> Any:
    """Compose OPD and corrective CE with the preregistered CE weight."""

    if not isinstance(corrective_weight, (int, float)) or corrective_weight < 0:
        raise ValueError("corrective_weight must be non-negative")
    return opd_loss + float(corrective_weight) * corrective_loss
