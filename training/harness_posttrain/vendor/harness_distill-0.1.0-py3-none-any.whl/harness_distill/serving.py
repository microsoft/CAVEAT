"""Lifecycle wrapper for a frozen, local vLLM OpenAI endpoint."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any
from urllib.request import urlopen


class VllmServer(AbstractContextManager["VllmServer"]):
    def __init__(
        self,
        *,
        model_path: str | Path,
        served_model_name: str,
        output_dir: str | Path,
        port: int = 8000,
        gpu_ids: tuple[int, ...] = tuple(range(8)),
        max_model_len: int = 131072,
        data_parallel: bool = True,
        lora_path: str | Path | None = None,
    ) -> None:
        if not gpu_ids:
            raise ValueError("at least one GPU is required")
        self.model_path = str(model_path)
        self.served_model_name = served_model_name
        self.output_dir = Path(output_dir).resolve()
        self.port = int(port)
        self.gpu_ids = tuple(gpu_ids)
        self.max_model_len = int(max_model_len)
        self.data_parallel = bool(data_parallel)
        self.lora_path = None if lora_path is None else str(lora_path)
        self.process: subprocess.Popen[Any] | None = None
        self._log: Any = None

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def command(self) -> list[str]:
        # vLLM registers every served base name and every LoRA module name in
        # the same model namespace.  Reusing the student name for both makes
        # routing ambiguous (and, depending on vLLM version, is rejected).
        # Keep the public student alias exclusively attached to the adapter;
        # the frozen base remains addressable through a distinct private alias.
        base_model_name = (
            f"{self.served_model_name}-frozen-base"
            if self.lora_path is not None
            else self.served_model_name
        )
        command = [
            sys.executable,
            "-m",
            "vllm.entrypoints.openai.api_server",
            "--model",
            self.model_path,
            "--served-model-name",
            base_model_name,
            "--host",
            "127.0.0.1",
            "--port",
            str(self.port),
            "--dtype",
            "bfloat16",
            "--language-model-only",
            "--max-model-len",
            str(self.max_model_len),
            "--reasoning-parser",
            "qwen3",
            "--tool-call-parser",
            "qwen3_coder",
            "--enable-auto-tool-choice",
            "--no-enable-prefix-caching",
            "--no-enable-log-requests",
        ]
        if self.data_parallel and len(self.gpu_ids) > 1:
            command += ["--data-parallel-size", str(len(self.gpu_ids))]
        elif len(self.gpu_ids) > 1:
            command += ["--tensor-parallel-size", str(len(self.gpu_ids))]
        if self.lora_path is not None:
            command += [
                "--enable-lora",
                "--max-loras",
                "1",
                "--max-lora-rank",
                "64",
                "--lora-modules",
                f"{self.served_model_name}={self.lora_path}",
            ]
        return command

    def start(self, timeout_seconds: float = 3600.0) -> VllmServer:
        if self.process is not None:
            raise RuntimeError("vLLM server already started")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        command = self.command()
        (self.output_dir / "command.json").write_text(
            json.dumps(command, indent=2) + "\n", encoding="utf-8"
        )
        self._log = (self.output_dir / "vllm.log").open("w", encoding="utf-8")
        self.process = subprocess.Popen(
            command,
            env={
                **os.environ,
                "CUDA_VISIBLE_DEVICES": ",".join(str(value) for value in self.gpu_ids),
                "FLA_TILELANG": "0",
            },
            stdout=self._log,
            stderr=subprocess.STDOUT,
        )
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError(
                    f"vLLM exited before readiness with code {self.process.returncode}; "
                    f"see {self.output_dir / 'vllm.log'}"
                )
            try:
                with urlopen(f"{self.base_url}/health", timeout=3.0) as response:  # noqa: S310
                    if response.status == 200:
                        return self
            except Exception:
                time.sleep(2.0)
        raise TimeoutError(f"vLLM did not become ready within {timeout_seconds} seconds")

    def stop(self) -> None:
        if self.process is not None:
            self.process.terminate()
            try:
                self.process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=30)
            self.process = None
        if self._log is not None:
            self._log.close()
            self._log = None

    def __enter__(self) -> VllmServer:
        return self.start()

    def __exit__(self, *exc: object) -> None:
        self.stop()
