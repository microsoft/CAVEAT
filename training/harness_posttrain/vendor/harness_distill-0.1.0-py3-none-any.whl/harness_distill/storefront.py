"""Truthful server-rendered storefront for procedural distillation tasks.

The storefront has intentionally ordinary browser surfaces: finite numbered
pagination, HTML product pages, a cart, and checkout.  It exposes no product
JSON endpoint.  The only evaluator endpoint is the order ledger, protected by
an operations token that is never embedded in an agent-facing response.
"""

from __future__ import annotations

import argparse
import hmac
import html
import json
import os
import tempfile
import threading
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote

from fastapi import FastAPI, Form, Header, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse

from .schemas import CatalogItem, SteeringCue, TrainingTaskSpec, canonical_json

STATE_VERSION = 1
OPS_TOKEN_ENV = "STOREFRONT_OPS_TOKEN"


def state_payload(task: TrainingTaskSpec) -> dict[str, Any]:
    """Build the disk state, keeping evaluator truth outside ``agent``."""

    return {
        "state_version": STATE_VERSION,
        "agent": task.agent_view(),
        "evaluator": {
            "task_id": task.task_id,
            "mode": task.mode,
            "oracle": task.oracle.to_dict(),
        },
    }


def write_state_file(path: str | Path, task: TrainingTaskSpec) -> Path:
    """Atomically persist the public storefront state and private oracle."""

    target = Path(path).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = canonical_json(state_payload(task)) + "\n"
    descriptor, temporary = tempfile.mkstemp(
        dir=str(target.parent), prefix=f"{target.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
        os.replace(temporary, target)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return target


def read_state_file(path: str | Path) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("state_version") != STATE_VERSION:
        raise ValueError("unsupported training storefront state")
    if not isinstance(payload.get("agent"), dict):
        raise ValueError("training storefront state has no agent view")
    evaluator = payload.get("evaluator")
    if not isinstance(evaluator, dict) or not isinstance(evaluator.get("oracle"), dict):
        raise ValueError("training storefront state has no evaluator oracle")
    return payload


@dataclass(frozen=True)
class AgentStorefrontState:
    task_id: str
    instruction: str
    domain_family: str
    layout_family: str
    catalog: tuple[CatalogItem, ...]
    page_size: int
    visible_total: int
    order: tuple[str, ...]
    cues: tuple[SteeringCue, ...]
    disclosure: str

    @classmethod
    def from_state(cls, payload: Mapping[str, Any]) -> AgentStorefrontState:
        agent = payload["agent"]
        catalog = tuple(CatalogItem.from_dict(item) for item in agent["catalog"])
        steering = agent["steering"]
        state = cls(
            task_id=str(agent["task_id"]),
            instruction=str(agent["instruction"]),
            domain_family=str(agent["domain_family"]),
            layout_family=str(agent["layout_family"]),
            catalog=catalog,
            page_size=int(agent["page_size"]),
            visible_total=int(agent["visible_total"]),
            order=tuple(str(item_id) for item_id in steering["default_order"]),
            cues=tuple(SteeringCue.from_dict(cue) for cue in steering.get("cues", [])),
            disclosure=str(steering.get("disclosure", "")),
        )
        item_ids = {item.item_id for item in state.catalog}
        if state.visible_total != len(state.catalog):
            raise ValueError("visible_total does not match the public catalog")
        if set(state.order) != item_ids or len(state.order) != len(item_ids):
            raise ValueError("public default order is not a catalog permutation")
        if state.page_size < 1:
            raise ValueError("page_size must be positive")
        if any(cue.item_id not in item_ids for cue in state.cues):
            raise ValueError("public cue references an unknown item")
        return state

    @property
    def by_id(self) -> dict[str, CatalogItem]:
        return {item.item_id: item for item in self.catalog}

    @property
    def page_count(self) -> int:
        return max(1, (self.visible_total + self.page_size - 1) // self.page_size)


class TransactionState:
    """Single-shopper cart and append-only order ledger."""

    def __init__(self) -> None:
        self.cart: dict[str, int] = {}
        self.orders: list[dict[str, Any]] = []
        self._lock = threading.Lock()

    def add(self, item_id: str, quantity: int) -> None:
        with self._lock:
            self.cart[item_id] = self.cart.get(item_id, 0) + quantity

    def remove(self, item_id: str) -> None:
        with self._lock:
            self.cart.pop(item_id, None)

    def checkout(self, catalog: Mapping[str, CatalogItem]) -> dict[str, Any] | None:
        with self._lock:
            if not self.cart:
                return None
            lines = []
            for item_id, quantity in self.cart.items():
                item = catalog[item_id]
                lines.append(
                    {
                        "item_id": item_id,
                        "title": item.title,
                        "quantity": quantity,
                        "unit_price": item.price,
                        "line_total": round(item.price * quantity, 2),
                    }
                )
            order = {
                "id": f"order-{len(self.orders) + 1}",
                "items": lines,
                "total": round(sum(line["line_total"] for line in lines), 2),
            }
            self.orders.append(order)
            self.cart.clear()
            return order

    def snapshot_orders(self) -> list[dict[str, Any]]:
        with self._lock:
            return json.loads(json.dumps(self.orders))


_CSS = """
body{font-family:Arial,sans-serif;color:#171717;margin:0;background:#f7f7f7}
header{background:#151f2e;color:white;padding:16px 5%;display:flex;justify-content:space-between}
header a{color:white}main{max-width:1100px;margin:24px auto;padding:0 20px}
.summary,.card,.panel{background:white;border:1px solid #ddd;border-radius:8px;padding:16px}
.summary{margin-bottom:18px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.card h2{font-size:18px;margin:6px 0}.price{font-size:20px;font-weight:bold}
.list-price{text-decoration:line-through;color:#666;margin-left:8px}.badge{display:inline-block;
background:#e7f0ff;color:#174a8b;border-radius:3px;padding:3px 6px;margin:2px;font-size:12px}
.pager{display:flex;gap:8px;flex-wrap:wrap;margin:24px 0}.pager a,.pager strong{padding:7px 10px;
border:1px solid #bbb;background:white}.specs{border-collapse:collapse;width:100%}
.specs th,.specs td{border-bottom:1px solid #ddd;text-align:left;padding:9px}
button{padding:10px 15px}.items{list-style:none;padding:0}
.items li{background:white;border-bottom:1px solid #ddd;padding:12px}
@media(max-width:800px){.grid{grid-template-columns:1fr}}
"""


def _document(title: str, body: str, *, cart_count: int) -> HTMLResponse:
    safe_title = html.escape(title)
    return HTMLResponse(
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{safe_title}</title><style>{_CSS}</style></head><body>"
        "<header><a href='/'><strong>Choice Market</strong></a>"
        f"<a href='/cart'>Cart ({cart_count})</a></header><main>{body}</main></body></html>"
    )


def _money(value: float) -> str:
    return f"${value:,.2f}"


def _cue_map(cues: Sequence[SteeringCue]) -> dict[str, list[SteeringCue]]:
    result: dict[str, list[SteeringCue]] = {}
    for cue in cues:
        result.setdefault(cue.item_id, []).append(cue)
    return result


def _card(item: CatalogItem, cues: Sequence[SteeringCue]) -> str:
    badges = "".join(
        f"<span class='badge' data-cue='{html.escape(cue.kind)}'>{html.escape(cue.label)}</span>"
        for cue in cues
    )
    list_price = (
        f"<span class='list-price'>{_money(item.list_price)}</span>"
        if item.list_price > item.price
        else ""
    )
    return (
        f"<article class='card' data-item-id='{html.escape(item.item_id)}'>{badges}"
        f"<h2><a href='/products/{quote(item.item_id)}'>{html.escape(item.title)}</a></h2>"
        f"<div class='price'>{_money(item.price)}{list_price}</div>"
        f"<p>{item.rating:.1f} / 5 from {item.review_count:,} reviews</p>"
        "<form method='post' action='/cart/add'>"
        f"<input type='hidden' name='item_id' value='{html.escape(item.item_id)}'>"
        "<input type='hidden' name='quantity' value='1'>"
        "<button type='submit'>Add to cart</button></form></article>"
    )


def create_app(state_path: str | Path, *, ops_token: str | None = None) -> FastAPI:
    """Create one isolated storefront from a state file.

    ``ops_token`` defaults to an environment variable so it never appears in a
    process command line or rendered page.
    """

    payload = read_state_file(state_path)
    public = AgentStorefrontState.from_state(payload)
    secret = ops_token if ops_token is not None else os.environ.get(OPS_TOKEN_ENV, "")
    if not secret:
        raise ValueError(f"{OPS_TOKEN_ENV} is required and must not be agent-visible")
    transactions = TransactionState()
    app = FastAPI(
        title="Harness Distillation Training Storefront",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    app.state.public = public
    app.state.transactions = transactions
    app.state.state_path = str(Path(state_path).resolve())
    by_id = public.by_id
    cues = _cue_map(public.cues)

    def cart_count() -> int:
        return sum(transactions.cart.values())

    @app.get("/api/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/", response_class=HTMLResponse)
    def home(page: int = Query(1, ge=1)) -> HTMLResponse:
        if page > public.page_count:
            raise HTTPException(status_code=404, detail="Page does not exist")
        start = (page - 1) * public.page_size
        ids = public.order[start : start + public.page_size]
        cards = "".join(_card(by_id[item_id], cues.get(item_id, ())) for item_id in ids)
        pager = "".join(
            (
                f"<strong aria-current='page'>{number}</strong>"
                if number == page
                else f"<a href='/?page={number}' aria-label='Page {number}'>{number}</a>"
            )
            for number in range(1, public.page_count + 1)
        )
        domain_title = html.escape(public.domain_family.replace("_", " ").title())
        disclosure = (
            f"<p class='disclosure'>{html.escape(public.disclosure)}</p>"
            if public.disclosure
            else ""
        )
        body = (
            f"<section class='summary'><h1>{domain_title}</h1>"
            f"<p class='visible-total'>{public.visible_total} options total</p>"
            f"<p>Page {page} of {public.page_count}</p>{disclosure}</section>"
            f"<section class='grid'>{cards}</section><nav class='pager'>{pager}</nav>"
        )
        return _document("Choice Market", body, cart_count=cart_count())

    @app.get("/products/{item_id}", response_class=HTMLResponse)
    def product(item_id: str) -> HTMLResponse:
        item = by_id.get(item_id)
        if item is None:
            raise HTTPException(status_code=404, detail="Product not found")
        badges = "".join(
            f"<span class='badge'>{html.escape(cue.label)}</span>" for cue in cues.get(item_id, ())
        )
        fact_rows = "".join(
            f"<tr><th>{html.escape(key.replace('_', ' ').title())}</th>"
            f"<td>{html.escape(str(value))}</td></tr>"
            for key, value in sorted(item.facts.items())
        )
        body = (
            f"<article class='panel' data-item-id='{html.escape(item.item_id)}'>{badges}"
            f"<h1>{html.escape(item.title)}</h1><p class='price'>{_money(item.price)}</p>"
            f"<p>Rating: {item.rating:.1f} / 5; {item.review_count:,} reviews; "
            f"{item.purchases:,} verified purchases.</p>"
            f"<table class='specs'><tbody>{fact_rows}</tbody></table>"
            "<form method='post' action='/cart/add'>"
            f"<input type='hidden' name='item_id' value='{html.escape(item.item_id)}'>"
            "<label>Quantity <input name='quantity' type='number' value='1' "
            "min='1' max='10'></label>"
            "<button type='submit'>Add to cart</button></form></article>"
        )
        return _document(item.title, body, cart_count=cart_count())

    @app.post("/cart/add")
    def add_to_cart(item_id: str = Form(...), quantity: int = Form(1)) -> RedirectResponse:
        if item_id not in by_id:
            raise HTTPException(status_code=404, detail="Product not found")
        if quantity < 1 or quantity > 10:
            raise HTTPException(status_code=422, detail="Quantity must be between 1 and 10")
        transactions.add(item_id, quantity)
        return RedirectResponse("/cart", status_code=303)

    @app.get("/cart", response_class=HTMLResponse)
    def cart() -> HTMLResponse:
        lines = []
        total = 0.0
        for item_id, quantity in transactions.cart.items():
            item = by_id[item_id]
            line_total = item.price * quantity
            total += line_total
            lines.append(
                f"<li data-item-id='{html.escape(item_id)}'>"
                f"<strong>{html.escape(item.title)}</strong> "
                f"— quantity {quantity} — {_money(line_total)} "
                "<form method='post' action='/cart/remove' style='display:inline'>"
                f"<input type='hidden' name='item_id' value='{html.escape(item_id)}'>"
                "<button type='submit'>Remove</button></form></li>"
            )
        contents = "".join(lines) or "<li>Your cart is empty.</li>"
        checkout = (
            "<form method='post' action='/checkout'>"
            "<button type='submit'>Place order</button></form>"
            if transactions.cart
            else ""
        )
        body = (
            f"<section class='panel'><h1>Cart</h1><ul class='items'>{contents}</ul>"
            f"<p><strong>Total: {_money(total)}</strong></p>{checkout}</section>"
        )
        return _document("Cart", body, cart_count=cart_count())

    @app.post("/cart/remove")
    def remove_from_cart(item_id: str = Form(...)) -> RedirectResponse:
        transactions.remove(item_id)
        return RedirectResponse("/cart", status_code=303)

    @app.post("/checkout", response_class=HTMLResponse)
    def checkout() -> HTMLResponse:
        order = transactions.checkout(by_id)
        if order is None:
            raise HTTPException(status_code=400, detail="Cart is empty")
        items = "".join(
            f"<li>{html.escape(line['title'])} × {line['quantity']}</li>" for line in order["items"]
        )
        body = (
            "<section class='panel'><h1>Order confirmed</h1>"
            f"<p>Order {html.escape(order['id'])}</p>"
            f"<ul>{items}</ul><p>Total: {_money(order['total'])}</p></section>"
        )
        return _document("Order confirmed", body, cart_count=0)

    @app.get("/api/orders")
    def evaluator_orders(
        x_storefront_ops: str | None = Header(default=None, alias="X-Storefront-Ops"),
    ) -> dict[str, Any]:
        if x_storefront_ops is None or not hmac.compare_digest(x_storefront_ops, secret):
            raise HTTPException(status_code=403, detail="Forbidden")
        return {"orders": transactions.snapshot_orders()}

    return app


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--state", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    import uvicorn

    app = create_app(args.state)
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
