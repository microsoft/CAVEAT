"""Isolated AgentArena worker with an audited per-run Qwen proxy.

The ordinary AgentArena worker imports only built-in environments.  Procedural
training runs need one opt-in package environment, and every run needs an
independent proxy/session so preserved reasoning can never bleed across
repetitions.  This module provides that isolation without changing AgentArena.
"""

from __future__ import annotations

import json
import os
import secrets
import subprocess
import sys
import time
from pathlib import Path
from typing import Any
from urllib.request import urlopen

from .proxy import SESSION_ID_ENV


def _new_rollout_session_id() -> str:
    """Return an opaque identity scoped to exactly one worker/episode."""

    return secrets.token_hex(32)


def _wait(url: str, process: subprocess.Popen[Any], timeout: float = 120.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"compatibility proxy exited with code {process.returncode}")
        try:
            with urlopen(url, timeout=2.0) as response:  # noqa: S310 - local loopback only
                if response.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise TimeoutError(f"compatibility proxy did not become ready: {url}")


def _stop(process: subprocess.Popen[Any] | None) -> None:
    if process is None:
        return
    process.terminate()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def main() -> int:
    spec = json.loads(sys.stdin.read())
    out_dir = Path(spec["out_dir"]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    trace_path = out_dir / "model_requests.jsonl"
    proxy_log = (out_dir / "proxy.log").open("w", encoding="utf-8")
    proxy: subprocess.Popen[Any] | None = None
    try:
        proxy_env = {
            **os.environ,
            "HARNESS_DISTILL_UPSTREAM_BASE_URL": str(spec["upstream_base_url"]).rstrip("/"),
            "HARNESS_DISTILL_UPSTREAM_API_KEY": str(spec.get("upstream_api_key", "")),
            "HARNESS_DISTILL_TRACE_JSONL": str(trace_path),
            SESSION_ID_ENV: _new_rollout_session_id(),
        }
        proxy_port = int(spec["proxy_port"])
        proxy = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "harness_distill.proxy:app_from_environment",
                "--factory",
                "--host",
                "127.0.0.1",
                "--port",
                str(proxy_port),
                "--log-level",
                "warning",
            ],
            env=proxy_env,
            stdout=proxy_log,
            stderr=subprocess.STDOUT,
        )
        _wait(f"http://127.0.0.1:{proxy_port}/healthz", proxy)

        # Built-ins register first; the procedural environment registers only
        # through this explicit import and is never added to the benchmark.
        import agentarena.envs  # noqa: F401
        import agentarena.scaffolds  # noqa: F401
        from agentarena.core.experiment import run_cell
        from agentarena.core.models import ModelSpec
        from agentarena.core.task import TaskSpec

        import harness_distill.training_env  # noqa: F401

        model = ModelSpec.parse(
            {
                "name": spec["model_label"],
                "provider": "openai",
                "base_url": f"http://127.0.0.1:{proxy_port}/v1",
                "api_key": "local-audited-proxy",
                "deployment": spec["wire_model"],
                "vision": False,
            }
        )
        trajectory = run_cell(
            env_name=spec["env"],
            scaffold_name=spec.get("scaffold", "browseruse"),
            model=model,
            task=TaskSpec.parse(spec["task"]),
            condition=spec["condition"],
            port=int(spec["environment_port"]),
            out_dir=out_dir,
            max_steps=int(spec.get("max_steps", 4000)),
            headless=True,
        )
        print(json.dumps(trajectory.summary(), sort_keys=True))
        return 0 if trajectory.evaluation and trajectory.evaluation.outcome != "error" else 1
    finally:
        _stop(proxy)
        proxy_log.close()


if __name__ == "__main__":
    raise SystemExit(main())
