"""Hash-bound Browser Use limit contracts for measured rollouts.

AgentArena records whether a run touched a stopping ceiling only when the
launcher supplies an exact ``AGENTARENA_LIMIT_CONTRACT_JSON``.  This module
owns the contract for harness-distillation rollouts.  The two campaign-wide
ceilings are parameters; fixed and lossy surfaces are read from the vendored
AgentArena runtime so they cannot silently drift away from what is audited.
"""

from __future__ import annotations

import hashlib
import importlib
from collections.abc import Mapping
from copy import deepcopy
from typing import Any

from .schemas import canonical_json

LIMIT_AUDIT_SCHEMA_VERSION = 1

# These are deliberately generous safety backstops, not measured task
# constraints.  They match the benchmark's audited Browser Use profile while
# the whole-run and maximum-step ceilings remain caller-configured.
LLM_TIMEOUT_SECONDS = 7_200
LLM_HTTP_TIMEOUT_SECONDS = 7_260
STEP_TIMEOUT_SECONDS = 7_500
EXTRACT_LLM_TIMEOUT_SECONDS = 7_500
CDP_REQUEST_TIMEOUT_SECONDS = 7_500
BROWSER_ACTION_TIMEOUT_SECONDS = 7_500
MAX_CONSECUTIVE_FAILURES = 1_000
EVENT_TIMEOUT_SECONDS = 600

EVENT_TIMEOUT_NAMES = (
    "AgentEventBusStop",
    "AgentFocusChangedEvent",
    "BrowserConnectedEvent",
    "BrowserErrorEvent",
    "BrowserKillEvent",
    "BrowserLaunchEvent",
    "BrowserReconnectedEvent",
    "BrowserReconnectingEvent",
    "BrowserSessionEventBusStopOnAgentClose",
    "BrowserStartEvent",
    "BrowserStateRequestEvent",
    "BrowserStopEvent",
    "BrowserStoppedEvent",
    "CaptchaSolverFinishedEvent",
    "CaptchaSolverStartedEvent",
    "CaptchaSolverWait",
    "ClickCoordinateEvent",
    "ClickElementEvent",
    "CloseTabEvent",
    "DownloadProgressEvent",
    "DownloadStartedEvent",
    "FileDownloadedEvent",
    "GetDropdownOptionsEvent",
    "GoBackEvent",
    "GoForwardEvent",
    "LoadStorageStateEvent",
    "NavigateToUrlEvent",
    "NavigationCompleteEvent",
    "NavigationStartedEvent",
    "RefreshEvent",
    "SaveStorageStateEvent",
    "ScreenshotEvent",
    "ScrollEvent",
    "ScrollToTextEvent",
    "SelectDropdownOptionEvent",
    "SendKeysEvent",
    "StorageStateLoadedEvent",
    "StorageStateSavedEvent",
    "SwitchTabEvent",
    "TabClosedEvent",
    "TabCreatedEvent",
    "TargetCrashedEvent",
    "TypeTextEvent",
    "UploadFileEvent",
    "WaitEvent",
)

DEPENDENCY_INNER_TIMEOUTS = {
    "local_browser_launch_attempts": 3,
    "local_browser_cdp_ready_seconds": 30,
    "cdp_connect_seconds": 15,
    "page_navigate_seconds": 20,
    "page_ready_same_domain_seconds": 3,
    "page_ready_cross_domain_seconds": 8,
    "reconnect_attempts": 3,
    "reconnect_attempt_seconds": 15,
    "reconnect_wait_seconds": 54,
    "dom_wait_seconds": [1, 2, 10],
    "click_type_wait_seconds": [2, 3, 5, 10, 15],
    "tool_wait_seconds": [2, 3, 30],
    "download_wait_seconds": [3, 5, 10, 15, 20],
    "popup_wait_seconds": 0.5,
    "websocket_frame_bytes": 200 * 1024**2,
}


def _positive_integer(value: object, name: str) -> int:
    if type(value) is not int or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _record(configured: object, source: str) -> dict[str, Any]:
    return {
        "applicability": ["baseline"],
        "configured": deepcopy(configured),
        "source": source,
    }


def _browseruse_runtime() -> Any:
    # AgentArena is an immutable vendored wheel in the campaign image.  Import
    # lazily so data-generation-only users do not need the browser dependency.
    return importlib.import_module("agentarena.scaffolds.browseruse")


def browseruse_limit_contract(
    *,
    max_steps: int,
    run_timeout_seconds: int,
) -> dict[str, Any]:
    """Return the exact baseline Browser Use contract for one rollout batch."""

    max_steps = _positive_integer(max_steps, "max_steps")
    run_timeout_seconds = _positive_integer(run_timeout_seconds, "run_timeout_seconds")
    runtime = _browseruse_runtime()

    lossy_context = {
        name: _record(configured, "browser_use prompt/tool context")
        for name, (configured, _comparison) in runtime._LOSSY_CONTEXT_CAPS.items()
    }
    safety_backstops = {
        "max_steps": _record(max_steps, "AgentArena RunContext / Agent.run"),
        "whole_run_timeout_seconds": _record(
            run_timeout_seconds,
            "AGENTARENA_CELL_TIMEOUT / agentarena.scaffolds.browseruse._run",
        ),
        "llm_timeout_seconds": _record(
            LLM_TIMEOUT_SECONDS, "browser_use.agent.service.Agent"
        ),
        "llm_http_timeout_seconds": _record(
            LLM_HTTP_TIMEOUT_SECONDS, "openai/httpx client"
        ),
        "step_timeout_seconds": _record(
            STEP_TIMEOUT_SECONDS, "browser_use.agent.service.Agent._execute_step"
        ),
        "extract_llm_timeout_seconds": _record(
            EXTRACT_LLM_TIMEOUT_SECONDS, "browser_use.tools.service extract patch"
        ),
        "cdp_request_timeout_seconds": _record(
            CDP_REQUEST_TIMEOUT_SECONDS, "browser_use.browser._cdp_timeout"
        ),
        "browser_action_timeout_seconds": _record(
            BROWSER_ACTION_TIMEOUT_SECONDS, "browser_use.tools.service.Tools.act"
        ),
        "max_consecutive_failures": _record(
            MAX_CONSECUTIVE_FAILURES, "browser_use.agent.service.Agent"
        ),
        "llm_sdk_max_retries": _record(
            {
                "retries": 16,
                "effective_attempts": 17,
                "retry_statuses": [408, 409, 429, ">=500"],
                "retry_after_max_seconds": 60,
                "exponential_backoff_max_seconds": 8,
            },
            "openai._base_client",
        ),
        "event_timeouts_seconds": _record(
            {name: EVENT_TIMEOUT_SECONDS for name in EVENT_TIMEOUT_NAMES},
            "browser_use event bus TIMEOUT_* environment",
        ),
        "dependency_inner_timeouts": _record(
            DEPENDENCY_INNER_TIMEOUTS, "browser_use browser/session/watchdogs/tools"
        ),
        "evaluate_result_single_chars": _record(
            runtime._EVALUATE_SINGLE_MAX_CHARS,
            "agentarena.scaffolds.browseruse common evaluate spill",
        ),
        "evaluate_result_store_bytes": _record(
            runtime._EVALUATE_STORE_MAX_BYTES,
            "agentarena.scaffolds.browseruse._EvaluateResultStore",
        ),
        "evaluate_result_store_responses": _record(
            runtime._EVALUATE_STORE_MAX_RESPONSES,
            "agentarena.scaffolds.browseruse._EvaluateResultStore",
        ),
    }
    fixed_architecture = {
        "max_completion_tokens": _record("off", "ChatOpenAI"),
        "max_actions_per_step": _record(5, "browser_use.agent.service.Agent"),
        "fallback_llm_depth": _record(1, "browser_use.agent.service.Agent"),
        "message_compaction": _record(
            {
                "enabled": True,
                "compact_every_n_steps": 25,
                "trigger_char_count": 40_000,
                "keep_last_items": 6,
                "summary_max_chars": 6_000,
                "include_read_state": False,
            },
            "browser_use.agent.message_manager.service",
        ),
        "post_task_auxiliary_judge": _record(
            runtime._POST_TASK_AUXILIARY_JUDGE_CONFIGURATION,
            "browser_use.agent.service.Agent",
        ),
        "evaluate_result_spill": _record(
            runtime._EVALUATE_RESULT_SPILL_CONFIGURATION,
            "agentarena.scaffolds.browseruse common evaluate spill",
        ),
        "extract_result_file_externalization": _record(
            runtime._EXTRACT_RESULT_FILE_EXTERNALIZATION_CONFIGURATION,
            "browser_use.tools.service.Tools.extract",
        ),
        "agent_output_validation_feedback_rendering": _record(
            runtime._AGENT_OUTPUT_VALIDATION_FEEDBACK_RENDERING_CONFIGURATION,
            "browser_use Agent error rendering",
        ),
        "replace_file_recursive_amplification_guard": _record(
            runtime._REPLACE_FILE_RECURSIVE_AMPLIFICATION_GUARD_CONFIGURATION,
            "agentarena.scaffolds.browseruse common replace_file guard",
        ),
    }
    payload = {
        "schema_version": LIMIT_AUDIT_SCHEMA_VERSION,
        "categories": {
            # Only this category can invalidate a run as backstop-bound.
            "safety_backstops": safety_backstops,
            # These report information loss and fixed policy architecture;
            # touching them is diagnostic, never a stopping-ceiling signal.
            "lossy_context_limits": lossy_context,
            "fixed_architecture": fixed_architecture,
        },
        "near_policy": {
            "evaluate_result_single_fraction": 0.25,
            "evaluate_result_store_fraction": 0.25,
            "whole_run_fraction": 0.99,
        },
    }
    return {
        **payload,
        "sha256": hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest(),
    }


def browseruse_limit_environment(contract: Mapping[str, Any]) -> dict[str, str]:
    """Serialize one contract and the exact live settings which it declares."""

    safety = contract["categories"]["safety_backstops"]
    event_timeouts = safety["event_timeouts_seconds"]["configured"]
    environment = {
        "AGENTARENA_CELL_TIMEOUT": str(safety["whole_run_timeout_seconds"]["configured"]),
        "AGENTARENA_LLM_TIMEOUT": str(safety["llm_timeout_seconds"]["configured"]),
        "AGENTARENA_MAX_FAILURES": str(safety["max_consecutive_failures"]["configured"]),
        "AGENTARENA_MAX_COMPLETION_TOKENS": "off",
        "BROWSER_USE_EXTRACT_TIMEOUT_S": str(
            safety["extract_llm_timeout_seconds"]["configured"]
        ),
        "BROWSER_USE_CDP_TIMEOUT_S": str(
            safety["cdp_request_timeout_seconds"]["configured"]
        ),
        "BROWSER_USE_ACTION_TIMEOUT_S": str(
            safety["browser_action_timeout_seconds"]["configured"]
        ),
        "AGENTARENA_LIMIT_CONTRACT_JSON": canonical_json(contract),
    }
    environment.update(
        {f"TIMEOUT_{name}": str(seconds) for name, seconds in event_timeouts.items()}
    )
    return environment


def rollout_worker_environment(
    parent_environment: Mapping[str, str],
    contract: Mapping[str, Any],
) -> dict[str, str]:
    """Return the complete, deterministic environment for a rollout worker."""

    return {
        **parent_environment,
        "AGENTARENA_NO_SHOT_PERSIST": "1",
        **browseruse_limit_environment(contract),
    }
