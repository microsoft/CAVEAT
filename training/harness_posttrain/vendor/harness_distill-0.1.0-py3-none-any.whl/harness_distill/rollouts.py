"""Concurrent, resumable actual-browser rollout collection."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .limit_contract import browseruse_limit_contract, rollout_worker_environment
from .schemas import TrainingTaskSpec, canonical_json

MODEL_IDENTITY_SCHEMA = "harness-distill.model-checkpoint-identity.v1"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def checkpoint_tree_identity(
    model_path: str | Path,
    *,
    served_model: str,
    model_id: str | None = None,
    revision: str | None = None,
    ignored_relative_paths: Sequence[str] = (),
) -> dict[str, Any]:
    """Hash every checkpoint byte and its relative tree position.

    The returned mapping is safe to persist in rollout provenance.  It contains
    no credentials and makes a resumed rollout directory specific to one exact
    set of model bytes, rather than merely to a mutable model label or endpoint.
    """

    root = Path(model_path).resolve()
    if not root.is_dir():
        raise ValueError(f"model checkpoint directory does not exist: {root}")
    if not isinstance(served_model, str) or not served_model:
        raise ValueError("served_model must be non-empty text")
    ignored = frozenset(str(value) for value in ignored_relative_paths)
    digest = hashlib.sha256()
    file_count = 0
    total_bytes = 0
    for path in sorted(candidate for candidate in root.rglob("*") if candidate.is_file()):
        relative = path.relative_to(root).as_posix()
        if relative in ignored:
            continue
        size = path.stat().st_size
        entry = {
            "path": relative,
            "bytes": size,
            "sha256": _sha256_file(path),
            "symlink_target": os.readlink(path) if path.is_symlink() else None,
        }
        encoded = canonical_json(entry).encode()
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        file_count += 1
        total_bytes += size
    if file_count == 0:
        raise ValueError(f"model checkpoint contains no files: {root}")
    return {
        "schema": MODEL_IDENTITY_SCHEMA,
        "checkpoint_path": str(root),
        "served_model": served_model,
        "model_id": model_id or served_model,
        "revision": revision,
        "tree_sha256": digest.hexdigest(),
        "file_count": file_count,
        "total_bytes": total_bytes,
    }


def _validated_model_identity(value: Mapping[str, Any], *, wire_model: str) -> dict[str, Any]:
    try:
        frozen = json.loads(canonical_json(dict(value)))
    except (TypeError, ValueError) as exc:
        raise ValueError("model_identity must be finite JSON") from exc
    if frozen.get("schema") != MODEL_IDENTITY_SCHEMA:
        raise ValueError("model_identity has an unsupported schema")
    if frozen.get("served_model") != wire_model:
        raise ValueError("model_identity served_model differs from wire_model")
    digest = frozen.get("tree_sha256")
    if (
        not isinstance(digest, str)
        or len(digest) != 64
        or any(character not in "0123456789abcdef" for character in digest)
    ):
        raise ValueError("model_identity tree_sha256 must be 64 lowercase hex characters")
    if not isinstance(frozen.get("checkpoint_path"), str):
        raise ValueError("model_identity requires checkpoint_path")
    if not isinstance(frozen.get("file_count"), int) or frozen["file_count"] < 1:
        raise ValueError("model_identity requires a positive file_count")
    return frozen


def _runtime_identity() -> dict[str, str]:
    def version(distribution: str) -> str:
        try:
            return importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError:
            return "unavailable"

    return {
        "python": platform.python_version(),
        "agentarena": version("agentarena"),
        "browser_use": version("browser-use"),
        "harness_distill": version("harness-distill"),
    }


def _safe(value: str) -> str:
    return value.replace("/", "-").replace(" ", "-")


def _agentarena_task(task: TrainingTaskSpec) -> dict[str, Any]:
    # Import lazily so generation/tests do not need AgentArena installed.
    from .training_env import to_agentarena_task

    wrapped = to_agentarena_task(task)
    return {
        "task_id": wrapped.task_id,
        "env": wrapped.env,
        "instruction": wrapped.instruction,
        "preferences": wrapped.preferences,
        "catalog": wrapped.catalog,
        "condition": wrapped.condition,
        "start_path": wrapped.start_path,
        "params": wrapped.params,
        "metadata": wrapped.metadata,
    }


def procedural_specs(
    tasks: Iterable[TrainingTaskSpec],
    *,
    repetitions: int = 1,
) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    for task in tasks:
        for repetition in range(repetitions):
            specs.append(
                {
                    "run_id": f"{task.task_id}-r{repetition + 1}",
                    "env": "harness-distill-training",
                    "task": _agentarena_task(task),
                    "condition": task.condition,
                    "repetition": repetition + 1,
                }
            )
    return specs


def amazon_specs(
    scenarios: Iterable[str],
    variants: Iterable[str],
    conditions: Iterable[str],
    *,
    repetitions: int,
) -> list[dict[str, Any]]:
    import agentarena.envs  # noqa: F401
    from agentarena.benchmark.registry import benchmark_tasks

    specs: list[dict[str, Any]] = []
    for scenario in scenarios:
        by_variant = {
            str(task.metadata["variant"]): task
            for task in benchmark_tasks(scenario, variants=tuple(variants))
        }
        for variant in variants:
            task = by_variant[variant]
            task_dict = {
                "task_id": task.task_id,
                "env": task.env,
                "instruction": task.instruction,
                "preferences": task.preferences,
                "catalog": task.catalog,
                "condition": task.condition,
                "start_path": task.start_path,
                "params": task.params,
                "metadata": task.metadata,
            }
            for condition in conditions:
                for repetition in range(repetitions):
                    specs.append(
                        {
                            "run_id": (f"{scenario}-{variant}-{condition}-r{repetition + 1}"),
                            "env": "amazon",
                            "task": task_dict,
                            "condition": condition,
                            "repetition": repetition + 1,
                        }
                    )
    return specs


def _done(path: Path) -> bool:
    summary = path / "summary.json"
    trajectory = path / "trajectory.json"
    if not summary.is_file() or not trajectory.is_file():
        return False
    try:
        payload = json.loads(summary.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return payload.get("outcome") not in {None, "error"}


def _quarantine_incomplete(root: Path, run_dir: Path, run_id: str) -> Path | None:
    """Preserve a partial prior attempt before reusing its canonical run path.

    Proxy traces are append-only. Re-launching directly into a failed run
    directory would mix two stochastic attempts and make later supervision or
    tool-validity audits ambiguous. Moving the whole directory is atomic on the
    run filesystem and keeps every byte available for infrastructure diagnosis.
    """

    if not run_dir.exists() or not any(run_dir.iterdir()):
        return None
    archive_root = root / "incomplete_attempts" / _safe(run_id)
    archive_root.mkdir(parents=True, exist_ok=True)
    attempt = 1
    while (archive_root / f"attempt-{attempt:03d}").exists():
        attempt += 1
    destination = archive_root / f"attempt-{attempt:03d}"
    run_dir.replace(destination)
    return destination


def collect_rollouts(
    specs: Iterable[Mapping[str, Any]],
    *,
    output_dir: str | Path,
    upstream_base_url: str,
    wire_model: str,
    model_label: str,
    model_identity: Mapping[str, Any],
    run_timeout_seconds: int,
    upstream_api_key: str = "",
    jobs: int = 8,
    base_port: int = 18000,
    max_steps: int = 4000,
    scaffold: str = "browseruse",
    force: bool = False,
    spawn_stagger_seconds: float = 1.0,
) -> dict[str, Any]:
    """Run each spec in its own process/proxy/browser and write a manifest.

    ``max_steps`` is a non-measured safety backstop.  Confirmatory analysis must
    separately reject any run whose AgentArena limit audit says it bound.
    """

    if jobs < 1:
        raise ValueError("jobs must be positive")
    if type(run_timeout_seconds) is not int or run_timeout_seconds < 1:
        raise ValueError("run_timeout_seconds must be a positive integer")
    if type(max_steps) is not int or max_steps < 1:
        raise ValueError("max_steps must be a positive integer")
    if scaffold != "browseruse":
        raise ValueError("the audited rollout limit contract requires scaffold='browseruse'")
    root = Path(output_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    normalized = [dict(spec) for spec in specs]
    frozen_model_identity = _validated_model_identity(model_identity, wire_model=wire_model)
    runtime_identity = _runtime_identity()
    limit_contract = browseruse_limit_contract(
        max_steps=max_steps,
        run_timeout_seconds=run_timeout_seconds,
    )
    manifest = {
        "schema": "harness-distill.rollout-campaign.v3",
        "upstream_base_url": upstream_base_url,
        "wire_model": wire_model,
        "model_label": model_label,
        "model_identity": frozen_model_identity,
        "runtime_identity": runtime_identity,
        "scaffold": scaffold,
        "max_steps_safety_backstop": max_steps,
        "run_timeout_seconds_safety_backstop": run_timeout_seconds,
        "limit_contract": limit_contract,
        "run_count": len(normalized),
        "spec_sha256": hashlib.sha256(canonical_json(normalized).encode()).hexdigest(),
    }
    manifest_path = root / "manifest.json"
    if manifest_path.is_file():
        try:
            existing_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"cannot resume corrupt rollout manifest: {manifest_path}") from exc
        if existing_manifest != manifest:
            raise RuntimeError(
                f"rollout campaign identity changed at existing output: {manifest_path}"
            )
    else:
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )

    pending: list[tuple[int, dict[str, Any], Path]] = []
    skipped = 0
    quarantined: list[dict[str, str]] = []
    for index, spec in enumerate(normalized):
        run_dir = root / _safe(str(spec["run_id"]))
        run_provenance = {
            "schema": "harness-distill.rollout-run-provenance.v2",
            "campaign_manifest_sha256": hashlib.sha256(
                canonical_json(manifest).encode()
            ).hexdigest(),
            "run_id": str(spec["run_id"]),
            "spec_sha256": hashlib.sha256(canonical_json(spec).encode()).hexdigest(),
            "model_identity": frozen_model_identity,
            "runtime_identity": runtime_identity,
            "scaffold": scaffold,
            "max_steps_safety_backstop": max_steps,
            "run_timeout_seconds_safety_backstop": run_timeout_seconds,
            "limit_contract_sha256": limit_contract["sha256"],
        }
        if not force and _done(run_dir):
            provenance_path = run_dir / "run_provenance.json"
            try:
                existing_provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise RuntimeError(f"completed rollout lacks valid provenance: {run_dir}") from exc
            if existing_provenance != run_provenance:
                raise RuntimeError(f"completed rollout provenance changed: {run_dir}")
            skipped += 1
            continue
        archived = _quarantine_incomplete(root, run_dir, str(spec["run_id"]))
        if archived is not None:
            quarantined.append(
                {
                    "run_id": str(spec["run_id"]),
                    "archived_path": str(archived),
                }
            )
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "run_provenance.json").write_text(
            json.dumps(run_provenance, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        pending.append((index, spec, run_dir))

    running: list[tuple[dict[str, Any], Path, subprocess.Popen[str], Any]] = []
    failures: list[str] = []
    while pending or running:
        while pending and len(running) < jobs:
            index, spec, run_dir = pending.pop(0)
            payload = {
                **spec,
                "out_dir": str(run_dir),
                "upstream_base_url": upstream_base_url,
                "upstream_api_key": upstream_api_key,
                "wire_model": wire_model,
                "model_label": model_label,
                "scaffold": scaffold,
                "max_steps": max_steps,
                "environment_port": base_port + index * 2,
                "proxy_port": base_port + index * 2 + 1,
            }
            log = (run_dir / "worker.log").open("w", encoding="utf-8")
            process = subprocess.Popen(
                [sys.executable, "-m", "harness_distill.rollout_worker"],
                stdin=subprocess.PIPE,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                env=rollout_worker_environment(os.environ, limit_contract),
            )
            assert process.stdin is not None
            process.stdin.write(json.dumps(payload))
            process.stdin.close()
            running.append((spec, run_dir, process, log))
            if pending and spawn_stagger_seconds > 0:
                time.sleep(spawn_stagger_seconds)

        still_running: list[tuple[dict[str, Any], Path, subprocess.Popen[str], Any]] = []
        for spec, run_dir, process, log in running:
            return_code = process.poll()
            if return_code is None:
                still_running.append((spec, run_dir, process, log))
                continue
            log.close()
            if return_code != 0 or not _done(run_dir):
                failures.append(str(spec["run_id"]))
        running = still_running
        if pending or running:
            time.sleep(1.0)

    summaries = []
    for spec in normalized:
        path = root / _safe(str(spec["run_id"])) / "summary.json"
        if path.is_file():
            summaries.append(json.loads(path.read_text(encoding="utf-8")))
    result = {
        "requested": len(normalized),
        "already_complete": skipped,
        "quarantined_incomplete_attempts": quarantined,
        "completed": len(summaries),
        "failed_run_ids": failures,
        "valid_purchase_rate": (
            sum(summary.get("chosen") is not None for summary in summaries) / len(summaries)
            if summaries
            else 0.0
        ),
        "optimal_product_rate": (
            sum(
                summary.get("outcome") in {"optimal", "compliant"} and bool(summary.get("success"))
                for summary in summaries
            )
            / len(summaries)
            if summaries
            else 0.0
        ),
    }
    (root / "collection_summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return result
