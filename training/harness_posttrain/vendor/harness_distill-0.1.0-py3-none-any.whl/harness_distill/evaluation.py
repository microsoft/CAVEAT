"""Headroom gating and sealed Amazon-five evaluation."""

from __future__ import annotations

import json
import math
import random
from collections import defaultdict
from pathlib import Path
from typing import Any

from .config import Campaign, atomic_json
from .rollouts import amazon_specs, checkpoint_tree_identity, collect_rollouts
from .serving import VllmServer


def snapshot_model(model: dict[str, Any], cache_root: str | Path) -> Path:
    from huggingface_hub import snapshot_download

    cache = Path(cache_root).resolve()
    cache.mkdir(parents=True, exist_ok=True)
    path = snapshot_download(
        repo_id=model["model_id"],
        revision=model["revision"],
        cache_dir=cache,
    )
    return Path(path).resolve()


def _limit_bound(stats: dict[str, Any]) -> bool:
    audit = stats.get("limit_audit")
    if not isinstance(audit, dict):
        return True
    if audit.get("complete") is not True:
        return True
    if audit.get("error") not in {None, ""}:
        return True
    # Only the declared safety-backstop category can invalidate a run. Fixed
    # architecture and lossy-context diagnostics are reported separately and
    # are not experimental stopping constraints.
    categories = audit.get("categories")
    if not isinstance(categories, dict):
        return True
    backstops = categories.get("safety_backstops")
    if not isinstance(backstops, dict):
        return True
    for entry in backstops.values():
        if not isinstance(entry, dict):
            return True
        touched = entry.get("touched_count")
        if not isinstance(touched, int) or isinstance(touched, bool):
            return True
        if touched != 0:
            return True
    return False


def score_amazon_runs(run_root: str | Path, scenarios: list[str]) -> dict[str, Any]:
    from agentarena.scoring.rescore import cell_binary, cell_strict

    root = Path(run_root)
    records: list[dict[str, Any]] = []
    for trajectory_path in sorted(root.glob("*/trajectory.json")):
        payload = json.loads(trajectory_path.read_text(encoding="utf-8"))
        run_name = trajectory_path.parent.name
        parts = run_name.split("-")
        scenario = next(
            (name for name in scenarios if trajectory_path.parent.name.startswith(name + "-")), None
        )
        if scenario is None:
            continue
        evaluation = payload.get("evaluation") or {}
        chosen = evaluation.get("chosen")
        condition = payload.get("condition")
        task_id = str(payload.get("task_id", ""))
        variant = task_id.rsplit("-", 1)[-1] if "-" in task_id else None
        repetition = None
        if "-r" in run_name:
            try:
                repetition = int(run_name.rsplit("-r", 1)[-1])
            except ValueError:
                repetition = None
        strict_binary = cell_binary(str(trajectory_path))
        record = {
            "run": run_name,
            "scenario": scenario,
            "variant": variant,
            "condition": condition,
            "repetition": repetition,
            "chosen": chosen,
            "optimal": strict_binary == 1.0,
            "valid_purchase": chosen is not None
            and evaluation.get("outcome") not in {"error", "none"},
            "steps": len(payload.get("steps", [])),
            "duration_seconds": (payload.get("stats") or {}).get("seconds"),
            "backstop_bound": _limit_bound(payload.get("stats") or {}),
            "preservation_strict": cell_strict(str(trajectory_path), soft=False),
            "strict_binary": strict_binary,
            "parts": parts,
        }
        records.append(record)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[str(record["condition"])].append(record)
    return {
        "runs": records,
        "run_count": len(records),
        "optimal_product_rate": (
            sum(record["optimal"] for record in records) / len(records) if records else 0.0
        ),
        "valid_purchase_rate": (
            sum(record["valid_purchase"] for record in records) / len(records) if records else 0.0
        ),
        "binding_backstop_runs": sum(record["backstop_bound"] for record in records),
        "mean_preservation_strict": (
            sum(
                float(record["preservation_strict"])
                for record in records
                if record["preservation_strict"] is not None
            )
            / sum(record["preservation_strict"] is not None for record in records)
            if any(record["preservation_strict"] is not None for record in records)
            else None
        ),
        "by_condition": {
            condition: {
                "n": len(values),
                "optimal_product_rate": sum(value["optimal"] for value in values) / len(values),
                "valid_purchase_rate": sum(value["valid_purchase"] for value in values)
                / len(values),
            }
            for condition, values in sorted(grouped.items())
        },
    }


def run_headroom(campaign: Campaign, output_dir: str | Path) -> dict[str, Any]:
    output = Path(output_dir).resolve()
    gate = campaign.models["selection_gate"]
    variants = list(campaign.evaluation["variants"])
    specs = amazon_specs([gate["development_scenario"]], variants, ["combined"], repetitions=3)
    specs += amazon_specs([gate["development_scenario"]], variants, ["clean"], repetitions=1)
    if len(specs) != gate["combined_runs"] + gate["clean_runs"]:
        raise AssertionError("headroom matrix drift")

    attempts = []
    for role in gate["order"]:
        model = campaign.model(role)
        attempt_dir = output / "eval" / "headroom" / role
        try:
            snapshot = snapshot_model(model, output / "models" / "cache")
            model_identity = checkpoint_tree_identity(
                snapshot,
                served_model=str(model["model_id"]),
                model_id=str(model["model_id"]),
                revision=str(model["revision"]),
            )
            with VllmServer(
                model_path=snapshot,
                served_model_name=model["model_id"],
                output_dir=attempt_dir / "server",
            ) as server:
                collection = collect_rollouts(
                    specs,
                    output_dir=attempt_dir / "runs",
                    upstream_base_url=server.base_url,
                    wire_model=model["model_id"],
                    model_label=f"{model['model_id']}-headroom",
                    model_identity=model_identity,
                    run_timeout_seconds=int(
                        campaign.evaluation["safety_backstops"]["run_timeout_seconds"]
                    ),
                    jobs=min(16, len(specs)),
                    base_port=19000 if role == "primary" else 19500,
                    max_steps=4000,
                    spawn_stagger_seconds=1.0,
                )
            scores = score_amazon_runs(attempt_dir / "runs", [gate["development_scenario"]])
        except Exception as exc:  # noqa: BLE001 - a failed primary must permit the frozen fallback
            attempt = {
                "role": role,
                "model": model,
                "passed": False,
                "status": "runtime_error",
                "exception_type": type(exc).__name__,
                "error": str(exc),
            }
            attempts.append(attempt)
            atomic_json(attempt_dir / "gate.json", attempt)
            continue
        combined = scores["by_condition"].get("combined", {})
        passed = (
            collection["completed"] == len(specs)
            and sum(run["valid_purchase"] for run in scores["runs"])
            >= gate["minimum_valid_transactions"]
            and combined.get("optimal_product_rate", 1.0)
            <= gate["maximum_combined_optimal_product_rate"]
            and scores["binding_backstop_runs"] == 0
        )
        attempt = {
            "role": role,
            "model": model,
            "snapshot": str(snapshot),
            "collection": collection,
            "scores": scores,
            "passed": passed,
        }
        attempts.append(attempt)
        atomic_json(attempt_dir / "gate.json", attempt)
        if passed:
            selected = {
                "schema": "harness-distill.selected-model.v1",
                "campaign_sha256": campaign.digest,
                "role": role,
                "model": model,
                "snapshot": str(snapshot),
                "attempts": attempts,
            }
            atomic_json(output / "selected_model.json", selected)
            return selected
    raise RuntimeError("neither preregistered Qwen checkpoint passed the headroom gate")


def _bootstrap_difference(
    base: list[dict[str, Any]],
    trained: list[dict[str, Any]],
    *,
    seed: int = 5603,
    draws: int = 10000,
) -> dict[str, float]:
    if len(base) != len(trained) or not base:
        raise ValueError("paired bootstrap needs equal non-empty arms")
    if all("run" in row for row in [*base, *trained]):
        base_by_run = {str(row["run"]): row for row in base}
        trained_by_run = {str(row["run"]): row for row in trained}
        if len(base_by_run) != len(base) or len(trained_by_run) != len(trained):
            raise ValueError("paired bootstrap run identities must be unique")
        if set(base_by_run) != set(trained_by_run):
            raise ValueError("paired bootstrap arms contain different run identities")
        ordered = sorted(base_by_run)
        base = [base_by_run[key] for key in ordered]
        trained = [trained_by_run[key] for key in ordered]
    rng = random.Random(seed)
    differences = []
    size = len(base)
    for _ in range(draws):
        indices = [rng.randrange(size) for _ in range(size)]
        differences.append(
            sum(
                float(trained[index]["optimal"]) - float(base[index]["optimal"])
                for index in indices
            )
            / size
        )
    differences.sort()
    return {
        "mean": sum(differences) / len(differences),
        "lower_95": differences[math.floor(0.025 * draws)],
        "upper_95": differences[min(draws - 1, math.floor(0.975 * draws))],
    }


def _summarize_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    if not records:
        raise ValueError("cannot summarize an empty evaluation subset")
    pstar = [
        float(record["preservation_strict"])
        for record in records
        if record.get("preservation_strict") is not None
    ]
    return {
        "n": len(records),
        "optimal_product_rate": sum(record["optimal"] for record in records) / len(records),
        "valid_purchase_rate": sum(record["valid_purchase"] for record in records) / len(records),
        "mean_preservation_strict": sum(pstar) / len(pstar) if pstar else None,
        "binding_backstop_runs": sum(record["backstop_bound"] for record in records),
    }


def _paired_task_stratified_bootstrap(
    base: list[dict[str, Any]],
    trained: list[dict[str, Any]],
    *,
    seed: int = 5603,
    draws: int = 10_000,
) -> dict[str, float]:
    """Paired cluster bootstrap over tasks, stratified by scenario.

    A task is one scenario/variant/condition triple. Its three repetitions stay
    together, preserving within-task dependence, while variants are resampled
    with replacement inside each scenario so no product category dominates.
    """

    base_by_run = {str(row["run"]): row for row in base}
    trained_by_run = {str(row["run"]): row for row in trained}
    if not base_by_run or set(base_by_run) != set(trained_by_run):
        raise ValueError("task-stratified bootstrap requires identical non-empty run IDs")
    task_differences: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    for run in sorted(base_by_run):
        left = base_by_run[run]
        right = trained_by_run[run]
        key = (str(left["scenario"]), str(left["variant"]), str(left["condition"]))
        if key != (
            str(right["scenario"]),
            str(right["variant"]),
            str(right["condition"]),
        ):
            raise ValueError(f"paired run metadata differs across arms: {run}")
        task_differences[key].append(float(right["optimal"]) - float(left["optimal"]))
    by_scenario: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    for key in sorted(task_differences):
        by_scenario[key[0]].append(key)
    rng = random.Random(seed)
    samples: list[float] = []
    for _ in range(draws):
        values: list[float] = []
        for scenario in sorted(by_scenario):
            tasks = by_scenario[scenario]
            for _task in tasks:
                sampled = tasks[rng.randrange(len(tasks))]
                values.extend(task_differences[sampled])
        samples.append(sum(values) / len(values))
    samples.sort()
    return {
        "mean": sum(samples) / len(samples),
        "lower_95": samples[math.floor(0.025 * draws)],
        "upper_95": samples[min(draws - 1, math.floor(0.975 * draws))],
    }


def run_final_evaluation(
    campaign: Campaign,
    output_dir: str | Path,
    *,
    base_model_path: str | Path,
    trained_model_path: str | Path,
    served_model_name: str,
) -> dict[str, Any]:
    output = Path(output_dir).resolve()
    evaluation = campaign.evaluation
    scenarios = list(evaluation["scenarios"])
    specs = amazon_specs(
        scenarios,
        list(evaluation["variants"]),
        list(evaluation["conditions"]),
        repetitions=int(evaluation["repetitions"]),
    )
    if len(specs) != 120:
        raise AssertionError(f"expected 120 runs per arm, got {len(specs)}")

    scores: dict[str, dict[str, Any]] = {}
    for arm, model_path, port, base_port in (
        ("base", base_model_path, 8000, 21000),
        ("trained", trained_model_path, 8001, 22000),
    ):
        arm_dir = output / "eval" / "full" / arm
        model_identity = checkpoint_tree_identity(
            model_path,
            served_model=served_model_name,
            model_id=served_model_name,
        )
        with VllmServer(
            model_path=model_path,
            served_model_name=served_model_name,
            output_dir=arm_dir / "server",
            port=port,
        ) as server:
            collection = collect_rollouts(
                specs,
                output_dir=arm_dir / "runs",
                upstream_base_url=server.base_url,
                wire_model=served_model_name,
                model_label=f"{served_model_name}-{arm}",
                model_identity=model_identity,
                run_timeout_seconds=int(evaluation["safety_backstops"]["run_timeout_seconds"]),
                jobs=24,
                base_port=base_port,
                max_steps=int(evaluation["safety_backstops"]["max_steps"]),
                spawn_stagger_seconds=1.0,
            )
        score = score_amazon_runs(arm_dir / "runs", scenarios)
        score["collection"] = collection
        scores[arm] = score
        atomic_json(arm_dir / "scores.json", score)
        if (
            collection["completed"] != len(specs)
            or collection["failed_run_ids"]
            or score["run_count"] != len(specs)
        ):
            raise RuntimeError(
                f"{arm} evaluation is incomplete; rerun the resumable phase before comparison"
            )

    base_runs = list(scores["base"]["runs"])
    trained_runs = list(scores["trained"]["runs"])
    base_ids = {str(record["run"]) for record in base_runs}
    trained_ids = {str(record["run"]) for record in trained_runs}
    if len(base_ids) != len(specs) or base_ids != trained_ids:
        raise RuntimeError("evaluation arms do not contain the same unique run identities")

    held_out = set(evaluation["held_out_confirmatory_scenarios"])
    development = set(evaluation["development_exposed_scenarios"])
    confirmatory_base = [
        record
        for record in base_runs
        if record["scenario"] in held_out and record["condition"] == "combined"
    ]
    confirmatory_trained = [
        record
        for record in trained_runs
        if record["scenario"] in held_out and record["condition"] == "combined"
    ]
    development_base = [
        record
        for record in base_runs
        if record["scenario"] in development and record["condition"] == "combined"
    ]
    development_trained = [
        record
        for record in trained_runs
        if record["scenario"] in development and record["condition"] == "combined"
    ]
    confirmatory_bootstrap = _paired_task_stratified_bootstrap(
        confirmatory_base, confirmatory_trained
    )
    clean_base = scores["base"]["by_condition"]["clean"]
    clean_trained = scores["trained"]["by_condition"]["clean"]
    confirmatory = {
        "scenarios": sorted(held_out),
        "base": _summarize_records(confirmatory_base),
        "trained": _summarize_records(confirmatory_trained),
        "paired_task_stratified_bootstrap_difference": confirmatory_bootstrap,
    }
    development_result = {
        "scenarios": sorted(development),
        "base": _summarize_records(development_base),
        "trained": _summarize_records(development_trained),
    }
    criteria = evaluation["success_criteria"]
    result = {
        "schema": "harness-distill.final-evaluation.v1",
        "expected_runs": 240,
        "observed_runs": scores["base"]["run_count"] + scores["trained"]["run_count"],
        "base": scores["base"],
        "trained": scores["trained"],
        "confirmatory": confirmatory,
        "development_exposed": development_result,
        "success": (
            confirmatory["trained"]["optimal_product_rate"]
            - confirmatory["base"]["optimal_product_rate"]
            >= criteria["minimum_combined_absolute_improvement"]
            and confirmatory_bootstrap["lower_95"] > criteria["bootstrap_lower_bound_must_exceed"]
            and clean_trained["optimal_product_rate"]
            >= clean_base["optimal_product_rate"]
            - criteria["maximum_clean_optimal_product_regression"]
            and clean_trained["valid_purchase_rate"]
            >= clean_base["valid_purchase_rate"]
            - criteria["maximum_clean_valid_purchase_regression"]
            and scores["base"]["binding_backstop_runs"] == 0
            and scores["trained"]["binding_backstop_runs"] == 0
        ),
    }
    atomic_json(output / "eval" / "full" / "comparison.json", result)
    return result
