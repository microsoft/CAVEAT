"""Opt-in AgentArena adapter for the procedural SSR training storefront.

Importing :mod:`harness_distill` alone has no registration side effects.  This
module registers ``harness-distill-training`` only when it is explicitly
imported and AgentArena is installed.
"""

from __future__ import annotations

import secrets
from pathlib import Path
from typing import Any

from .schemas import TrainingTaskSpec
from .storefront import OPS_TOKEN_ENV, read_state_file, write_state_file

ENVIRONMENT_NAME = "harness-distill-training"
SERVER_MODULE = "harness_distill.storefront"
_SOURCE_ROOT = Path(__file__).resolve().parents[1]

try:
    from agentarena.core.environment import (
        ENVIRONMENTS,
        Environment,
        ServerHandle,
        http_get_json,
    )
    from agentarena.core.task import TaskSpec
    from agentarena.core.trajectory import Evaluation
except ImportError:  # pragma: no cover - exercised in a standalone installation
    ENVIRONMENTS = None
    Environment = object  # type: ignore[assignment,misc]
    ServerHandle = Any  # type: ignore[assignment,misc]
    TaskSpec = Any  # type: ignore[assignment,misc]
    Evaluation = Any  # type: ignore[assignment,misc]
    http_get_json = None


def _task_from_params(
    catalog: str | None,
    condition: str,
    params: dict[str, Any],
) -> TrainingTaskSpec:
    raw = params.get("training_task")
    path = params.get("training_task_path")
    if raw is not None and path is not None:
        raise ValueError("specify training_task or training_task_path, not both")
    if raw is not None:
        if isinstance(raw, TrainingTaskSpec):
            task = raw
        elif isinstance(raw, dict):
            task = TrainingTaskSpec.from_dict(raw)
        elif isinstance(raw, str):
            task = TrainingTaskSpec.from_json(raw)
        else:
            raise TypeError("training_task must be a TrainingTaskSpec, mapping, or JSON string")
    elif path is not None:
        task = TrainingTaskSpec.from_json(Path(path).read_text(encoding="utf-8"))
    else:
        raise ValueError("task params must contain training_task or training_task_path")

    if catalog is not None and catalog != task.task_id:
        raise ValueError(f"catalog {catalog!r} does not match training task {task.task_id!r}")
    if condition != task.condition:
        raise ValueError(f"condition {condition!r} does not match training task {task.condition!r}")
    return task


def to_agentarena_task(task: TrainingTaskSpec) -> Any:
    """Wrap a procedural task without exposing its structured oracle to the agent."""

    if ENVIRONMENTS is None:
        raise RuntimeError("AgentArena is not installed")
    return TaskSpec(
        task_id=task.task_id,
        env=ENVIRONMENT_NAME,
        instruction=task.instruction,
        preferences={},
        catalog=task.task_id,
        condition=task.condition,
        start_path="/",
        params={"training_task": task.to_dict()},
        metadata={
            "procedural_split": task.split,
            "domain_family": task.domain_family,
            "task_mode": task.mode,
        },
    )


class HarnessDistillTrainingEnvironment(Environment):  # type: ignore[misc]
    """AgentArena lifecycle adapter backed by a per-run procedural state file."""

    name = ENVIRONMENT_NAME
    server_dir = _SOURCE_ROOT
    server_module = SERVER_MODULE
    health_path = "/api/health"
    default_start_path = "/"
    catalogs: dict[str, Any] = {}

    def __init__(self) -> None:
        if ENVIRONMENTS is None:
            raise RuntimeError("AgentArena is required for HarnessDistillTrainingEnvironment")
        self._ops_token = secrets.token_hex(32)
        self._pre_orders: dict[str, set[str]] = {}

    def server_command(self, port: int, db_path: Path) -> list[str]:
        return [
            "-m",
            SERVER_MODULE,
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--state",
            str(Path(db_path).resolve()),
        ]

    def server_env(
        self,
        catalog: str | None,
        condition: str,
        params: dict[str, Any],
    ) -> dict[str, str]:
        # The operations credential is process environment only.  It is never a
        # CLI flag, cookie, HTML meta value, or agent-facing request header.
        return {OPS_TOKEN_ENV: self._ops_token}

    def seed_db(
        self,
        db_path: Path,
        *,
        catalog: str | None,
        condition: str,
        params: dict[str, Any],
    ) -> None:
        task = _task_from_params(catalog, condition, params)
        write_state_file(db_path, task)

    def _ops_headers(self, handle: Any) -> dict[str, str]:
        token = (getattr(handle, "env", None) or {}).get(OPS_TOKEN_ENV) or self._ops_token
        return {"X-Storefront-Ops": token}

    def _orders(self, handle: Any) -> list[dict[str, Any]]:
        if http_get_json is None:  # pragma: no cover - guarded by __init__
            raise RuntimeError("AgentArena is not installed")
        response = http_get_json(
            f"{handle.base_url}/api/orders",
            headers=self._ops_headers(handle),
        )
        orders = response.get("orders", [])
        if not isinstance(orders, list):
            raise RuntimeError("training storefront returned a malformed order ledger")
        return orders

    def after_start(self, handle: Any, task: Any) -> None:
        self._pre_orders[str(handle.db_path)] = {
            str(order.get("id")) for order in self._orders(handle) if order.get("id") is not None
        }

    def evaluate(self, handle: Any, task: Any) -> Any:
        # Deliberately reload evaluator truth from the local state file.  TaskSpec
        # preferences/metadata and every server response are insufficient to infer it.
        private_state = read_state_file(handle.db_path)["evaluator"]
        mode = str(private_state["mode"])
        oracle = private_state["oracle"]
        accepted = {str(item_id) for item_id in oracle.get("accepted_item_ids", [])}
        optimum = oracle.get("optimal_item_id")

        before = self._pre_orders.get(str(handle.db_path), set())
        orders = [order for order in self._orders(handle) if str(order.get("id")) not in before]
        if not orders:
            abstention_success = mode == "no_qualified"
            return Evaluation(
                outcome="abstained" if abstention_success else "none",
                success=abstention_success,
                details={
                    "completed": False,
                    "abstained": True,
                    "task_mode": mode,
                    "optimal_selected": False,
                },
            )

        lines = [line for order in orders for line in order.get("items", [])]
        chosen = str(lines[-1].get("item_id")) if lines else None
        chosen_label = str(lines[-1].get("title")) if lines else None
        quantity = int(lines[-1].get("quantity", 0)) if lines else 0
        valid_basket = len(lines) == 1 and quantity == 1
        accepted_choice = bool(valid_basket and chosen in accepted)
        optimal_selected = bool(valid_basket and optimum is not None and chosen == str(optimum))

        if not valid_basket:
            outcome = "invalid_basket"
        elif optimal_selected:
            outcome = "optimal"
        elif accepted_choice:
            outcome = "accepted"
        else:
            outcome = "suboptimal"
        return Evaluation(
            outcome=outcome,
            chosen=chosen,
            chosen_label=chosen_label,
            success=accepted_choice,
            details={
                "completed": True,
                "task_mode": mode,
                "accepted": accepted_choice,
                "optimal_selected": optimal_selected,
                "basket_item_count": len(lines),
                "quantity": quantity,
                "all_in_total": round(sum(float(order.get("total", 0.0)) for order in orders), 2),
            },
        )


# Registration is intentionally here, not in harness_distill.__init__.  An
# experiment must opt in with ``import harness_distill.training_env``.
if ENVIRONMENTS is not None and ENVIRONMENT_NAME not in ENVIRONMENTS:
    ENVIRONMENTS.register(ENVIRONMENT_NAME)(HarnessDistillTrainingEnvironment)
