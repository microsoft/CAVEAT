"""End-to-end, resumable orchestration for harness-distillation training.

This module is intentionally the only layer which joins browser rollouts,
public-evidence phase sidecars, frozen-teacher labels, PRIME training, cumulative
checkpoint merging, and procedural validation.  The lower-level modules remain
independently auditable.  Every stochastic boundary publishes immutable output
before a completion manifest; incompatible partial output fails closed instead
of being silently regenerated.

PRIME-RL 0.7 cannot combine reverse-KL OPD and corrective cross entropy in one
loss.  Consequently each OPD round is followed by a separately recorded,
assistant-only corrective/rehearsal SFT pass.  It is an alternating
approximation, not a claim of simultaneous ``OPD + 0.5 CE``.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import shutil
import statistics
import tempfile
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .config import Campaign, atomic_json
from .evaluation import _limit_bound
from .materialize import (
    canonical_json,
    materialize_decision_replays,
    read_jsonl,
    write_jsonl,
)
from .phase_sidecars import OpenAIPhaseExtractor, build_phase_sidecar_file
from .rollouts import MODEL_IDENTITY_SCHEMA, collect_rollouts, procedural_specs
from .schemas import TrainingTaskSpec, read_tasks_jsonl
from .serving import VllmServer
from .sft_data import build_sft_jsonl
from .teacher_labels import (
    FrozenTeacherConfig,
    label_materialized_replays,
)

SEQUENCE_LENGTH = 65_536
ROLLOUT_BATCH_SIZE = 256
ROLLOUT_JOBS = 32
VALIDATION_JOBS = 32
PHASE_SCHEMA = "harness-distill.training-phase.v1"
SELECTION_SCHEMA = "harness-distill.checkpoint-selection.v1"
MERGE_SCHEMA = "harness-distill.cumulative-merge.v1"


class CampaignPhaseError(RuntimeError):
    """A campaign phase would violate an audited or resumability invariant."""


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _tree_manifest(root: Path, *, ignored: frozenset[str] = frozenset()) -> dict[str, Any]:
    if not root.is_dir():
        raise CampaignPhaseError(f"checkpoint directory does not exist: {root}")
    files: dict[str, Any] = {}
    for path in sorted(candidate for candidate in root.rglob("*") if candidate.is_file()):
        relative = path.relative_to(root).as_posix()
        if relative in ignored:
            continue
        files[relative] = {"bytes": path.stat().st_size, "sha256": _sha256_file(path)}
    if not files:
        raise CampaignPhaseError(f"checkpoint has no files: {root}")
    return {"files": files, "digest": _sha256_json(files)}


def _rollout_model_identity(
    checkpoint: Path,
    *,
    served_model: str,
    tree: Mapping[str, Any] | None = None,
    revision: str | None = None,
) -> dict[str, Any]:
    audited = dict(tree) if tree is not None else _tree_manifest(checkpoint)
    files = audited.get("files")
    digest = audited.get("digest")
    if not isinstance(files, Mapping) or not isinstance(digest, str):
        raise CampaignPhaseError("checkpoint tree manifest is malformed")
    return {
        "schema": MODEL_IDENTITY_SCHEMA,
        "checkpoint_path": str(checkpoint.resolve()),
        "served_model": served_model,
        "model_id": served_model,
        "revision": revision,
        "tree_sha256": digest,
        "file_count": len(files),
        "total_bytes": sum(int(item["bytes"]) for item in files.values()),
    }


def _load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise CampaignPhaseError(f"required artifact is missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CampaignPhaseError(f"cannot read JSON artifact {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise CampaignPhaseError(f"JSON artifact is not an object: {path}")
    return value


def _publish_plan(path: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    frozen = json.loads(canonical_json(dict(payload)))
    if path.is_file():
        existing = _load_json(path)
        if canonical_json(existing) != canonical_json(frozen):
            raise CampaignPhaseError(f"existing deterministic plan drifted: {path}")
        return existing
    atomic_json(path, frozen)
    return frozen


def _selected_state(campaign: Campaign, output: Path) -> dict[str, Any]:
    selected = _load_json(output / "selected_model.json")
    if selected.get("schema") != "harness-distill.selected-model.v1":
        raise CampaignPhaseError("selected-model artifact has an unsupported schema")
    if selected.get("campaign_sha256") != campaign.digest:
        raise CampaignPhaseError("selected-model artifact belongs to a different campaign")
    role = selected.get("role")
    if role not in {"primary", "fallback"}:
        raise CampaignPhaseError("selected-model role is invalid")
    configured = campaign.model(str(role))
    if selected.get("model") != configured:
        raise CampaignPhaseError("selected-model identity differs from frozen configuration")
    snapshot = Path(str(selected.get("snapshot", ""))).resolve()
    if not snapshot.is_dir() or snapshot.name != configured["revision"]:
        raise CampaignPhaseError("selected model is not the exact pinned local snapshot")
    smoke_report = output / "smoke" / str(role) / "smoke_report.json"
    smoke = _load_json(smoke_report)
    smoke_snapshot = Path(str(smoke.get("resolved_snapshot", ""))).resolve()
    smoke_identity = smoke.get("snapshot")
    if (
        smoke.get("status") != "ok"
        or not isinstance(smoke_identity, Mapping)
        or smoke_identity.get("role") != role
        or smoke_identity.get("model_id") != configured["model_id"]
        or smoke_identity.get("revision") != configured["revision"]
        or not smoke_snapshot.is_dir()
        or smoke_snapshot.name != configured["revision"]
    ):
        raise CampaignPhaseError("full-model smoke report does not attest the selected snapshot")
    snapshot_tree = _tree_manifest(snapshot)
    if _tree_manifest(smoke_snapshot) != snapshot_tree:
        raise CampaignPhaseError(
            "full-model smoke report attests different checkpoint content from selection"
        )
    return {
        "role": str(role),
        "model": configured,
        "snapshot": snapshot,
        "snapshot_tree": snapshot_tree,
        "smoke_report": smoke_report,
    }


def _tasks(campaign: Campaign, output: Path, split: str) -> tuple[TrainingTaskSpec, ...]:
    manifest = _load_json(output / "data" / "procedural" / "manifest.json")
    if manifest.get("campaign_sha256") != campaign.digest:
        raise CampaignPhaseError("procedural data belongs to a different campaign")
    record = manifest.get("splits", {}).get(split)
    if not isinstance(record, Mapping):
        raise CampaignPhaseError(f"procedural manifest has no {split!r} split")
    path = Path(str(record.get("path", ""))).resolve()
    if not path.is_file() or _sha256_file(path) != record.get("sha256"):
        raise CampaignPhaseError(f"procedural split hash mismatch: {split}")
    loaded = read_tasks_jsonl(path)
    if len(loaded) != record.get("count"):
        raise CampaignPhaseError(f"procedural split count mismatch: {split}")
    return loaded


def _ordered(tasks: Iterable[TrainingTaskSpec], namespace: str) -> list[TrainingTaskSpec]:
    return sorted(
        tasks,
        key=lambda task: hashlib.sha256(f"{namespace}:{task.task_id}".encode()).hexdigest(),
    )


def _run_dir(batch_dir: Path, task: TrainingTaskSpec) -> Path:
    run_id = f"{task.task_id}-r1"
    return batch_dir / run_id.replace("/", "-").replace(" ", "-")


def _task_id_from_run_dir(path: str | Path) -> str:
    name = Path(path).name
    if not name.endswith("-r1"):
        raise CampaignPhaseError(f"unexpected one-repetition run directory: {name}")
    return name[:-3]


def _assert_unbound(run_dir: Path) -> None:
    trajectory = _load_json(run_dir / "trajectory.json")
    if _limit_bound(trajectory.get("stats") or {}):
        raise CampaignPhaseError(f"safety backstop or incomplete limit audit bound {run_dir.name}")


def _successful(run_dir: Path) -> bool:
    summary = _load_json(run_dir / "summary.json")
    _assert_unbound(run_dir)
    return summary.get("success") is True and summary.get("outcome") in {
        "optimal",
        "accepted",
        "abstained",
    }


def _collect_to_quota(
    tasks: Sequence[TrainingTaskSpec],
    *,
    quota: int,
    output_dir: Path,
    upstream_base_url: str,
    wire_model: str,
    model_label: str,
    model_identity: Mapping[str, Any],
    run_timeout_seconds: int,
    base_port: int,
    maximum_attempts: int | None,
) -> tuple[list[Path], list[Path], dict[str, Any]]:
    """Collect deterministic batches and stop only between complete batches."""

    candidates = list(tasks[:maximum_attempts] if maximum_attempts is not None else tasks)
    plan = {
        "schema": "harness-distill.rollout-quota-plan.v1",
        "quota": quota,
        "maximum_attempts": maximum_attempts,
        "candidate_task_ids": [task.task_id for task in candidates],
        "batch_size": ROLLOUT_BATCH_SIZE,
    }
    plan["candidate_sha256"] = _sha256_json(plan["candidate_task_ids"])
    _publish_plan(output_dir / "plan.json", plan)

    successes: list[Path] = []
    attempted: list[Path] = []
    usable: list[Path] = []
    unusable: list[dict[str, str]] = []
    batches = 0
    for start in range(0, len(candidates), ROLLOUT_BATCH_SIZE):
        batch_tasks = candidates[start : start + ROLLOUT_BATCH_SIZE]
        batch_dir = output_dir / "batches" / f"batch-{start // ROLLOUT_BATCH_SIZE:03d}"
        batch_result_path = batch_dir / "quota_batch_result.json"
        expected_ids = [task.task_id for task in batch_tasks]
        if batch_result_path.is_file():
            frozen_batch = _load_json(batch_result_path)
            if frozen_batch.get("task_ids") != expected_ids:
                raise CampaignPhaseError(f"rollout batch plan drifted: {batch_dir}")
            collection = frozen_batch["collection"]
        else:
            collection = collect_rollouts(
                procedural_specs(batch_tasks),
                output_dir=batch_dir,
                upstream_base_url=upstream_base_url,
                wire_model=wire_model,
                model_label=model_label,
                model_identity=model_identity,
                run_timeout_seconds=run_timeout_seconds,
                jobs=min(ROLLOUT_JOBS, len(batch_tasks)),
                base_port=base_port,
                max_steps=4000,
                scaffold="browseruse",
                spawn_stagger_seconds=0.25,
            )
            atomic_json(
                batch_result_path,
                {
                    "schema": "harness-distill.rollout-quota-batch.v1",
                    "task_ids": expected_ids,
                    "collection": collection,
                },
            )
        failed_ids = set(collection.get("failed_run_ids", []))
        batches += 1
        for task in batch_tasks:
            path = _run_dir(batch_dir, task)
            attempted.append(path)
            if f"{task.task_id}-r1" in failed_ids or not (path / "summary.json").is_file():
                unusable.append({"task_id": task.task_id, "reason": "incomplete_or_error"})
                continue
            try:
                success = _successful(path)
            except CampaignPhaseError:
                unusable.append({"task_id": task.task_id, "reason": "backstop_or_audit"})
                continue
            usable.append(path)
            if success:
                successes.append(path)
        if len(successes) >= quota:
            break
    if len(successes) < quota:
        raise CampaignPhaseError(
            f"only {len(successes)} successful trajectories after {len(attempted)} attempts; "
            f"required {quota}"
        )
    selected = successes[:quota]
    result = {
        "schema": "harness-distill.rollout-quota-result.v1",
        "quota": quota,
        "attempted": len(attempted),
        "successful": len(successes),
        "selected": len(selected),
        "unusable": len(unusable),
        "unusable_attempts": unusable,
        "batches": batches,
        "attempted_run_dirs": [str(path) for path in attempted],
        "usable_run_dirs": [str(path) for path in usable],
        "selected_run_dirs": [str(path) for path in selected],
    }
    result["result_sha256"] = _sha256_json(result)
    _publish_plan(output_dir / "result.json", result)
    return selected, usable, result


def _atomic_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    count = write_jsonl(temporary, rows)
    temporary.replace(path)
    return count


def _aggregate_proxy_records(run_dirs: Sequence[Path], destination: Path) -> list[dict[str, Any]]:
    sources = []
    records: list[dict[str, Any]] = []
    for run_dir in run_dirs:
        trace = run_dir / "model_requests.jsonl"
        if not trace.is_file() or trace.stat().st_size == 0:
            raise CampaignPhaseError(f"completed rollout has no proxy trace: {run_dir}")
        sources.append({"path": str(trace), "sha256": _sha256_file(trace)})
        records.extend(read_jsonl(trace))
    identity = {"sources": sources, "record_count": len(records)}
    identity["sources_sha256"] = _sha256_json(sources)
    identity_path = destination.with_suffix(".sources.json")
    if destination.is_file() or identity_path.is_file():
        if not destination.is_file() or not identity_path.is_file():
            raise CampaignPhaseError("partial aggregate proxy artifact exists")
        if _load_json(identity_path) != identity:
            raise CampaignPhaseError("aggregate proxy sources drifted")
        existing = read_jsonl(destination)
        if canonical_json(existing) != canonical_json(records):
            raise CampaignPhaseError("aggregate proxy bytes no longer match source traces")
        return existing
    _atomic_jsonl(destination, records)
    atomic_json(identity_path, identity)
    return records


def _bounded_label_count(rows: Sequence[Mapping[str, Any]], per_session: int) -> int:
    counts: dict[str, int] = {}
    for row in rows:
        session = row.get("session_sha256")
        if not isinstance(session, str):
            raise CampaignPhaseError("decision replay has no session identity")
        counts[session] = counts.get(session, 0) + 1
    return sum(min(per_session, count) for count in counts.values())


def _recoverable_teacher_publish(
    replays: Sequence[Mapping[str, Any]],
    teacher: FrozenTeacherConfig,
    *,
    labels_path: Path,
    audits_path: Path,
    checkpoint_dir: Path,
    expected_labels: int,
    max_attempts: int,
) -> dict[str, Any]:
    """Reload per-item journals and publish the two projections recoverably.

    There is no filesystem primitive that atomically renames two files.  The
    authoritative per-item checkpoints therefore act as the transaction log:
    after a crash between projections, completed labels are reloaded without a
    new teacher sample and both canonical files are emitted again.
    """

    batch = asyncio.run(
        label_materialized_replays(
            replays,
            teacher,
            checkpoint_dir=checkpoint_dir,
            max_attempts=max_attempts,
        )
    )
    if len(batch.labels) != expected_labels or len(batch.call_audits) != expected_labels:
        raise CampaignPhaseError("frozen teacher returned an incomplete corrective batch")
    expected_label_rows = list(batch.labels)
    expected_audit_rows = list(batch.call_audits)
    had_projection = labels_path.exists() or audits_path.exists()
    for name, path, expected in (
        ("labels", labels_path, expected_label_rows),
        ("teacher_calls", audits_path, expected_audit_rows),
    ):
        if path.exists() and canonical_json(read_jsonl(path)) != canonical_json(expected):
            raise CampaignPhaseError(
                f"partial teacher projection differs from checkpoint journal: {name}"
            )
    # Re-emit both even when one was already present.  A repeated crash is safe:
    # each file replacement is atomic and the item journals remain authoritative.
    _atomic_jsonl(labels_path, expected_label_rows)
    _atomic_jsonl(audits_path, expected_audit_rows)
    return {
        "labels": len(batch.labels),
        "skipped_by_session_bound": batch.skipped_by_session_bound,
        "skipped_by_total_bound": batch.skipped_by_total_bound,
        "total_attempts": batch.total_attempts,
        "retried_labels": batch.retried_labels,
        "resumed_labels": batch.resumed_labels,
        "max_attempts": batch.max_attempts,
        "resumed": batch.resumed_labels > 0 or had_projection,
    }


def _build_supervision(
    run_dirs: Sequence[Path],
    *,
    output_dir: Path,
    teacher_base_url: str,
    model: Mapping[str, Any],
    split: str = "train",
    decision_limit_per_session: int | None = None,
) -> dict[str, Any]:
    """Build public sidecars, exact replays, and bounded corrective labels."""

    manifest_path = output_dir / "manifest.json"
    aggregate_path = output_dir / "proxy.all.jsonl"
    proxy_path = output_dir / "proxy.jsonl"
    sidecar_path = output_dir / "sidecars.jsonl"
    replay_path = output_dir / "replays.jsonl"
    labels_path = output_dir / "corrective.jsonl"
    audits_path = output_dir / "teacher_calls.jsonl"
    sidecar_checkpoint_dir = output_dir / "sidecar_checkpoints"
    teacher_checkpoint_dir = output_dir / "teacher_checkpoints"
    retry_attempts = 3
    all_proxy_records = _aggregate_proxy_records(run_dirs, aggregate_path)
    if decision_limit_per_session is not None and decision_limit_per_session < 1:
        raise CampaignPhaseError("decision_limit_per_session must be positive")
    session_counts: dict[str, int] = {}
    proxy_records: list[dict[str, Any]] = []
    excluded = 0
    for record in all_proxy_records:
        if record.get("role", "student") != "student" or record.get("status_code") not in range(
            200, 300
        ):
            excluded += 1
            continue
        session = record.get("session_sha256")
        if not isinstance(session, str):
            raise CampaignPhaseError("successful proxy record lacks a session identity")
        count = session_counts.get(session, 0)
        if decision_limit_per_session is not None and count >= decision_limit_per_session:
            excluded += 1
            continue
        proxy_records.append(record)
        session_counts[session] = count + 1
    if not proxy_records:
        raise CampaignPhaseError("no successful student decisions are eligible for supervision")
    if proxy_path.is_file():
        if canonical_json(read_jsonl(proxy_path)) != canonical_json(proxy_records):
            raise CampaignPhaseError("supervision decision preselection drifted")
    else:
        _atomic_jsonl(proxy_path, proxy_records)
    inputs = {
        "aggregate_proxy_sha256": _sha256_file(aggregate_path),
        "proxy_sha256": _sha256_file(proxy_path),
        "aggregate_decisions": len(all_proxy_records),
        "selected_decisions": len(proxy_records),
        "excluded_decisions": excluded,
        "decision_limit_per_session": decision_limit_per_session,
        "model_id": model["model_id"],
        "revision": model["revision"],
        "split": split,
        "maximum_labels_per_session": 4,
        "retry_policy": {
            "maximum_attempts_per_item": retry_attempts,
            "selection": "first_valid_no_outcome",
            "attempt_charged_before_call": True,
        },
    }
    if manifest_path.is_file():
        manifest = _load_json(manifest_path)
        if manifest.get("inputs") != inputs:
            raise CampaignPhaseError("supervision inputs differ from completed manifest")
        for name, path in {
            "sidecars": sidecar_path,
            "replays": replay_path,
            "labels": labels_path,
            "teacher_calls": audits_path,
        }.items():
            expected = manifest.get("artifacts", {}).get(name, {}).get("sha256")
            if not path.is_file() or _sha256_file(path) != expected:
                raise CampaignPhaseError(f"completed supervision artifact drifted: {name}")
        return manifest

    extractor = OpenAIPhaseExtractor(
        base_url=teacher_base_url,
        model=str(model["model_id"]),
        model_revision=str(model["revision"]),
    )
    if not sidecar_path.exists():
        sidecar_report = build_phase_sidecar_file(
            proxy_path,
            sidecar_path,
            extractor,
            split=split,
            max_workers=32,
            checkpoint_dir=sidecar_checkpoint_dir,
            max_attempts=retry_attempts,
        ).to_dict()
    else:
        sidecar_report = {
            "input_records": len(proxy_records),
            "successful_decisions": len(read_jsonl(sidecar_path)),
            "skipped_records": len(proxy_records) - len(read_jsonl(sidecar_path)),
            "output_sha256": _sha256_file(sidecar_path),
            "resumed": True,
        }

    sidecars = read_jsonl(sidecar_path)
    replays = materialize_decision_replays(proxy_records, sidecars)
    if not replays:
        raise CampaignPhaseError("supervision produced no decision replays")
    if replay_path.exists():
        if canonical_json(read_jsonl(replay_path)) != canonical_json(replays):
            raise CampaignPhaseError(
                "existing replay rows differ from deterministic materialization"
            )
    else:
        _atomic_jsonl(replay_path, replays)

    expected_labels = _bounded_label_count(replays, 4)
    teacher = FrozenTeacherConfig(
        base_url=teacher_base_url,
        served_model_name=str(model["model_id"]),
        model_id=str(model["model_id"]),
        revision=str(model["revision"]),
        concurrency=32,
        maximum_labels_per_session=4,
    )
    # A supervision manifest is the only completion marker (handled above).
    # Until it exists, even two present projections are revalidated against the
    # authoritative per-item journals rather than trusted by row count alone.
    label_result = _recoverable_teacher_publish(
        replays,
        teacher,
        labels_path=labels_path,
        audits_path=audits_path,
        checkpoint_dir=teacher_checkpoint_dir,
        expected_labels=expected_labels,
        max_attempts=retry_attempts,
    )

    artifacts = {
        name: {"path": str(path), "sha256": _sha256_file(path), "rows": len(read_jsonl(path))}
        for name, path in {
            "sidecars": sidecar_path,
            "replays": replay_path,
            "labels": labels_path,
            "teacher_calls": audits_path,
        }.items()
    }
    manifest = {
        "schema": "harness-distill.supervision-batch.v1",
        "inputs": inputs,
        "sidecar_report": sidecar_report,
        "label_result": label_result,
        "artifacts": artifacts,
        "teacher_receives_evaluator_truth": False,
        "teacher_receives_private_storefront_data": False,
        "decision_preselection": {
            "outcome_blind": True,
            "causal_first_per_session": decision_limit_per_session,
            "selected": len(proxy_records),
            "excluded": excluded,
        },
    }
    atomic_json(manifest_path, manifest)
    return manifest


def _verify_and_merge_stage(
    base_checkpoint: str | Path,
    adapter_path: str | Path,
    output_dir: str | Path,
    *,
    stage: str,
    device: str = "cuda:0",
) -> dict[str, Any]:
    """Merge a stage-local LoRA into its exact parent and verify cumulative logits.

    PRIME initializes each new LoRA at zero on a full student snapshot.  A
    stage adapter is therefore meaningful only relative to that parent, not to
    the campaign's original checkpoint.  This verifier enforces the chain and
    publishes a new complete HF snapshot for the next stage.
    """

    from .model_merge import _collect, _logits, checkpoint_kind
    from .model_smoke import (
        _chat_template_sha256,
        _load_model,
        _load_processor_tokenizer,
        _prompt_tensors,
    )

    base = Path(base_checkpoint).resolve()
    adapter = Path(adapter_path).resolve()
    destination = Path(output_dir).resolve()
    if checkpoint_kind(base) != "merged_hf" and not (base / "config.json").is_file():
        # An HF cache snapshot is a full checkpoint but can store weights behind
        # symlinks; checkpoint_kind still normally recognizes it.  Keep the
        # explicit config guard for fixture-compatible local snapshots.
        raise CampaignPhaseError(f"student parent is not a full HF checkpoint: {base}")
    if checkpoint_kind(adapter) != "peft_adapter":
        raise CampaignPhaseError(f"stage output is not a PEFT adapter: {adapter}")
    adapter_config = _load_json(adapter / "adapter_config.json")
    if adapter_config.get("r") != 64 or float(adapter_config.get("lora_alpha", -1)) != 128.0:
        raise CampaignPhaseError("stage adapter rank/alpha differs from 64/128")
    declared_base = str(adapter_config.get("base_model_name_or_path", ""))
    if declared_base and Path(declared_base).expanduser().resolve() != base:
        raise CampaignPhaseError(
            f"stage adapter declares parent {declared_base!r}, expected {str(base)!r}"
        )

    base_tree = _tree_manifest(base)
    adapter_tree = _tree_manifest(adapter)
    provenance_path = destination / "merge_provenance.json"
    if provenance_path.is_file():
        provenance = _load_json(provenance_path)
        if (
            provenance.get("schema") != MERGE_SCHEMA
            or provenance.get("stage") != stage
            or provenance.get("base", {}).get("digest") != base_tree["digest"]
            or provenance.get("adapter", {}).get("digest") != adapter_tree["digest"]
        ):
            raise CampaignPhaseError(f"completed cumulative merge inputs drifted: {stage}")
        current = _tree_manifest(destination, ignored=frozenset({"merge_provenance.json"}))
        if current["digest"] != provenance.get("merged", {}).get("digest"):
            raise CampaignPhaseError(f"completed cumulative checkpoint drifted: {stage}")
        return provenance
    if destination.exists():
        raise CampaignPhaseError(f"unattested cumulative checkpoint already exists: {destination}")

    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    cuda = device.startswith("cuda")
    try:
        import torch
        from peft import PeftModel

        torch.manual_seed(20260807)
        processor, tokenizer = _load_processor_tokenizer(base)
        template_hash = _chat_template_sha256(tokenizer)
        inputs = _prompt_tensors(tokenizer, device=device)

        base_model = _load_model(base, device=device)
        base_logits = _logits(base_model, inputs)
        architectures = tuple(getattr(base_model.config, "architectures", ()) or ())
        del base_model
        _collect(cuda=cuda)

        parent = _load_model(base, device=device)
        adapted = PeftModel.from_pretrained(parent, adapter, is_trainable=False)
        del parent
        adapted_logits = _logits(adapted, inputs)
        base_delta = float((adapted_logits - base_logits).abs().max().item())
        if not math.isfinite(base_delta) or base_delta <= 1e-7:
            raise CampaignPhaseError(f"{stage} adapter is a numerical no-op")
        merged = adapted.merge_and_unload(safe_merge=True)
        del adapted
        merged_logits = _logits(merged, inputs)
        merge_delta = float((merged_logits - adapted_logits).abs().max().item())
        if not torch.allclose(adapted_logits, merged_logits, atol=5e-2, rtol=5e-3):
            raise CampaignPhaseError(f"{stage} adapter and merged logits differ")
        merged.save_pretrained(staging, safe_serialization=True, max_shard_size="10GB")
        processor.save_pretrained(staging)
        tokenizer.save_pretrained(staging)
        del merged
        _collect(cuda=cuda)

        reload_processor, reload_tokenizer = _load_processor_tokenizer(staging)
        if _chat_template_sha256(reload_tokenizer) != template_hash:
            raise CampaignPhaseError(f"{stage} merge changed the native chat template")
        reload_inputs = _prompt_tensors(reload_tokenizer, device=device)
        if not torch.equal(
            inputs["input_ids"].detach().cpu(), reload_inputs["input_ids"].detach().cpu()
        ):
            raise CampaignPhaseError(f"{stage} merge changed deterministic token IDs")
        reloaded = _load_model(staging, device=device)
        if tuple(getattr(reloaded.config, "architectures", ()) or ()) != architectures:
            raise CampaignPhaseError(f"{stage} merge changed the model architecture")
        reload_logits = _logits(reloaded, reload_inputs)
        reload_delta = float((reload_logits - merged_logits).abs().max().item())
        if not torch.allclose(merged_logits, reload_logits, atol=5e-2, rtol=5e-3):
            raise CampaignPhaseError(f"{stage} saved/reloaded logits differ")
        del reloaded, reload_processor
        _collect(cuda=cuda)

        merged_tree = _tree_manifest(staging)
        provenance = {
            "schema": MERGE_SCHEMA,
            "stage": stage,
            "base": {"path": str(base), "digest": base_tree["digest"]},
            "adapter": {"path": str(adapter), "digest": adapter_tree["digest"]},
            "merged": {
                "path": str(destination),
                "digest": merged_tree["digest"],
                "file_count": len(merged_tree["files"]),
            },
            "logit_verification": {
                "base_adapter_max_abs": base_delta,
                "adapter_merged_max_abs": merge_delta,
                "merged_reload_max_abs": reload_delta,
                "non_noop": True,
                "merge_equivalent": True,
                "reload_equivalent": True,
            },
            "chat_template_sha256": template_hash,
        }
        atomic_json(staging / "merge_provenance.json", provenance)
        staging.replace(destination)
        return provenance
    except BaseException:
        if staging.exists():
            shutil.rmtree(staging)
        raise


def _proxy_call_valid(trace_path: Path) -> bool:
    try:
        rows = read_jsonl(trace_path)
    except Exception:
        return False
    if not rows:
        return False
    for row in rows:
        if row.get("status_code") not in range(200, 300):
            return False
        response = row.get("response")
        choices = response.get("choices") if isinstance(response, Mapping) else None
        if not isinstance(choices, list) or len(choices) != 1:
            return False
        if not isinstance(choices[0], Mapping) or not isinstance(
            choices[0].get("message"), Mapping
        ):
            return False
    return True


def _score_procedural_runs(
    run_root: Path,
    tasks: Sequence[TrainingTaskSpec],
) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    by_id = {task.task_id: task for task in tasks}
    for task in tasks:
        run_dir = _run_dir(run_root, task)
        summary = _load_json(run_dir / "summary.json")
        trajectory = _load_json(run_dir / "trajectory.json")
        if summary.get("task_id") != task.task_id:
            raise CampaignPhaseError(f"validation run/task mismatch: {run_dir}")
        stats = trajectory.get("stats") or {}
        details = (trajectory.get("evaluation") or {}).get("details") or {}
        record = {
            "task_id": task.task_id,
            "mode": task.mode,
            "condition": task.condition,
            "outcome": summary.get("outcome"),
            "success": summary.get("success") is True,
            "optimal": task.mode == "best_available" and summary.get("outcome") == "optimal",
            "steps": int(summary.get("num_steps") or len(trajectory.get("steps", []))),
            "tool_valid": stats.get("error") in {None, ""}
            and _proxy_call_valid(run_dir / "model_requests.jsonl"),
            "backstop_bound": _limit_bound(stats),
            "valid_basket": details.get("basket_item_count") in {None, 1}
            and details.get("quantity") in {None, 1},
        }
        records.append(record)
    if len(records) != len(by_id):
        raise CampaignPhaseError("procedural validation has missing or duplicate task IDs")
    best = [record for record in records if record["mode"] == "best_available"]
    satisfice = [
        record for record in records if record["mode"] == "satisfice" and record["success"]
    ]
    if not best or not satisfice:
        raise CampaignPhaseError(
            "procedural validation lacks best-available or successful satisficing runs"
        )
    result = {
        "schema": "harness-distill.procedural-validation-score.v1",
        "run_count": len(records),
        "best_available_count": len(best),
        "optimal_product_rate": sum(record["optimal"] for record in best) / len(best),
        "all_mode_success_rate": sum(record["success"] for record in records) / len(records),
        "tool_validity_rate": sum(record["tool_valid"] for record in records) / len(records),
        "satisficing_success_count": len(satisfice),
        "satisficing_efficiency_median_steps": float(
            statistics.median(record["steps"] for record in satisfice)
        ),
        "binding_backstop_runs": sum(record["backstop_bound"] for record in records),
        "invalid_basket_runs": sum(not record["valid_basket"] for record in records),
        "records": records,
    }
    return result


def _validate_checkpoint(
    campaign: Campaign,
    tasks: Sequence[TrainingTaskSpec],
    *,
    checkpoint: Path,
    output_dir: Path,
    served_model_name: str,
    label: str,
) -> dict[str, Any]:
    score_path = output_dir / "scores.json"
    checkpoint_tree = _tree_manifest(checkpoint, ignored=frozenset({"merge_provenance.json"}))
    model_identity = _rollout_model_identity(
        checkpoint,
        served_model=served_model_name,
        tree=checkpoint_tree,
    )
    if score_path.is_file():
        score = _load_json(score_path)
        if score.get("checkpoint_digest") != checkpoint_tree["digest"]:
            raise CampaignPhaseError(f"validation checkpoint drifted: {label}")
        return score
    specs = procedural_specs(tasks)
    with VllmServer(
        model_path=checkpoint,
        served_model_name=served_model_name,
        output_dir=output_dir / "server",
        port=8000,
    ) as server:
        collection = collect_rollouts(
            specs,
            output_dir=output_dir / "runs",
            upstream_base_url=server.base_url,
            wire_model=served_model_name,
            model_label=f"{served_model_name}-{label}-validation",
            model_identity=model_identity,
            run_timeout_seconds=int(campaign.evaluation["safety_backstops"]["run_timeout_seconds"]),
            jobs=min(VALIDATION_JOBS, len(specs)),
            base_port=40_000,
            max_steps=4000,
            scaffold="browseruse",
            spawn_stagger_seconds=0.25,
        )
    if collection["failed_run_ids"] or collection["completed"] != len(tasks):
        raise CampaignPhaseError(f"procedural validation did not complete: {label}")
    score = _score_procedural_runs(output_dir / "runs", tasks)
    score.update(
        {
            "label": label,
            "checkpoint": str(checkpoint),
            "checkpoint_digest": checkpoint_tree["digest"],
            "collection": collection,
        }
    )
    atomic_json(score_path, score)
    return score


def _candidate(
    campaign: Campaign,
    label: str,
    checkpoint: Path,
    score: Mapping[str, Any],
    baseline: Mapping[str, Any],
) -> dict[str, Any]:
    settings = campaign.campaign["checkpointing"]
    tool_floor = float(baseline["tool_validity_rate"]) - float(
        settings["maximum_tool_validity_regression"]
    )
    efficiency_ceiling = float(baseline["satisficing_efficiency_median_steps"]) * (
        1.0 + float(settings["maximum_satisficing_efficiency_regression"])
    )
    reasons = []
    if int(score["binding_backstop_runs"]) != 0:
        reasons.append("binding_backstop")
    if float(score["tool_validity_rate"]) < tool_floor:
        reasons.append("tool_validity_regression")
    if float(score["satisficing_efficiency_median_steps"]) > efficiency_ceiling:
        reasons.append("satisficing_efficiency_regression")
    tree = _tree_manifest(checkpoint, ignored=frozenset({"merge_provenance.json"}))
    return {
        "label": label,
        "checkpoint": str(checkpoint),
        "checkpoint_digest": tree["digest"],
        "eligible": not reasons,
        "ineligible_reasons": reasons,
        "selection_metrics": {
            "optimal_product_rate": score["optimal_product_rate"],
            "all_mode_success_rate": score["all_mode_success_rate"],
            "tool_validity_rate": score["tool_validity_rate"],
            "satisficing_efficiency_median_steps": score["satisficing_efficiency_median_steps"],
        },
    }


def _publish_selection(
    campaign: Campaign,
    output: Path,
    candidates: Sequence[Mapping[str, Any]],
    baseline: Mapping[str, Any],
) -> dict[str, Any]:
    eligible = [dict(item) for item in candidates if item.get("eligible") is True]
    if not eligible:
        raise CampaignPhaseError("no trained checkpoint passed the frozen procedural guards")
    # Stage order is the last tie-break only; no Amazon outcome enters selection.
    selected = max(
        eligible,
        key=lambda item: (
            float(item["selection_metrics"]["optimal_product_rate"]),
            float(item["selection_metrics"]["all_mode_success_rate"]),
            float(item["selection_metrics"]["tool_validity_rate"]),
            -float(item["selection_metrics"]["satisficing_efficiency_median_steps"]),
            str(item["label"]),
        ),
    )
    result = {
        "schema": SELECTION_SCHEMA,
        "campaign_sha256": campaign.digest,
        "select_by": campaign.campaign["checkpointing"]["select_by"],
        "selection_data": "procedural_validation_only",
        "amazon_outcomes_used": False,
        "baseline_guards": {
            "tool_validity_rate": baseline["tool_validity_rate"],
            "satisficing_efficiency_median_steps": baseline["satisficing_efficiency_median_steps"],
        },
        "candidates": [dict(item) for item in candidates],
        "selected": selected,
    }
    atomic_json(output / "checkpoints" / "selection.json", result)
    return result


def _collect_on_policy(
    tasks: Sequence[TrainingTaskSpec],
    *,
    quota: int,
    output_dir: Path,
    upstream_base_url: str,
    wire_model: str,
    model_label: str,
    model_identity: Mapping[str, Any],
    run_timeout_seconds: int,
    base_port: int,
) -> tuple[list[Path], dict[str, Any]]:
    """Collect exactly ``quota`` usable student-visited episodes.

    Selection depends only on infrastructure completeness and an unbound safety
    audit, never on reward, purchase, or task success.
    """

    plan = {
        "schema": "harness-distill.on-policy-plan.v1",
        "quota": quota,
        "candidate_task_ids": [task.task_id for task in tasks],
        "candidate_sha256": _sha256_json([task.task_id for task in tasks]),
        "selection": "first deterministic infrastructure-complete unbound episodes",
    }
    _publish_plan(output_dir / "plan.json", plan)
    usable: list[Path] = []
    rejected: list[dict[str, str]] = []
    attempts = 0
    for start in range(0, len(tasks), ROLLOUT_BATCH_SIZE):
        batch_tasks = list(tasks[start : start + ROLLOUT_BATCH_SIZE])
        batch_dir = output_dir / "batches" / f"batch-{start // ROLLOUT_BATCH_SIZE:03d}"
        batch_result_path = batch_dir / "on_policy_batch_result.json"
        expected_ids = [task.task_id for task in batch_tasks]
        if batch_result_path.is_file():
            frozen = _load_json(batch_result_path)
            if frozen.get("task_ids") != expected_ids:
                raise CampaignPhaseError(f"on-policy batch plan drifted: {batch_dir}")
            collection = frozen["collection"]
        else:
            collection = collect_rollouts(
                procedural_specs(batch_tasks),
                output_dir=batch_dir,
                upstream_base_url=upstream_base_url,
                wire_model=wire_model,
                model_label=model_label,
                model_identity=model_identity,
                run_timeout_seconds=run_timeout_seconds,
                jobs=min(ROLLOUT_JOBS, len(batch_tasks)),
                base_port=base_port,
                max_steps=4000,
                scaffold="browseruse",
                spawn_stagger_seconds=0.25,
            )
            atomic_json(
                batch_result_path,
                {
                    "schema": "harness-distill.on-policy-batch.v1",
                    "task_ids": expected_ids,
                    "collection": collection,
                },
            )
        failed = set(collection.get("failed_run_ids", []))
        for task in batch_tasks:
            attempts += 1
            run_dir = _run_dir(batch_dir, task)
            if f"{task.task_id}-r1" in failed or not (run_dir / "trajectory.json").is_file():
                rejected.append({"task_id": task.task_id, "reason": "incomplete_or_error"})
                continue
            try:
                _assert_unbound(run_dir)
            except CampaignPhaseError:
                rejected.append({"task_id": task.task_id, "reason": "backstop_or_audit"})
                continue
            usable.append(run_dir)
            if len(usable) == quota:
                break
        if len(usable) == quota:
            break
    if len(usable) != quota:
        raise CampaignPhaseError(
            f"only {len(usable)} usable on-policy episodes after {attempts} attempts"
        )
    result = {
        "schema": "harness-distill.on-policy-result.v1",
        "quota": quota,
        "attempted": attempts,
        "usable": len(usable),
        "rejected": rejected,
        "run_dirs": [str(path) for path in usable],
        "outcome_blind_selection": True,
    }
    _publish_plan(output_dir / "result.json", result)
    return usable, result


def _prime_root() -> Path:
    return Path(os.environ.get("PRIME_RL_HOME", "/opt/prime-rl")).resolve()


def _prepare_sft_dataset(
    source_jsonl: Path,
    output_dir: Path,
    smoke_report: Path,
) -> Any:
    from .prime_training import materialize_sft_jsonl_to_parquet

    return materialize_sft_jsonl_to_parquet(
        source_jsonl,
        output_dir,
        smoke_report=smoke_report,
        seq_len=SEQUENCE_LENGTH,
        global_batch_size=8,
        prime_root=_prime_root(),
    )


def _rehearsal_mixture(
    *,
    round_index: int,
    corrective_rows: Sequence[Mapping[str, Any]],
    seed_sft_jsonl: Path,
    seed_prime_manifest: Path,
    output_dir: Path,
    smoke_report: Path,
    requested_fraction: float,
) -> tuple[Any, dict[str, Any]]:
    """Construct a deterministic 10% rehearsal mix measured by trainable tokens."""

    if not 0 < requested_fraction < 1:
        raise CampaignPhaseError("rehearsal fraction must be strictly between zero and one")
    correction_raw = output_dir / "correction-only" / "raw"
    correction_manifest = build_sft_jsonl([], corrective_rows, correction_raw)
    correction_data = _prepare_sft_dataset(
        Path(correction_manifest["path"]),
        output_dir / "correction-only" / "prime",
        smoke_report,
    )

    seed_rows = read_jsonl(seed_sft_jsonl)
    seed_audit = _load_json(seed_prime_manifest).get("token_audit")
    if not isinstance(seed_audit, Mapping) or not isinstance(seed_audit.get("rows"), list):
        raise CampaignPhaseError("seed SFT manifest lacks per-row token audit")
    audit_rows = seed_audit["rows"]
    if len(audit_rows) != len(seed_rows):
        raise CampaignPhaseError("seed SFT rows and token audit are misaligned")
    pool: list[tuple[dict[str, Any], int]] = []
    for row, audit in zip(seed_rows, audit_rows, strict=True):
        if row.get("schema") != "harness-distill.success-sft.v1":
            continue
        tokens = audit.get("trainable_tokens")
        if not isinstance(tokens, int) or tokens < 1:
            raise CampaignPhaseError("seed rehearsal row has no audited trainable tokens")
        pool.append((row, tokens))
    if not pool:
        raise CampaignPhaseError("seed SFT data contains no successful rehearsal rows")
    pool.sort(
        key=lambda pair: hashlib.sha256(
            f"rehearsal:{round_index}:{pair[0]['label_id']}".encode()
        ).hexdigest()
    )
    target = correction_data.trainable_tokens * requested_fraction / (1.0 - requested_fraction)
    selected: list[dict[str, Any]] = []
    selected_tokens = 0
    for row, tokens in pool:
        before = abs(target - selected_tokens)
        after = abs(target - (selected_tokens + tokens))
        if not selected or after <= before:
            selected.append(row)
            selected_tokens += tokens
            continue
        break
    if not selected:
        raise CampaignPhaseError("deterministic rehearsal sampler selected no rows")

    combined_raw = output_dir / "combined" / "raw"
    combined_manifest = build_sft_jsonl([], [*corrective_rows, *selected], combined_raw)
    combined_data = _prepare_sft_dataset(
        Path(combined_manifest["path"]),
        output_dir / "combined" / "prime",
        smoke_report,
    )
    expected_total = correction_data.trainable_tokens + selected_tokens
    if combined_data.trainable_tokens != expected_total:
        raise CampaignPhaseError("combined rehearsal token audit is not additive")
    actual_fraction = selected_tokens / combined_data.trainable_tokens
    mixture = {
        "schema": "harness-distill.alternating-corrective-mixture.v1",
        "round": round_index,
        "requested_rehearsal_fraction": requested_fraction,
        "measurement": "PRIME-rendered trainable assistant tokens",
        "corrective_rows": len(corrective_rows),
        "corrective_trainable_tokens": correction_data.trainable_tokens,
        "rehearsal_rows": len(selected),
        "rehearsal_trainable_tokens": selected_tokens,
        "combined_rows": combined_data.row_count,
        "combined_trainable_tokens": combined_data.trainable_tokens,
        "actual_rehearsal_fraction": actual_fraction,
        "selected_rehearsal_label_ids": [row["label_id"] for row in selected],
        "alternating_not_simultaneous_ce": True,
    }
    atomic_json(output_dir / "mixture.json", mixture)
    return combined_data, mixture


def _validated_phase_result(path: Path, campaign: Campaign) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    result = _load_json(path)
    if (
        result.get("schema") != PHASE_SCHEMA
        or result.get("campaign_sha256") != campaign.digest
        or result.get("status") != "complete"
    ):
        raise CampaignPhaseError(f"incompatible completed training phase: {path}")
    checkpoint = Path(str(result.get("checkpoint", ""))).resolve()
    expected = result.get("checkpoint_digest")
    current = _tree_manifest(checkpoint, ignored=frozenset({"merge_provenance.json"}))
    if current["digest"] != expected:
        raise CampaignPhaseError(f"completed training checkpoint drifted: {path}")
    return result


def run_sft_phase(campaign: Campaign, output_dir: str | Path) -> dict[str, Any]:
    """Collect seed browser trajectories and train the initial rank-64 LoRA."""

    from .prime_training import generate_sft_toml, launch_prime_training

    output = Path(output_dir).resolve()
    result_path = output / "checkpoints" / "sft_phase.json"
    complete = _validated_phase_result(result_path, campaign)
    if complete is not None:
        return complete
    selected = _selected_state(campaign, output)
    train = _tasks(campaign, output, "train")
    validation = _tasks(campaign, output, "validation")
    seed = campaign.campaign["seed_collection"]
    shadow_candidates = _ordered(
        (task for task in train if not (task.condition == "clean" and task.mode == "satisfice")),
        "seed-shadow",
    )
    rehearsal_candidates = _ordered(
        (task for task in train if task.condition == "clean" and task.mode == "satisfice"),
        "seed-clean-satisfice",
    )
    seed_dir = output / "rollouts" / "seed"
    model_id = str(selected["model"]["model_id"])
    seed_model_identity = _rollout_model_identity(
        selected["snapshot"],
        served_model=model_id,
        revision=str(selected["model"]["revision"]),
    )
    with VllmServer(
        model_path=selected["snapshot"],
        served_model_name=model_id,
        output_dir=seed_dir / "server",
        port=8000,
    ) as server:
        shadow_success, shadow_usable, shadow_result = _collect_to_quota(
            shadow_candidates,
            quota=int(seed["successful_shadow_trajectories"]),
            output_dir=seed_dir / "shadow",
            upstream_base_url=server.base_url,
            wire_model=model_id,
            model_label=f"{model_id}-seed-shadow",
            model_identity=seed_model_identity,
            run_timeout_seconds=int(campaign.evaluation["safety_backstops"]["run_timeout_seconds"]),
            base_port=20_000,
            maximum_attempts=int(seed["maximum_attempted_tasks"]),
        )
        rehearsal_success, rehearsal_usable, rehearsal_result = _collect_to_quota(
            rehearsal_candidates,
            quota=int(seed["clean_satisficing_rehearsal_trajectories"]),
            output_dir=seed_dir / "clean-satisfice",
            upstream_base_url=server.base_url,
            wire_model=model_id,
            model_label=f"{model_id}-seed-clean-satisfice",
            model_identity=seed_model_identity,
            run_timeout_seconds=int(campaign.evaluation["safety_backstops"]["run_timeout_seconds"]),
            base_port=24_000,
            maximum_attempts=int(seed["maximum_clean_satisficing_attempts"]),
        )
        supervision = _build_supervision(
            [*shadow_usable, *rehearsal_usable],
            output_dir=seed_dir / "supervision",
            teacher_base_url=server.base_url,
            model=selected["model"],
            decision_limit_per_session=int(seed["teacher_maximum_corrective_actions_per_episode"]),
        )

    corrective_rows = read_jsonl(Path(supervision["artifacts"]["labels"]["path"]))
    raw_dir = output / "data" / "sft" / "seed" / "raw"
    sft_manifest = build_sft_jsonl(
        [*shadow_success, *rehearsal_success],
        corrective_rows,
        raw_dir,
    )
    sft_data = _prepare_sft_dataset(
        Path(sft_manifest["path"]),
        output / "data" / "sft" / "seed" / "prime",
        selected["smoke_report"],
    )
    sft_config = campaign.campaign["sft"]
    artifact = generate_sft_toml(
        smoke_report=selected["smoke_report"],
        dataset_dir=sft_data.train_parquet.parent,
        config_path=output / "configs" / "generated-sft.toml",
        output_dir=output / "checkpoints" / "prime-sft",
        student_snapshot=selected["snapshot"],
        optimizer_updates=sft_data.optimizer_updates,
        seq_len=SEQUENCE_LENGTH,
        global_batch_size=8,
        num_gpus=8,
        rank=int(sft_config["lora_rank"]),
        alpha=float(sft_config["lora_alpha"]),
        dropout=float(sft_config["lora_dropout"]),
        learning_rate=float(sft_config["learning_rate"]),
        warmup_fraction=float(sft_config["warmup_fraction"]),
        checkpoint_interval=int(campaign.campaign["checkpointing"]["interval_updates"]),
    )
    trained = launch_prime_training(
        artifact,
        phase_dir=output / "checkpoints" / "launch-sft",
        prime_root=_prime_root(),
    )
    checkpoint = output / "models" / "stages" / "sft"
    merge = _verify_and_merge_stage(
        selected["snapshot"],
        trained.adapter_path,
        checkpoint,
        stage="sft",
    )

    baseline_score = _validate_checkpoint(
        campaign,
        validation,
        checkpoint=selected["snapshot"],
        output_dir=output / "eval" / "procedural-validation" / "base",
        served_model_name=model_id,
        label="base",
    )
    sft_score = _validate_checkpoint(
        campaign,
        validation,
        checkpoint=checkpoint,
        output_dir=output / "eval" / "procedural-validation" / "sft",
        served_model_name=model_id,
        label="sft",
    )
    candidate = _candidate(campaign, "sft", checkpoint, sft_score, baseline_score)
    checkpoint_tree = _tree_manifest(checkpoint, ignored=frozenset({"merge_provenance.json"}))
    result = {
        "schema": PHASE_SCHEMA,
        "phase": "sft",
        "status": "complete",
        "campaign_sha256": campaign.digest,
        "selected_role": selected["role"],
        "base_snapshot": str(selected["snapshot"]),
        "shadow_collection": shadow_result,
        "clean_satisficing_collection": rehearsal_result,
        "supervision": supervision,
        "dataset": sft_data.to_dict(),
        "prime_config": artifact.to_dict(),
        "prime_run": trained.to_dict(),
        "cumulative_merge": merge,
        "checkpoint": str(checkpoint),
        "checkpoint_digest": checkpoint_tree["digest"],
        "validation": {"base": baseline_score, "sft": sft_score},
        "candidate": candidate,
        "provisional_selection": candidate if candidate["eligible"] else None,
    }
    atomic_json(result_path, result)
    return result


def run_distillation_phase(campaign: Campaign, output_dir: str | Path) -> dict[str, Any]:
    """Run three chained OPD -> corrective/rehearsal SFT rounds."""

    from .prime_training import (
        generate_opd_toml,
        generate_sft_toml,
        generate_teacher_inference_toml,
        launch_prime_training,
        run_frozen_teacher,
    )

    output = Path(output_dir).resolve()
    final_path = output / "checkpoints" / "distill_phase.json"
    complete = _validated_phase_result(final_path, campaign)
    if complete is not None:
        return complete
    selected = _selected_state(campaign, output)
    sft_result = _validated_phase_result(output / "checkpoints" / "sft_phase.json", campaign)
    if sft_result is None:
        raise CampaignPhaseError("SFT phase must complete before distillation")
    train = _tasks(campaign, output, "train")
    validation = _tasks(campaign, output, "validation")
    settings = campaign.campaign["on_policy_context_distillation"]
    rounds = int(settings["rounds"])
    episode_quota = int(settings["episodes_per_round"])
    if rounds != 3 or episode_quota != 512:
        raise CampaignPhaseError("frozen campaign requires three 512-episode OPD rounds")

    seed_ids = {
        _task_id_from_run_dir(path)
        for key in ("shadow_collection", "clean_satisficing_collection")
        for path in sft_result[key]["attempted_run_dirs"]
    }
    remaining = _ordered(
        (task for task in train if task.task_id not in seed_ids),
        "opd-on-policy-pool",
    )
    candidate_block = episode_quota * 2
    if len(remaining) < rounds * candidate_block:
        raise CampaignPhaseError("too few fresh procedural tasks for disjoint OPD round pools")
    task_by_id = {task.task_id: task for task in train}
    round_plan = {
        "schema": "harness-distill.opd-round-plan.v1",
        "rounds": rounds,
        "episodes_per_round": episode_quota,
        "candidate_block_size": candidate_block,
        "excluded_seed_task_count": len(seed_ids),
        "round_task_ids": {
            str(index): [
                task.task_id
                for task in remaining[(index - 1) * candidate_block : index * candidate_block]
            ]
            for index in range(1, rounds + 1)
        },
    }
    round_plan["sha256"] = _sha256_json(round_plan["round_task_ids"])
    round_plan = _publish_plan(output / "rollouts" / "on-policy" / "plan.json", round_plan)

    current = Path(str(sft_result["checkpoint"])).resolve()
    baseline_score = sft_result["validation"]["base"]
    candidates = [dict(sft_result["candidate"])]
    round_results: list[dict[str, Any]] = []
    model_id = str(selected["model"]["model_id"])
    prime_root = _prime_root()
    for round_index in range(1, rounds + 1):
        round_root = output / "checkpoints" / f"distill-round-{round_index}"
        round_result_path = round_root / "round_result.json"
        prior = _validated_phase_result(round_result_path, campaign)
        if prior is not None:
            if Path(str(prior.get("parent_checkpoint", ""))).resolve() != current:
                raise CampaignPhaseError(f"distillation round {round_index} parent chain drifted")
            current = Path(str(prior["checkpoint"])).resolve()
            candidates.append(dict(prior["candidate"]))
            round_results.append(prior)
            continue

        round_tasks = [
            task_by_id[task_id] for task_id in round_plan["round_task_ids"][str(round_index)]
        ]
        rollout_root = output / "rollouts" / "on-policy" / f"round-{round_index}"
        student_model_identity = _rollout_model_identity(
            current,
            served_model=model_id,
        )
        with VllmServer(
            model_path=current,
            served_model_name=model_id,
            output_dir=rollout_root / "student-server",
            port=8000,
        ) as server:
            run_dirs, rollout_result = _collect_on_policy(
                round_tasks,
                quota=episode_quota,
                output_dir=rollout_root / "episodes",
                upstream_base_url=server.base_url,
                wire_model=model_id,
                model_label=f"{model_id}-opd-round-{round_index}",
                model_identity=student_model_identity,
                run_timeout_seconds=int(
                    campaign.evaluation["safety_backstops"]["run_timeout_seconds"]
                ),
                base_port=28_000 + round_index * 2_500,
            )

        # Sidecar extraction and corrective labeling always use the immutable
        # original base, never the evolving student or evaluator state.
        with VllmServer(
            model_path=selected["snapshot"],
            served_model_name=model_id,
            output_dir=rollout_root / "teacher-label-server",
            port=8001,
        ) as teacher_server:
            supervision = _build_supervision(
                run_dirs,
                output_dir=rollout_root / "supervision",
                teacher_base_url=teacher_server.base_url,
                model=selected["model"],
                decision_limit_per_session=None,
            )

        replay_path = Path(supervision["artifacts"]["replays"]["path"])
        opd_artifact = generate_opd_toml(
            smoke_report=selected["smoke_report"],
            replay_jsonl=replay_path,
            config_path=output / "configs" / f"generated-opd-round-{round_index}.toml",
            output_dir=round_root / "prime-opd",
            student_snapshot=current,
            round_index=round_index,
            optimizer_updates=int(settings["optimizer_updates_per_round"]),
            seq_len=SEQUENCE_LENGTH,
            batch_size=8,
            rank=64,
            alpha=128.0,
            dropout=0.0,
            learning_rate=float(settings["learning_rate"]),
            checkpoint_interval=int(campaign.campaign["checkpointing"]["interval_updates"]),
        )
        teacher_artifact = generate_teacher_inference_toml(
            smoke_report=selected["smoke_report"],
            config_path=output / "configs" / f"generated-frozen-teacher-round-{round_index}.toml",
            output_dir=round_root / "frozen-teacher-runtime",
            seq_len=SEQUENCE_LENGTH,
        )
        with run_frozen_teacher(
            teacher_artifact,
            phase_dir=round_root / "frozen-teacher-launch",
            prime_root=prime_root,
        ) as teacher_handle:
            teacher_snapshot = Path(teacher_handle.model_name).resolve()
            if _tree_manifest(teacher_snapshot) != selected["snapshot_tree"]:
                raise CampaignPhaseError("live OPD teacher is not the immutable original base")
            opd_run = launch_prime_training(
                opd_artifact,
                phase_dir=round_root / "launch-opd",
                prime_root=prime_root,
            )

        opd_checkpoint = output / "models" / "stages" / f"opd-round-{round_index}"
        opd_merge = _verify_and_merge_stage(
            current,
            opd_run.adapter_path,
            opd_checkpoint,
            stage=f"opd-round-{round_index}",
        )

        corrective_rows = read_jsonl(Path(supervision["artifacts"]["labels"]["path"]))
        correction_data, mixture = _rehearsal_mixture(
            round_index=round_index,
            corrective_rows=corrective_rows,
            seed_sft_jsonl=Path(sft_result["dataset"]["source_jsonl"]),
            seed_prime_manifest=Path(sft_result["dataset"]["manifest_path"]),
            output_dir=round_root / "alternating-corrective-data",
            smoke_report=selected["smoke_report"],
            requested_fraction=float(settings["rehearsal_fraction"]),
        )
        corrective_lr = float(settings["learning_rate"]) * float(
            settings["corrective_cross_entropy_weight"]
        )
        correction_artifact = generate_sft_toml(
            smoke_report=selected["smoke_report"],
            dataset_dir=correction_data.train_parquet.parent,
            config_path=output / "configs" / f"generated-corrective-sft-round-{round_index}.toml",
            output_dir=round_root / "prime-corrective-sft",
            student_snapshot=opd_checkpoint,
            optimizer_updates=correction_data.optimizer_updates,
            seq_len=SEQUENCE_LENGTH,
            global_batch_size=8,
            num_gpus=8,
            rank=64,
            alpha=128.0,
            dropout=0.0,
            learning_rate=corrective_lr,
            warmup_fraction=float(campaign.campaign["sft"]["warmup_fraction"]),
            checkpoint_interval=int(campaign.campaign["checkpointing"]["interval_updates"]),
        )
        correction_run = launch_prime_training(
            correction_artifact,
            phase_dir=round_root / "launch-corrective-sft",
            prime_root=prime_root,
        )
        round_checkpoint = output / "models" / "stages" / f"distill-round-{round_index}"
        correction_merge = _verify_and_merge_stage(
            opd_checkpoint,
            correction_run.adapter_path,
            round_checkpoint,
            stage=f"corrective-sft-round-{round_index}",
        )
        score = _validate_checkpoint(
            campaign,
            validation,
            checkpoint=round_checkpoint,
            output_dir=output / "eval" / "procedural-validation" / f"distill-round-{round_index}",
            served_model_name=model_id,
            label=f"distill-round-{round_index}",
        )
        candidate = _candidate(
            campaign,
            f"distill-round-{round_index}",
            round_checkpoint,
            score,
            baseline_score,
        )
        checkpoint_tree = _tree_manifest(
            round_checkpoint, ignored=frozenset({"merge_provenance.json"})
        )
        round_result = {
            "schema": PHASE_SCHEMA,
            "phase": f"distill-round-{round_index}",
            "status": "complete",
            "campaign_sha256": campaign.digest,
            "round": round_index,
            "parent_checkpoint": str(current),
            "rollout": rollout_result,
            "supervision": supervision,
            "opd": {
                "config": opd_artifact.to_dict(),
                "teacher_config": teacher_artifact.to_dict(),
                "run": opd_run.to_dict(),
                "cumulative_merge": opd_merge,
            },
            "alternating_corrective_sft": {
                "simultaneous_ce": False,
                "coefficient_realization": "separate_one_pass_lr_scaling",
                "corrective_cross_entropy_weight": settings["corrective_cross_entropy_weight"],
                "learning_rate": corrective_lr,
                "dataset": correction_data.to_dict(),
                "mixture": mixture,
                "config": correction_artifact.to_dict(),
                "run": correction_run.to_dict(),
                "cumulative_merge": correction_merge,
            },
            "validation": score,
            "candidate": candidate,
            "checkpoint": str(round_checkpoint),
            "checkpoint_digest": checkpoint_tree["digest"],
        }
        atomic_json(round_result_path, round_result)
        candidates.append(candidate)
        round_results.append(round_result)
        current = round_checkpoint

    selection = _publish_selection(campaign, output, candidates, baseline_score)
    selected_checkpoint = Path(selection["selected"]["checkpoint"]).resolve()
    selected_tree = _tree_manifest(
        selected_checkpoint, ignored=frozenset({"merge_provenance.json"})
    )
    result = {
        "schema": PHASE_SCHEMA,
        "phase": "distill",
        "status": "complete",
        "campaign_sha256": campaign.digest,
        "rounds": round_results,
        "selection": selection,
        "checkpoint": str(selected_checkpoint),
        "checkpoint_digest": selected_tree["digest"],
    }
    atomic_json(final_path, result)
    return result


def resolve_selected_adapter(output_dir: str | Path) -> Path:
    """Resolve the selected cumulative HF checkpoint for final verification.

    The legacy function name is kept for the CLI boundary.  Iterative training
    produces stage-local adapters, but the scientifically selected artifact is
    the fully merged cumulative checkpoint attested by procedural validation.
    """

    output = Path(output_dir).resolve()
    selection = _load_json(output / "checkpoints" / "selection.json")
    if selection.get("schema") != SELECTION_SCHEMA:
        raise CampaignPhaseError("checkpoint selection has an unsupported schema")
    if selection.get("selection_data") != "procedural_validation_only":
        raise CampaignPhaseError("checkpoint selection used non-procedural evidence")
    if selection.get("amazon_outcomes_used") is not False:
        raise CampaignPhaseError("checkpoint selection may not use Amazon outcomes")
    selected = selection.get("selected")
    if not isinstance(selected, Mapping) or selected.get("eligible") is not True:
        raise CampaignPhaseError("checkpoint selection has no eligible winner")
    checkpoint = Path(str(selected.get("checkpoint", ""))).resolve()
    current = _tree_manifest(checkpoint, ignored=frozenset({"merge_provenance.json"}))
    if current["digest"] != selected.get("checkpoint_digest"):
        raise CampaignPhaseError("selected cumulative checkpoint bytes drifted")
    provenance = _load_json(checkpoint / "merge_provenance.json")
    if provenance.get("schema") != MERGE_SCHEMA:
        raise CampaignPhaseError("selected cumulative checkpoint lacks merge attestation")
    verification = provenance.get("logit_verification") or {}
    if not all(
        verification.get(key) is True
        for key in ("non_noop", "merge_equivalent", "reload_equivalent")
    ):
        raise CampaignPhaseError("selected cumulative checkpoint failed logit verification")
    return checkpoint
