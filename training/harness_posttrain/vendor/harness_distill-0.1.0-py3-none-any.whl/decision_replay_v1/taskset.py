"""Typed Verifiers V1 task rows for materialized browser decisions."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import verifiers.v1 as vf
from verifiers.v1.dialects.chat import parse_message

from harness_distill.materialize import (
    MATERIALIZED_SCHEMA,
    PRIME_CONTROLLED_REQUEST_FIELDS,
    canonical_json,
    read_jsonl,
    rebuild_teacher_privilege,
    sha256_json,
)


class DecisionReplayData(vf.TaskData):
    """One baseline request plus a teacher-only OPD context sidecar."""

    replay_id: str
    split: str
    session_sha256: str
    source_sequence: int | None = None
    source_turn_index: int
    request_sha256: str
    replay_request_sha256: str
    request: dict[str, Any]
    privileged_context: str
    privilege_audit: dict[str, Any]
    reference_completion: dict[str, Any] | None = None


class DecisionReplayTask(vf.Task[DecisionReplayData]):
    @vf.stop
    async def exactly_one_decision(self, trace: vf.Trace) -> bool:
        return trace.num_turns >= 1


class DecisionReplayTasksetConfig(vf.TasksetConfig):
    path: str = ""
    split: str = "train"
    limit: int | None = None


def _validate_row(row: dict[str, Any], row_number: int) -> None:
    if row.get("schema") != MATERIALIZED_SCHEMA:
        raise ValueError(f"row {row_number}: unsupported replay schema")
    request = row.get("request")
    if not isinstance(request, dict):
        raise ValueError(f"row {row_number}: request must be an object")
    controlled = sorted(set(request) & PRIME_CONTROLLED_REQUEST_FIELDS)
    if controlled:
        raise ValueError(f"row {row_number}: PRIME-controlled request fields remain: {controlled}")
    if not isinstance(request.get("messages"), list) or not request["messages"]:
        raise ValueError(f"row {row_number}: request requires messages")
    context = row.get("privileged_context")
    if not isinstance(context, str):
        raise ValueError(f"row {row_number}: privileged_context must be JSON text")
    privilege = rebuild_teacher_privilege(json.loads(context))
    if privilege.state.turn_index > row.get("source_turn_index", -1):
        raise ValueError(f"row {row_number}: privilege comes from a future turn")
    if canonical_json(privilege.audit.to_dict()) != canonical_json(row.get("privilege_audit")):
        raise ValueError(f"row {row_number}: privilege audit does not match context")


class DecisionReplayTaskset(vf.Taskset[DecisionReplayTask, DecisionReplayTasksetConfig]):
    def load(self) -> list[DecisionReplayTask]:
        if not self.config.path:
            raise ValueError("decision replay taskset requires --taskset.path")
        path = Path(self.config.path)
        if not path.is_file():
            raise ValueError(f"decision replay dataset does not exist: {path}")
        if self.config.limit is not None and self.config.limit < 1:
            raise ValueError("taskset limit must be positive when set")

        selected: list[dict[str, Any]] = []
        for row_number, row in enumerate(read_jsonl(path), 1):
            _validate_row(row, row_number)
            if row.get("split") == self.config.split:
                selected.append(row)
            if self.config.limit is not None and len(selected) >= self.config.limit:
                break
        if not selected:
            raise ValueError(f"no replay rows found for split {self.config.split!r}")

        tasks: list[DecisionReplayTask] = []
        for idx, row in enumerate(selected):
            request = row["request"]
            # TaskData's typed prompt seeds trace bookkeeping.  The harness sends
            # the independently stored native request, so provider-specific wire
            # fields are still preserved exactly for the actual model call.
            typed_prompt = [parse_message(message) for message in request["messages"]]
            tasks.append(
                DecisionReplayTask(
                    DecisionReplayData(
                        idx=idx,
                        name=row["replay_id"],
                        prompt=typed_prompt,
                        system_prompt=None,
                        replay_id=row["replay_id"],
                        split=row["split"],
                        session_sha256=row["session_sha256"],
                        source_sequence=row.get("source_sequence"),
                        source_turn_index=row["source_turn_index"],
                        request_sha256=row["request_sha256"],
                        replay_request_sha256=sha256_json(request),
                        request=request,
                        privileged_context=row["privileged_context"],
                        privilege_audit=row["privilege_audit"],
                        reference_completion=row.get("reference_completion"),
                    ),
                    self.config.task,
                )
            )
        return tasks
