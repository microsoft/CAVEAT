# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Send exactly one native chat-completions request to Verifiers interception."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

PRIME_CONTROLLED_FIELDS = {
    "model",
    "temperature",
    "top_p",
    "top_k",
    "min_p",
    "typical_p",
    "presence_penalty",
    "frequency_penalty",
    "repetition_penalty",
    "max_tokens",
    "max_completion_tokens",
    "min_tokens",
    "seed",
    "n",
    "best_of",
    "stop",
    "stream",
    "stream_options",
    "logprobs",
    "top_logprobs",
    "logit_bias",
    "reasoning",
    "reasoning_effort",
    "extra_body",
}


def chat_completions_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/v1"):
        return base + "/chat/completions"
    return base + "/v1/chat/completions"


def request_body(request_path: str, model: str) -> dict:
    with Path(request_path).open("r", encoding="utf-8") as handle:
        body = json.load(handle)
    if not isinstance(body, dict) or not isinstance(body.get("messages"), list):
        raise ValueError("materialized request is not a chat-completions object")
    controlled = sorted(set(body) & PRIME_CONTROLLED_FIELDS)
    if controlled:
        raise ValueError(f"PRIME-controlled fields remain in request: {controlled}")
    if "privileged_context" in body:
        raise ValueError("privileged_context must never enter the model request")
    # The interception layer replaces this with ModelContext.model and imposes
    # ModelContext.sampling.  No other field is changed here.
    return {**body, "model": model}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--request", required=True)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    body = request_body(args.request, args.model)
    wire = json.dumps(
        body,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    ).encode("utf-8")
    request = Request(
        chat_completions_url(args.base_url),
        data=wire,
        method="POST",
        headers={
            "Authorization": f"Bearer {args.api_key}",
            "Content-Type": "application/json",
        },
    )
    try:
        # No client retry: a replay task is exactly one causal model call.
        with urlopen(request, timeout=1800) as response:  # noqa: S310
            raw = response.read()
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[-2000:]
        print(f"model request failed ({exc.code}): {detail}", file=sys.stderr)
        return 1
    except URLError as exc:
        print(f"model request failed: {exc}", file=sys.stderr)
        return 1
    try:
        completion = json.loads(raw)
        message = completion["choices"][0]["message"]
    except (json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
        print(f"invalid chat-completions response: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(message, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
