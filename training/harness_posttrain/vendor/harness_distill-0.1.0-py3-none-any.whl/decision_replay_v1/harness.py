"""One-call harness that replays a native browser-use request unchanged."""

from __future__ import annotations

import hashlib
from pathlib import Path

import verifiers.v1 as vf

from harness_distill.materialize import (
    PRIME_CONTROLLED_REQUEST_FIELDS,
    canonical_json,
    sha256_json,
)

PROGRAM_SOURCE = (Path(__file__).resolve().parent / "program.py").read_text()


class DecisionReplayHarnessConfig(vf.HarnessConfig):
    """No behavioral knobs: model and sampling belong to PRIME's ModelContext."""


class DecisionReplayHarness(vf.Harness[DecisionReplayHarnessConfig]):
    SUPPORTS_MESSAGE_PROMPT = True

    async def setup(self, runtime: vf.Runtime) -> None:
        await runtime.prepare_uv_script(PROGRAM_SOURCE, self.config.resolved_env)

    async def launch(
        self,
        ctx: vf.ModelContext,
        trace: vf.Trace,
        runtime: vf.Runtime,
        endpoint: str,
        secret: str,
        mcp_urls: dict[str, str],
    ) -> vf.ProgramResult:
        if mcp_urls:
            raise ValueError("decision replay never adds or connects MCP tools")
        data = trace.task.data
        request = data.request
        if not isinstance(request, dict) or not isinstance(request.get("messages"), list):
            raise ValueError("decision replay task has no native messages request")
        controlled = sorted(set(request) & PRIME_CONTROLLED_REQUEST_FIELDS)
        if controlled:
            raise ValueError(f"PRIME-controlled fields remain in replay: {controlled}")
        if sha256_json(request) != data.replay_request_sha256:
            raise ValueError("native replay request changed after task materialization")

        # Crucially, privileged_context is not read while constructing the
        # request and never crosses into the harness program.  PRIME's OPD
        # trainer reads it from TaskData on the teacher-scoring path only.
        request_bytes = canonical_json(request).encode("utf-8")
        digest = hashlib.sha256(request_bytes).hexdigest()
        request_path = f"/tmp/harness-distill-replay/{digest}.json"
        await runtime.write(request_path, request_bytes)
        program = await runtime.prepare_uv_script(PROGRAM_SOURCE, self.config.resolved_env)
        return await runtime.run_program(
            [
                *program,
                f"--base-url={endpoint}",
                f"--api-key={secret}",
                f"--model={ctx.model}",
                f"--request={request_path}",
            ],
            self.config.resolved_env,
        )
