"""Verifiers V1 taskset + harness for one-call browser decision replay.

Importing :mod:`harness_distill` does not import Verifiers.  This plugin is the
explicit integration boundary and is loaded only when selected by Verifiers.
"""

from .harness import DecisionReplayHarness, DecisionReplayHarnessConfig
from .taskset import DecisionReplayTaskset, DecisionReplayTasksetConfig

__all__ = [
    "DecisionReplayHarness",
    "DecisionReplayHarnessConfig",
    "DecisionReplayTaskset",
    "DecisionReplayTasksetConfig",
]
